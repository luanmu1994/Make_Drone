# Tài liệu kỹ thuật — PHẦN CẢM BIẾN ÂM THANH

> Phân hệ giám sát âm thanh: **module microphone MEMS INMP441**
> giao tiếp I2S, STM32F407VET6 thu qua **I2S3 ở chế độ Master
> Receive (chỉ thu)** bằng DMA vòng tròn. Đầu ra là một mức âm
> thang 0–100 đưa vào telemetry; vượt 80 thì dashboard cảnh báo.
> Đây là phân hệ được chốt sơ đồ chân sau cùng (10/11/2026) và
> phần firmware thu âm thuộc bước G5 của lộ trình tích hợp —
> trạng thái triển khai được ghi rõ ở cuối tài liệu.

## 1. Pin mapping

Module INMP441 có 6 chân: VDD, GND, SCK, WS, SD, L/R. Module
**không có chân MCK** — xung nhịp chủ (master clock) do nó tự suy
ra từ SCK, và đây là điểm quyết định toàn bộ lựa chọn chân bên
dưới.

| INMP441 | STM32F407 | Chức năng | Ghi chú |
|---|---|---|---|
| VDD | 3.3V | Nguồn (dải 1.62–3.63V) | Thêm tụ 100 nF VDD–GND tại module nếu chưa có |
| GND | GND | Đất chung | |
| SCK | **PC10** | I2S3_CK, AF6 — xung bit (BCLK) | STM32 cấp xung xuống mic |
| WS | **PA4** | I2S3_WS, AF6 — xung chọn kênh (LRCK) | |
| SD | **PC12** | I2S3_SD, AF6 — dữ liệu | Mic gửi lên STM32 |
| L/R | **GND** | Chọn kênh LEFT | Nối VDD thì thành kênh RIGHT |
| — | PC7 | I2S3_MCK | **Không dùng — tắt trong cấu hình** |

Cả ba chân tín hiệu đã đối chiếu Bảng 9 (Alternate function) của
datasheet DS8626 Rev 12: đều là AF6 của SPI3/I2S3.

**Vì sao không dùng bộ chân I2S3 còn lại** (SCK=PB3, WS=PA15,
SD=PB5): cả ba nằm trong nhóm chân SPI-Flash/NRF có sẵn trên bo
DevEBox (PA15 còn là chân JTAG JTDI), dễ xung đột phần cứng trên
bo. Còn chân MCK của I2S3 chỉ tồn tại ở PC7 — mà PC7 đang là
TIM3_CH2 của encoder động cơ M1. Vì INMP441 không cần MCK nên cấu
hình **Master Clock Output = Disable** là bắt buộc và vô hại;
đây là cùng một bản chất với quyết định trước đây ở I2S2 (MCK ở
PC6 cũng là chân encoder).

Phương án I2S3 này thay thế phương án I2S2 cũ (PB10/PB12/PC3,
giữ DMA1 Stream 3): PB10, PB12, PC3 và DMA1 Stream 3 nay được
giải phóng hoàn toàn.

## 2. Chức năng

- Thu âm thanh môi trường quanh xe liên tục, quy về một **mức âm
  nguyên thang 0–100** (trường `sound` trong khung telemetry
  0x01) và một cờ báo động `sound_alarm` khi mức > 80 theo yêu
  cầu của Brief.
- Dashboard (GCS) hiển thị mức âm theo thời gian thực và bật cảnh
  báo khi có tiếng động lớn bất thường gần xe (va chạm, tiếng kêu
  cơ khí, người gọi...) — kênh giám sát độc lập với cảm biến
  khoảng cách và encoder.

## 3. Thuật toán

### 3.1. Thu dữ liệu bằng DMA (thiết kế G5)

- I2S3 chạy Master Receive: STM32 phát SCK/WS, dữ liệu 24-bit
  (dấu bù 2, MSB trước, chuẩn Philips) chảy vào theo từng khung
  32-bit/kênh. Vì L/R = GND, dữ liệu hợp lệ nằm ở **slot LEFT**
  của mỗi khung; slot RIGHT bỏ qua.
- DMA1 Stream 0 / Channel 0 (ánh xạ SPI3_RX theo RM0090) chạy chế
  độ **Circular** vào một buffer vòng; sự kiện half-transfer và
  transfer-complete chia buffer thành các nửa để xử lý luân phiên
  mỗi ~100 ms. CPU không tham gia chép dữ liệu — DMA chạy nền
  ngay cả khi vòng lặp chính đang bận đo cảm biến (~75 ms) hay khi
  motor đang chạy, nên việc thu âm không làm chậm điều khiển.

### 3.2. Tính mức âm 0–100 (thiết kế G5)

Trên mỗi khối mẫu (slot LEFT, đã dịch về số nguyên 24-bit):

1. Loại bỏ thành phần DC (trừ trung bình khối) — microphone MEMS
   luôn có offset, không trừ thì mức nền bị đội lên.
2. Tính **giá trị đỉnh |x|max và RMS** của khối; dùng đỉnh để phản
   ứng nhanh với tiếng động đột ngột, RMS để mức hiển thị ổn định.
3. Ánh xạ sang thang 0–100 bằng hệ số hiệu chuẩn (mục 3.3); kẹp
   (clamp) trong [0, 100]. Cập nhật vào telemetry ở nhịp 5 Hz
   chung với khung trạng thái; cờ báo động = (mức > 80) đúng
   ngưỡng Brief, có giữ trạng thái ngắn hạn để dashboard không
   nhấp nháy theo từng khối 100 ms.

### 3.3. Hiệu chuẩn — điều kiện bắt buộc, không phải tùy chọn

Tiếng ồn tự thân của 4 động cơ N20 + hộp số khi xe chạy làm mức
âm nền tăng đáng kể. Nếu hiệu chuẩn thang 0–100 trong phòng yên
tĩnh thì khi xe vừa chạy, mức đo có thể vượt 80 và **báo động
giả liên tục**. Quy trình hiệu chuẩn đúng: đo mức nền trong 3
trạng thái (tĩnh / motor chạy không tải / chạy có tải) và đặt hệ
số ánh xạ + ngưỡng sao cho trạng thái chạy bình thường nằm dưới
ngưỡng báo động một khoảng an toàn, còn tiếng động bất thường
(vỗ tay mạnh, gõ vào khung xe) vượt ngưỡng rõ rệt.

## 4. Cấu hình và firmware

### 4.1. CubeMX

- SPI3 → Mode **I2S**, tắt Full-Duplex (chỉ thu).
- I2S3: Mode = **Master Receive**, Standard = **Philips**, Data
  Format = **24 bits on 32 bits frame**, Audio Frequency =
  **16 kHz** (đủ cho đo mức âm; băng thông âm cao hơn không cần
  cho mục đích cảnh báo), **Master Clock Output = Disable**.
- DMA: SPI3_RX → **DMA1 Stream 0, Channel 0**, Mode = Circular.
- Sau khi Generate Code phải rà lại `gpio.c`: PC10/PA4/PC12 ở
  AF6; **PC7 vẫn AF2 (TIM3)** — nếu CubeMX tự bật MCK thì PC7 sẽ
  bị chiếm và encoder M1 mất kênh B.

### 4.2. Đấu dây thực tế

Ba dây tín hiệu giữ ngắn (< 20 cm), đi kèm dây GND, tránh chạy
song song dài với dây PWM động cơ (nhiễu đóng cắt chui vào SCK
làm sai lệch mẫu). Không cắm thẻ TF vào khe microSD của bo khi
đang dùng cấu hình này vì khe TF dùng chung PC10/PC12 cho SDIO.

### 4.3. Firmware

Hiện firmware hợp nhất đã có sẵn **đường ống dữ liệu**: khung
telemetry 0x01 chứa trường `sound` (uint16, 0–100) và
`sound_alarm` (uint8) đúng định dạng dashboard.py đang đọc, cơ
chế tính mức chạy ở nhịp 100 ms trong vòng điều phối của
`app_main` đã được dự trù trong phân tích tích hợp (mục 6). Phần
chưa viết là khối thu I2S3+DMA và hàm tính mức (bước G5); cho
tới khi G5 hoàn thành, firmware gửi `sound = 0, sound_alarm = 0`
để khung telemetry giữ nguyên định dạng.

**Trạng thái:** sơ đồ chân + cấu hình đã chốt và kiểm chứng
không xung đột với toàn bộ bản đồ tài nguyên của project (32
chân đã dùng + 3 chân mới, mỗi chân một chức năng; DMA1 Stream 0
là kênh DMA đầu tiên được dùng trong project). Firmware thu âm
chưa triển khai (G5) và chưa có số liệu thực nghiệm — hiệu chuẩn
theo mục 3.3 chỉ thực hiện được sau khi G5 chạy trên phần cứng.

## 5. Sơ đồ khối & lưu đồ

```
Âm thanh ──► INMP441 ──I2S3 (PC10/PA4/PC12, AF6)──► DMA1 Stream 0 Ch 0 (Circular)
                                                            │ buffer vòng, sự kiện nửa/đầy
                                                            ▼
                              Xử lý mỗi ~100 ms: bỏ DC → đỉnh + RMS → ánh xạ 0–100
                                                            │
                                                            ▼
                              telemetry khung 0x01 (sound, sound_alarm) ──► dashboard GCS
```

Lưu đồ xử lý một khối: nhận sự kiện DMA (nửa buffer vừa đầy) →
trích các mẫu slot LEFT → trừ trung bình (bỏ DC) → tính |x|max
và RMS → cập nhật mức hiển thị (RMS) và bộ giữ báo động (đỉnh)
→ ghi vào biến dùng chung cho telemetry ở nhịp 5 Hz.

## 6. Thông số kỹ thuật & tiêu chí đánh giá

| Hạng mục | Giá trị | Tiêu chí đạt |
|---|---|---|
| Định dạng dữ liệu | 24-bit trên khung 32-bit, chuẩn Philips | Giải mã đúng slot LEFT, mẫu không bị lệch kênh |
| Tần số lấy mẫu | 16 kHz | Đủ băng thông tiếng động môi trường; nhu cầu là đo mức, không ghi âm |
| Thang đo | 0–100, báo động > 80 (theo Brief) | Sau hiệu chuẩn: xe chạy bình thường không báo động giả; tiếng động bất thường (vỗ tay mạnh, gõ khung) vượt ngưỡng rõ rệt |
| Chu kỳ cập nhật mức | ~100 ms xử lý, phát telemetry 5 Hz | Mức trên dashboard nhảy theo tiếng động trong < 0,5 s |

## 7. Kết quả kiểm thử

| Bài test | Kết quả |
|---|---|
| Rà soát xung đột tài nguyên | **Đạt (kiểm chứng tĩnh)**: PC10/PA4/PC12 + DMA1 Stream 0 không trùng bất kỳ chân/kênh nào trong bản đồ 35 chân của project (32 chân cũ + 3 chân mới, rà cơ học từ mã nguồn cấu hình) |
| Đối chiếu chân theo datasheet | Đạt: cả 3 chân là AF6 của I2S3 theo DS8626 Rev 12 Bảng 9 |
| Thu âm trên phần cứng thật | **Chưa thực nghiệm** — firmware thu (G5) chưa triển khai nên chưa có mẫu âm, chưa hiệu chuẩn được thang 0–100. Mục này để trống kết quả đo một cách có chủ đích, chờ G5 |

## 8. So sánh & lựa chọn phương án

- **I2S3 (bộ chân PC10/PA4/PC12) vs I2S2 (PB10/PB12/PC3):**
  I2S2 là phương án phân tích ban đầu; chuyển sang I2S3 theo
  hướng triển khai hiện tại vì bộ chân được chọn đều trống hoàn
  toàn, đồng thời giải phóng PB10/PB12/PC3 cho dự phòng. Cái giá
  phải trả: PC10/PC12 trùng nhóm SDIO của khe thẻ TF trên bo —
  chấp nhận được vì project không dùng thẻ nhớ.
- **I2S3 vs bộ chân PB3/PA15/PB5 của chính I2S3:** bộ chân sau
  dính nhóm SPI-Flash/NRF và chân JTAG trên bo — loại.
- **Mic I2S số (INMP441) vs mic analog + ADC:** INMP441 tích hợp
  sẵn ADC, tín hiệu số ít nhiễm nhiễu PWM của motor hơn hẳn
  đường analog chạy dài trên xe, và không tốn kênh ADC. Chọn
  INMP441 theo Brief.
- **DMA vòng tròn vs đọc polling:** polling sẽ tranh vòng lặp
  chính với các lượt đo cảm biến ~75 ms, làm méo nhịp lấy mẫu;
  DMA chạy nền độc lập. Chọn DMA.

## 9. An toàn & xử lý sự cố

Phân hệ âm thanh chỉ giám sát, không tham gia điều khiển, nên
rủi ro an toàn của nó là **gây hại gián tiếp** cho phân hệ khác:

- Rủi ro lớn nhất: CubeMX tự bật MCK sẽ chiếm PC7 và làm mất
  kênh B encoder M1 mà không có lỗi build nào cảnh báo. Đối
  sách: Master Clock Output = Disable + bước rà `gpio.c` sau
  mỗi lần Generate (PC7 phải là AF2).
- Báo động giả do tiếng ồn motor: xử lý bằng hiệu chuẩn 3 trạng
  thái (mục 3.3), không bằng cách nâng ngưỡng tùy tiện.
- Mất dữ liệu âm (DMA dừng, cấu hình sai) không được phép ảnh
  hưởng điều khiển xe: trường sound giữ giá trị 0 và hệ thống
  còn lại chạy bình thường — đúng hành vi hiện tại khi G5 chưa
  triển khai.

| Triệu chứng (dự kiến khi triển khai G5) | Nguyên nhân hay gặp | Xử lý |
|---|---|---|
| Mức âm luôn 0 | DMA chưa chạy / nhầm slot kênh / L/R nối khác với cấu hình đọc | Kiểm tra sự kiện DMA có về; đối chiếu L/R phần cứng với slot firmware đọc |
| Encoder M1 mất đếm sau khi thêm I2S3 | MCK bị bật, PC7 thành AF6 | Tắt MCK, rà gpio.c, Generate lại |
| Báo động liên tục khi xe chạy | Chưa hiệu chuẩn nền motor | Chạy quy trình hiệu chuẩn mục 3.3 |

## 10. Hạn chế & hướng phát triển

- Firmware thu âm chưa viết (G5) — đây là phân hệ duy nhất của
  project mới dừng ở mức chốt chân + thiết kế thuật toán, chưa
  có kiểm chứng chạy thật.
- Thang 0–100 là thang tương đối theo hiệu chuẩn tại chỗ, không
  phải dB SPL tuyệt đối; muốn số liệu dB thật cần microphone
  chuẩn đối chiếu.
- Chưa rõ mức ồn nền thực tế của 4 motor trên khung xe thật —
  con số này quyết định khoảng an toàn của ngưỡng 80 và chỉ đo
  được sau G5. Hướng phát triển: triển khai G5, hiệu chuẩn 3
  trạng thái, cân nhắc thêm lọc thông thấp cho mức hiển thị và
  ghi log sự kiện âm lớn kèm mốc thời gian.
