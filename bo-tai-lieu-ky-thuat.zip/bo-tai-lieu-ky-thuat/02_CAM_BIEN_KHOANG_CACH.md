# Tài liệu kỹ thuật — PHẦN CẢM BIẾN KHOẢNG CÁCH

> Phân hệ đo khoảng cách vật cản: **3 module VL53L0X** (laser
> ToF — time-of-flight) đặt ở trước/trái/phải của xe, giao tiếp
> I2C chung bus I2C1 với STM32F407VET6, phân biệt bằng địa chỉ
> riêng sau khi gán lúc khởi động. Driver dùng bản register-level
> `st-flow-v5` — bản driver đã chứng minh đo được trên phần cứng
> thật của project này.

Module thực tế đang dùng (theo ảnh chụp của người dùng, thay thế
mọi ảnh minh họa của shop): mạch **CJVL53L0X V2 màu đen** (kiểu
CJMCU, hai tai bắt vít) — không phải GY-530 xanh trong tài liệu
gốc, không phải HW-843 tím. Chip vẫn là VL53L0X, địa chỉ I2C mặc
định 0x29.

## 1. Pin mapping

Thứ tự chân trên module (nhìn mặt chữ silkscreen, từ trái sang
phải): **VCC – GND – SCL – SDA – GPIO1 – XSHUT**. Hai chân GPIO1
và XSHUT nằm kề nhau — đây là điểm dễ cắm nhầm dây XSHUT nhất khi
đấu 3 module.

| Tín hiệu | FRONT | LEFT | RIGHT | Ghi chú |
|---|---|---|---|---|
| VCC | 3.3V | 3.3V | 3.3V | Cấp chung rail 3.3V |
| GND | GND | GND | GND | Đất chung |
| SCL | PB6 (I2C1_SCL) | PB6 | PB6 | Bus chung |
| SDA | PB7 (I2C1_SDA) | PB7 | PB7 | Bus chung |
| XSHUT | **PC0** | **PC1** | **PC2** | GPIO Output, mức khởi tạo LOW |
| GPIO1 (ngắt) | không nối | không nối | không nối | Firmware polling, không dùng ngắt |
| Địa chỉ sau gán | **0x30** | **0x31** | **0x32** | Gán qua thanh ghi 0x8A lúc boot |

Lưu ý trên bo DevEBox: PB6/PB7 đồng thời là chân của khe cắm
NRF24 — **không cắm module NRF24 khi đang dùng I2C1** cho cảm biến.

Điện trở kéo lên (pull-up) SCL/SDA dùng điện trở có sẵn trên từng
module; khi 3 module song song, điện trở tương đương giảm còn
khoảng 1/3 — đây là một phần lý do bus phải chạy 100 kHz (mục 4).

## 2. Chức năng

- Đo khoảng cách tới vật cản ở 3 hướng trước/trái/phải, dải hữu
  dụng trong project: 30–2000 mm.
- Phân loại mỗi hướng thành **vùng an toàn** theo ngưỡng của Brief:
  SAFE > 1000 mm, WARNING 500–1000 mm, AVOID 250–500 mm,
  STOP ≤ 250 mm — đầu vào trực tiếp cho bộ điều hướng (nav_fsm)
  quyết định đi thẳng / chậm lại / tránh / dừng.
- Tự giám sát tình trạng: tỉ lệ mẫu hợp lệ của từng cảm biến, bộ
  đếm lỗi firmware, trạng thái mất dữ liệu (stale) để hệ thống
  chuyển sang fail-safe BLOCKED khi không còn tin được cảm biến.

## 3. Thuật toán

### 3.1. Khởi tạo và gán địa chỉ (vấn đề kinh điển của nhiều VL53L0X chung bus)

Cả 3 module đều thức dậy ở cùng địa chỉ 0x29 nên không thể init
song song. Quy trình boot:

1. Giữ cả 3 XSHUT ở mức LOW (module tắt) trong 10 ms. Firmware có
   bước **BUS CHECK**: dò địa chỉ 0x29 trong lúc cả 3 đang tắt —
   nếu vẫn có thiết bị trả ACK thì XSHUT không kiểm soát được
   module (sai chân GPIO hoặc cắm nhầm dây sang GPIO1).
2. Nhả XSHUT của **một** module, init nó tại 0x29, ghi thanh ghi
   0x8A để gán địa chỉ mới (0x30/0x31/0x32), đọc lại Model ID
   (0xEE) tại địa chỉ mới để xác nhận.
3. Lặp lại cho module tiếp theo. Module nào init lỗi thì hạ XSHUT
   tắt hẳn ngay, hai module còn lại vẫn hoạt động bình thường.

Mỗi bước init ghi lại **mã giai đoạn (init_stage 1–8)** và byte ID
đọc được; dòng log lỗi có dạng `INIT S2 LEFT: FAIL stage=5
id=0x..` để chẩn đoán chính xác chết ở bước nào (không ACK / sai
ID / VHV / data-init / gán địa chỉ / SPAD info / tuning / hiệu
chuẩn tham chiếu).

### 3.2. Hiệu chuẩn tham chiếu SPAD — gốc rễ của sự cố đo không ra số

Bài học đắt nhất của phân hệ này: các driver rút gọn thường nạp
bảng SPAD (single-photon avalanche diode) tham chiếu lưu sẵn trong
NVM của chip. Trên các module đang dùng, dữ liệu NVM đó cho tín
hiệu phản hồi ≈ 0 → phép đo hoàn tất nhưng luôn báo "không có mục
tiêu" (`err=4`, khoảng cách 8191 mm) dù vật ở ngay trước mặt, và
**thay 3 module khác nhau vẫn lỗi y hệt** (chứng tỏ không phải
module chết). Driver `st-flow-v5` xử lý bằng cách port hai thủ tục
của ST vào driver register-level:

- `PerformRefSpadManagement`: quét tìm tập SPAD cho ra tín hiệu
  tham chiếu nội bộ ~21 MCPS;
- `PerformRefCalibration`: hiệu chuẩn VHV + phase.

Sau khi có hai bước này, cảm biến đo ổn định 33–37 mm ở khoảng
gần và bám vật 46–229 mm, `valid_count=5, error_count=0` (kết quả
bench ngày 31/10/2026). Hệ quả bắt buộc: **không trộn driver khác
(Adafruit, bản LONG_RANGE) vào cùng main.c** — hàm Begin của chúng
init lại bằng SPAD từ NVM và phá hỏng trạng thái hiệu chuẩn trên.

### 3.3. Lấy mẫu trượt (rolling) và trung vị trượt

Đo burst cả 3 cảm biến liên tiếp sẽ chặn vòng lặp chính ~1,1 giây
— không chấp nhận được khi xe cần phản ứng STOP < 100 ms. Thuật
toán đang dùng (`VL53_3_Step()`):

- Mỗi lượt vòng lặp chính chỉ đo **single-shot một cảm biến**, luân
  phiên nghiêm ngặt FRONT → LEFT → RIGHT (~75 ms mỗi lượt).
- Mọi lần đo (kể cả lần lỗi, ghi là INVALID) đều đẩy vào **cửa sổ
  trượt 5 mẫu** của cảm biến đó; giá trị công bố là **trung vị**
  (median) khi có ≥ 3/5 mẫu hợp lệ. Trung vị loại được các mẫu
  nhiễu đơn lẻ tốt hơn trung bình cộng.
- Cửa sổ hết hạn sau 3 lần đo lỗi liên tiếp; dữ liệu quá 1 giây
  chưa cập nhật bị coi là stale → nav_fsm xử lý fail-safe.
- 20 lần đo lỗi liên tiếp → cảm biến bị đánh dấu offline; khi xe
  đang dừng, firmware thử khôi phục (`VL53_3_Recover`) mỗi 10 giây,
  tối đa 3 lần mỗi cảm biến.
- Tần suất hiệu dụng: mỗi cảm biến có mẫu mới sau ~220 ms, trung
  vị cập nhật ~4–5 Hz — là giới hạn vật lý của sơ đồ single-shot
  luân phiên trên bus 100 kHz.

### 3.4. Phân vùng và hysteresis

Ngưỡng vùng như mục 2, cộng **hysteresis 50 mm** tại mỗi biên:
muốn đổi vùng, khoảng cách phải vượt ngưỡng thêm 50 mm theo chiều
ngược lại. Hysteresis chống hiện tượng vùng nhảy qua lại khi vật
nằm đúng biên ngưỡng (ví dụ 249/251 mm luân phiên) làm FSM dao
động theo.

## 4. Cấu hình và firmware

### 4.1. CubeMX

- I2C1: PB6/PB7, tốc độ **100 kHz** (hạ từ 400 kHz: 1 module chạy
  400 kHz được, nhưng 3 module song song làm điện dung bus tăng
  gấp ~3, cạnh xung méo — đây là nghi phạm số một của đợt lỗi
  INIT FAIL cả 3 cảm biến và là mục kiểm tra đầu tiên trong danh
  sách chẩn đoán).
- PC0/PC1/PC2: GPIO_Output, **mức khởi tạo LOW** (sai mục này là
  cả 3 module thức cùng lúc ở 0x29 và gán địa chỉ thất bại).
- USART1 (PA9/PA10) 115200: kênh log/bench có dây.

### 4.2. File firmware

| File | Vai trò |
|---|---|
| `vl53l0x_min.c/.h` | Driver register-level đa thiết bị (bản st-flow-v5 mở rộng): struct `VL53M_Dev`, `VL53M_Init(dev, new_addr7)`, `VL53M_Shutdown()`, quản lý SPAD + hiệu chuẩn tham chiếu, ghi init_stage/id_byte phục vụ chẩn đoán |
| `vl53l0x_3sensor.c/.h` | Lớp ứng dụng rolling: `VL53_3_Step()`, cửa sổ trượt + trung vị, phân vùng/hysteresis, stale/offline/recover, in CSV 5 Hz |

Định dạng log CSV (USART1, 5 Hz):
`tick_ms,front_mm,left_mm,right_mm,f_zone,l_zone,r_zone,valid_sensors,error_count`
(giá trị −1 = INVALID). Dashboard bench: `dashboard_3sensor.py`
(hiển thị + giải mã stage/BUS CHECK) và `dashboard_tong_hop.py`
(khi chạy chung với motor).

### 4.3. Quy trình kiểm tra

1. Boot: log phải có BUS CHECK OK và 3 dòng INIT OK kèm địa chỉ
   0x30/0x31/0x32.
2. Che từng cảm biến bằng bàn tay ở ~10 cm: chỉ cột tương ứng tụt
   xuống ~100 mm, hai cột còn lại không đổi — kiểm chứng không
   nhầm địa chỉ/kênh.
3. Bài đo độ chính xác: đặt bia tại các mốc 50/100/200/300/500/
   800/1000 mm, lấy 20 mẫu mỗi mốc (dashboard có sẵn chức năng):
   đạt khi sai số ≤ 5% hoặc ≤ 20 mm trong 100–800 mm; ≤ 10% tại
   1000 mm; mốc 50 mm chỉ ghi nhận.

**Trạng thái:** nhánh 1 cảm biến đã chứng minh chạy trên phần
cứng thật (31/10/2026). Nhánh 3 cảm biến: lần chạy thật đầu tiên
(04/11/2026) cả 3 đều INIT FAIL — bản firmware chẩn đoán (BUS
CHECK + mã stage) đã bàn giao và đang chờ log boot mới để khoanh
nguyên nhân theo danh sách: hạ I2C xuống 100 kHz → test cô lập
từng module → đo VCC tại chân module. Bài đo độ chính xác 20 mẫu
chưa thực hiện.

## 5. Sơ đồ khối & lưu đồ

```
Vật cản ──► 3× VL53L0X ──I2C1 (PB6/PB7, 100 kHz)──► vl53l0x_min (driver)
                                                        │ single-shot luân phiên
                                                        ▼
                              vl53l0x_3sensor: cửa sổ trượt 5 mẫu → TRUNG VỊ
                                                        │ mm + vùng (hysteresis 50 mm)
                                          ┌─────────────┴─────────────┐
                                          ▼                           ▼
                                    nav_fsm (trên xe)        CSV 5 Hz → dashboard
```

Lưu đồ boot: giữ 3 XSHUT LOW 10 ms → BUS CHECK tại 0x29 (phải
câm) → với từng cảm biến: nhả XSHUT → init tại 0x29 (gồm quản lý
SPAD + hiệu chuẩn tham chiếu) → gán địa chỉ mới qua thanh ghi
0x8A → đọc lại Model ID 0xEE tại địa chỉ mới → lỗi thì hạ XSHUT
tắt hẳn và ghi mã stage.

## 6. Thông số kỹ thuật & tiêu chí đánh giá

| Hạng mục | Giá trị | Tiêu chí đạt |
|---|---|---|
| Dải đo dùng trong project | 30–2000 mm | — |
| Độ chính xác (bài test 20 mẫu/mốc) | Mốc 50/100/200/300/500/800/1000 mm | ≤ 5% hoặc ≤ 20 mm trong 100–800 mm; ≤ 10% tại 1000 mm; 50 mm chỉ ghi nhận |
| Tần suất cập nhật | ~4–5 Hz mỗi cảm biến (luân phiên single-shot) | Trung vị đổi theo vật trong < 0,5 s |
| Ngưỡng vùng | STOP ≤ 250 / AVOID ≤ 500 / WARNING ≤ 1000 mm, hysteresis 50 mm | Vùng không nhảy qua lại khi vật đứng yên ở biên |
| Tính toàn vẹn dữ liệu | Stale > 1 s → fail-safe BLOCKED | Rút một cảm biến khi chạy: hệ thống phải báo mất và xử lý an toàn, không dùng số cũ |

## 7. Kết quả kiểm thử

| Bài test | Kết quả |
|---|---|
| 1 cảm biến trên phần cứng thật (31/10/2026) | **Đạt**: đo ổn định 33–37 mm, bám vật 46–229 mm, valid_count = 5, error_count = 0, vùng STOP đúng. Trước đó cùng phần cứng báo err=4/8191 mm liên tục — đối chứng cho thấy sửa đúng nguyên nhân (SPAD) chứ không phải thay module |
| Gán địa chỉ + luân phiên (mô phỏng, 06/11/2026) | Đạt: boot gán PC0→0x30, PC1→0x31, PC2→0x32; 15 lượt Step luân phiên đúng thứ tự FRONT→LEFT→RIGHT; trung vị/vùng đúng số liệu mẫu |
| Dashboard 3 cảm biến v2 | Đạt kiểm thử phần mềm: hiện BUS CHECK, giải mã đúng stage trên thẻ cảm biến lỗi, mô phỏng chạy đủ kịch bản FSM |
| 3 cảm biến trên phần cứng thật (04/11/2026) | **Chưa đạt**: cả 3 INIT FAIL ở lần chạy đầu. Bản chẩn đoán (BUS CHECK + mã stage 1–8) đã bàn giao; chờ log boot mới để kết luận nguyên nhân |
| Bài độ chính xác 20 mẫu × 7 mốc | **Chưa thực hiện** |

## 8. So sánh & lựa chọn phương án

- **Rolling single-shot vs đo burst cả 3:** burst chặn vòng lặp
  ~1,1 s, phá vỡ yêu cầu phản ứng STOP < 100 ms và nhịp ramp
  motor 10 ms; rolling trả giá bằng tần suất 4–5 Hz/cảm biến
  nhưng mỗi lượt chỉ ~75 ms và luôn có dữ liệu mới nhất của một
  hướng. Chọn rolling.
- **Driver register-level + ST flow (v5) vs thư viện ST API đầy
  đủ:** bản API đầy đủ từng gây nhiều lỗi build/tích hợp trong
  quá trình làm project; port riêng hai thủ tục hiệu chuẩn của ST
  vào driver register nhỏ gọn cho kết quả đo đã được chứng minh
  trên đúng module đang dùng. Chọn v5 và cố định nó làm driver
  duy nhất của project.
- **Trung vị vs trung bình cộng:** trung vị loại hẳn mẫu nhiễu
  đơn lẻ (điểm đo bay) mà không cần ngưỡng lọc; chọn cửa sổ 5 +
  trung vị, yêu cầu tối thiểu 3/5 mẫu hợp lệ mới công bố.
- **I2C 100 kHz vs 400 kHz:** 400 kHz chạy được với 1 module
  nhưng 3 module song song tăng điện dung bus ~3 lần; chọn
  100 kHz để lấy độ tin cậy, tốc độ vẫn đủ cho sơ đồ rolling.

## 9. An toàn & xử lý sự cố

Nguyên tắc an toàn của phân hệ: **mất dữ liệu phải nguy hiểm
bằng không** — cảm biến stale > 1 s hoặc mất ≥ 2 cảm biến thì
nav_fsm ép BLOCKED bất kể giá trị cuối cùng đọc được là bao
nhiêu.

| Triệu chứng | Nguyên nhân hay gặp | Xử lý |
|---|---|---|
| Đo hoàn tất nhưng luôn 8191 mm, err=4 | SPAD tham chiếu từ NVM cho tín hiệu 0 | Dùng driver v5 (có PerformRefSpadManagement); không trộn driver khác vào cùng main.c |
| INIT FAIL cả 3 (log mới có stage) | Theo mã stage: 1 = không ACK (nguồn/dây/XSHUT), 5 = gán địa chỉ (xung đột bus), còn lại đa số do bus chập chờn | Theo thứ tự: I2C về 100 kHz → test cô lập từng module như bài 1 cảm biến → đo VCC tại chân module (3.2–3.4V) → kiểm tra dây XSHUT có cắm nhầm sang GPIO1 |
| BUS CHECK báo CANH BAO | Có thiết bị trả ACK ở 0x29 khi cả 3 XSHUT đang LOW | PC0/PC1/PC2 chưa cấu hình GPIO Output, hoặc dây XSHUT không tới đúng chân module |
| Giá trị nhảy loạn trên một số bề mặt | Bề mặt đen/bóng/nghiêng — đặc tính vật lý của ToF | Dựa vào trung vị + fail-safe; không diễn giải là lỗi firmware |

## 10. Hạn chế & hướng phát triển

- Đầu mối lớn nhất còn mở: bench 3 cảm biến trên phần cứng thật
  chưa khép (INIT FAIL), và bài độ chính xác chuẩn chưa chạy —
  mọi khẳng định về độ chính xác hiện mới dựa trên bài 1 cảm
  biến.
- Tần suất 4–5 Hz/cảm biến là trần của sơ đồ single-shot luân
  phiên trên bus chung; vật tiến nhanh có thể chỉ được phát hiện
  sau tối đa ~220 ms + thời gian xử lý FSM.
- VL53L0X yếu trên bề mặt hấp thụ IR (vải đen) và bề mặt gương
  góc nghiêng lớn; hướng phát triển: chuyển VL53L1X (xa hơn, có
  ROI), dùng chế độ đo liên tục + chân GPIO1 làm ngắt để tăng
  tần suất, hoặc bổ sung cảm biến siêu âm cho bề mặt khó.
