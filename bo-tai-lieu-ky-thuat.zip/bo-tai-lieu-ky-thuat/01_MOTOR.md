# Tài liệu kỹ thuật — PHẦN MOTOR

> Phân hệ truyền động của xe mô hình: **4 động cơ GA12-N20** (6V,
> ~300 RPM tại trục ra) kèm encoder Hall, điều khiển qua **2 mạch
> TB6612FNG**, vi điều khiển STM32F407VET6. Tài liệu này mô tả đúng
> phần cứng thực tế đang dùng và firmware đã bàn giao (driver
> `motor_n20` v3, bài test `motors_4test` v3.2, khối `motors_app`
> trong project hợp nhất).

Định danh 4 động cơ: **M1 = trước–trái (FL), M2 = trước–phải (FR),
M3 = sau–trái (RL), M4 = sau–phải (RR)**. TB6612 thứ nhất (TB1) lái
M1 (kênh A) + M2 (kênh B); TB6612 thứ hai (TB2) lái M3 (kênh A) +
M4 (kênh B).

## 1. Pin mapping

### 1.1. Dây động cơ + encoder (6 dây JST, đọc theo silkscreen trên mạch XY-N20)

| Dây | Tín hiệu | Nối tới |
|---|---|---|
| Đỏ | M2 (một đầu cuộn motor) | Ngõ ra motor của TB6612 (AO/B{O}) |
| Trắng | M1 (đầu cuộn còn lại) | Ngõ ra motor còn lại của kênh |
| **Đen** | **VCC encoder (3.3–5V)** | 3.3V — **không phải GND** |
| Vàng | C2 (encoder pha B) | Chân pha B (xem 1.3) |
| Xanh lá | C1 (encoder pha A) | Chân pha A (xem 1.3) |
| **Xanh dương** | **GND encoder** | GND chung |

Hai điểm dễ nhầm đã xác nhận từ ảnh chụp mạch thật: dây **đen là
VCC** của encoder và dây **xanh dương mới là GND** — đấu ngược theo
thói quen "đen = đất" sẽ làm encoder không hoạt động.

### 1.2. PWM và chiều quay (STM32 → TB6612FNG)

| Động cơ | PWM | Timer | IN1 | IN2 | STBY |
|---|---|---|---|---|---|
| M1 | PE9 | TIM1_CH1 (PSC 0, ARR 8399, 20 kHz @168 MHz) | PB0 | PB1 | PE0 (TB1) |
| M2 | PE11 | TIM1_CH2 | PE5 | PE6 | PE0 (TB1) |
| M3 | PB14 | TIM12_CH1 (PSC 0, ARR 4199 @84 MHz) | PD8 | PD9 | PE1 (TB2) |
| M4 | PB15 | TIM12_CH2 | PD10 | PD11 | PE1 (TB2) |

Nguồn motor VM của cả hai TB6612 lấy từ rail 6V chung (xem tài
liệu NGUỒN); VCC logic của TB6612 cấp 3.3V.

### 1.3. Encoder

| Động cơ | Kiểu đếm | Pha A (C1) | Pha B (C2) | Ghi chú |
|---|---|---|---|---|
| M1 | Phần cứng TIM3 Encoder Mode TI12 (×4, lọc IC = 4) | PC6 (TIM3_CH1) | PC7 (TIM3_CH2) | Đếm bằng phần cứng, 0% CPU |
| M2 | Phần cứng TIM4 Encoder Mode TI12 (×4, lọc IC = 4) | PD12 (TIM4_CH1) | PD13 (TIM4_CH2) | AF2 |
| M3 | Phần mềm qua EXTI hai sườn, pull-up | PD14 | PD15 | Chung EXTI15_10_IRQn |
| M4 | Phần mềm qua EXTI hai sườn, pull-up | PE12 | PE13 | Chung EXTI15_10_IRQn |

Lý do M3/M4 phải đếm mềm: sau khi TIM1/TIM12 làm PWM và TIM3/TIM4
làm encoder phần cứng thì không còn timer encoder nào trống mà
không xung đột chân (TIM8 trùng PC6/PC7; TIM2/TIM5 chỉ còn các chân
đã dùng cho việc khác). Tải ngắt encoder mềm đo đạc ~14 nghìn sườn/
giây mỗi động cơ ở 300 RPM, chiếm < 1–4% CPU — chấp nhận được.

## 2. Chức năng

- Nhận lệnh tốc độ theo **phần nghìn (permille) có dấu** (−1000…
  +1000; dấu = chiều quay) cho từng động cơ hoặc theo cặp trái/phải,
  chuyển thành PWM + cặp chân chiều trên TB6612FNG.
- Đo tốc độ thực (RPM), tổng số xung, số vòng quay và góc trục của
  từng động cơ từ encoder; phát hiện hai lỗi vận hành: **NO_COUNT**
  (có lệnh chạy nhưng encoder không đếm) và **STALL** (có lệnh lớn
  nhưng trục không quay).
- Trong project hợp nhất: thực thi mẫu tốc độ do bộ điều hướng
  (nav_fsm) quyết định — FORWARD 600‰, WARNING 350‰, AVOID lệch
  150/550‰ giữa hai bên, BLOCKED 0‰ — và cung cấp số liệu
  PWM/RPM/số vòng cho telemetry gửi về dashboard.

## 3. Thuật toán

### 3.1. Ramp PWM mềm (chống sụt áp)

Lệnh `MotorN20_SetPermille()` chỉ đặt **đích**; hàm
`MotorN20_Update()` chạy mỗi 10 ms dịch duty thực áp
(`applied_permille`) về phía đích tối đa **20‰ mỗi nhịp** — tức
0 → 100% trong 0,5 s. Khi đổi chiều, duty phải về 0 rồi chân chiều
mới được lật. Cơ chế này thay vai trò của tụ bulk 1000 µF mà bench
chưa có: dòng đỉnh của 4 động cơ không chồng lên nhau, rail 6V
không sụp gây reset STM32. Bổ trợ: khi chạy đồng bộ, lệnh cho từng
động cơ được phát **so le 150 ms**.

### 3.2. Đo tốc độ và số vòng

- Encoder phần cứng: đọc delta bộ đếm 16-bit của TIM3/TIM4 mỗi nhịp
  cập nhật (xử lý tràn theo modulo 2^16). Encoder mềm: bảng dịch
  trạng thái quadrature 16 ô (chuỗi Gray A sớm pha hơn B:
  00→10→11→01), bước nhảy 2 trạng thái bị loại là nhiễu.
- RPM tính trên **cửa sổ 100 ms** rồi làm mượt EMA; firmware xuất
  `rpm_x10` (RPM × 10) để giữ độ phân giải 0,1 RPM trong log nguyên.
- Số vòng = tổng xung ÷ **CPR** (số xung trên một vòng trục ra).
  CPR mặc định 2800 = 7 xung/kênh × 4 (×4 quadrature) × tỉ số hộp
  số 100:1 — đây là giá trị **tạm tính** vì tỉ số hộp số không in
  trên động cơ; giá trị thật phải hiệu chuẩn (mục 4.3).

### 3.3. Phát hiện lỗi

- **NO_COUNT**: |lệnh| ≥ 25% liên tục 1 giây mà không có xung nào.
- **STALL**: lệnh lớn kéo dài nhưng tốc độ đo ~ 0 (kẹt cơ khí/quá
  tải/nguồn yếu). Cờ lỗi được OR vào cột flags của log CSV và in
  dòng `LOI Mx ...` kèm hướng dẫn kiểm tra.

### 3.4. Bài test theo số vòng cố định (motors_4test v3.2)

Demo tự chạy sau boot 2 s (hoặc bấm phím `t`), dừng theo **số vòng
đếm được** thay vì theo giây: Pha A khởi động từng động cơ ở +50%
đến khi đạt 5.000 vòng; Pha B cả 4 chạy +60%, mỗi động cơ tự dừng
ở 20.000 vòng của riêng nó; Pha C quay ngược −60% thêm 20.000 vòng
để trục về gần vị trí đầu. Mỗi pha có timeout bảo vệ 60 s; động cơ
bị NO_COUNT giữa pha bị dừng sớm và bỏ qua. Hai hằng số
`REV_KHOI_DONG_X1000` / `REV_CHAY_X1000` nằm ở đầu khối demo để
sửa nhanh.

## 4. Cấu hình và firmware

### 4.1. CubeMX

- TIM1 + TIM12: PWM Generation, nguồn xung internal clock (bắt
  buộc khai báo ClockSourceINT trong .ioc, thiếu sẽ lỗi link
  `htim1`/`htim12` không tồn tại).
- TIM3 + TIM4: Encoder Mode TI12, cực tính `TIM_ICPOLARITY_RISING`,
  IC filter = 4.
- PD14/PD15 + PE12/PE13: GPIO_EXTI hai sườn, pull-up; NVIC
  EXTI15_10_IRQn bật.
- Các chân chiều/STBY: GPIO Output, mức khởi tạo LOW.

### 4.2. File firmware

| File | Vai trò |
|---|---|
| `motor_n20.c/.h` | Driver một động cơ: PWM ramp, chiều, hãm, đo RPM/số vòng, cờ lỗi |
| `soft_enc.c/.h` | Giải mã quadrature bằng phần mềm cho M3/M4 |
| `motors_4test.c/.h` | Bài test bench 4 động cơ (bản v3.2, banner boot `BAN 4 MOTOR v3.2`): demo theo số vòng, phím điều khiển tay, hiệu chuẩn CPR, log CSV 14 cột 5 Hz + dòng `REV` 1 Hz |
| `motors_app.c/.h` | Bản dùng trong project hợp nhất: cùng cách đấu chân, API Set/SetSides/Stop + getter cho telemetry, hàm `MotorsApp_GetBench()` xuất dòng `MOT,...` cho dashboard tổng hợp |

Điều khiển tay qua USART1 115200: phím `0..4` chọn động cơ, `f/r`
thuận/ngược, `s` dừng, `b` hãm, `+/−` chỉnh mức, `t` chạy demo,
`x` xóa bộ đếm, `c` hiệu chuẩn CPR.

### 4.3. Hiệu chuẩn CPR (bắt buộc trước khi tin số vòng)

Chọn 1 động cơ (phím `1..4`), bấm `c`, tắt nguồn VM, **quay tay
trục ra đúng 10 vòng**, bấm `c` lần nữa — firmware in
`CALIB Mx DONE: CPR = N`. Ghi N vào cấu hình (macro
`N20_COUNTS_PER_OUTPUT_REV` hoặc `MotorsApp_SetCpr()` trong bản
hợp nhất). Làm lần lượt cho cả 4 động cơ vì CPR thực tế lệch nhau
vài %.

### 4.4. Đối chiếu khi bench

Theo dõi bằng `dashboard_motor.py` (bài test riêng) hoặc
`dashboard_tong_hop.py` (project hợp nhất): thẻ từng động cơ hiện
RPM, thanh PWM có dấu, số vòng do firmware tính và huy hiệu
NO_COUNT/STALL.

**Trạng thái:** firmware + dashboard đã kiểm chứng bằng biên dịch
sạch (`-Wall -Wextra -Werror`) và mô phỏng phần cứng (cả 12 điểm
dừng theo vòng đều đạt, M1/M2 dừng đúng 14.000 xung cho 5 vòng).
Còn mở: log bench trên phần cứng thật và hiệu chuẩn CPR từng động
cơ — CPR đang là giá trị tạm 2800 nên số vòng vật lý chưa được
khẳng định cho tới khi hiệu chuẩn.

## 5. Sơ đồ khối & lưu đồ

```
Lệnh tốc độ (nav_fsm / dashboard / phím test)
        │
        ▼
┌────────────────┐  đích (permille)  ┌──────────────────┐
│ motors_app /   │ ────────────────► │ motor_n20 (×4)   │
│ motors_4test   │                   │ ramp 20‰/10 ms,  │
└────────────────┘                   │ đổi chiều qua 0  │
        ▲                            └───────┬──────────┘
        │ RPM, số vòng, flags                │ PWM + IN1/IN2
        │                            ┌───────▼──────────┐
        └────────────────────────────│ TB6612FNG (×2)   │
              encoder (TIM3/TIM4     │ VM = 6V          │
              phần cứng, EXTI mềm)   └───────┬──────────┘
                                             ▼
                                     Motor N20 + hộp số
```

Lưu đồ nhịp điều khiển (mỗi 10 ms): đọc lệnh đích → dịch duty
thực áp tối đa 20‰ về phía đích (nếu đổi dấu, bắt buộc qua 0
trước khi lật chân chiều) → cập nhật bộ đếm encoder → tính RPM
trên cửa sổ 100 ms → cập nhật cờ NO_COUNT/STALL → (ở bài test)
kiểm tra điều kiện đạt số vòng của pha demo hiện tại.

## 6. Thông số kỹ thuật & tiêu chí đánh giá

| Hạng mục | Giá trị | Tiêu chí đạt |
|---|---|---|
| Điện áp motor | 6V (rail VM) | — |
| Tốc độ không tải danh định | ~300 RPM tại trục ra | RPM đo được cùng dấu, đúng chiều lệnh |
| PWM | 20 kHz, duty −100…+100% (permille có dấu) | Không nghe tiếng rít, ramp 0→100% trong ~0,5 s |
| CPR | 2800 (tạm) → giá trị hiệu chuẩn riêng từng động cơ | Sau hiệu chuẩn: quay tay 10 vòng, sai lệch số vòng hiển thị ≤ 2% |
| Dừng theo số vòng (bản v3.2) | Khởi động 5.000 vòng, chạy 20.000 vòng | Mọi động cơ tự dừng; độ vượt do ramp được ghi nhận, không tính là lỗi đếm |
| Phát hiện lỗi | NO_COUNT sau 1 s có lệnh mà không xung; STALL khi kẹt | Cờ lỗi xuất hiện trong log/dashboard ≤ ~2 s kể từ sự cố |

## 7. Kết quả kiểm thử

| Bài test | Cách thực hiện | Kết quả |
|---|---|---|
| Biên dịch firmware | `-Wall -Wextra -Werror`, stub HAL | Sạch, không cảnh báo |
| Demo theo số vòng (v3.2) | Mô phỏng phần cứng: encoder chỉ quay khi có lệnh, chiều theo chân IN | **12/12 điểm dừng đạt** (4 động cơ × 3 pha); M1/M2 dừng đúng 14.000 xung cho 5 vòng; M3/M4 dừng ở 14.010 xung (lệch 0,07% do độ hạt nhịp 10 ms); `DEMO DONE` sau 52,8 s mô phỏng; không xuất hiện dòng lỗi |
| Encoder mềm | Cấp chuỗi Gray chuẩn vào EXTI | +28 xung / 7 chu kỳ thuận, quay ngược trả về đúng 0 |
| Bench phần cứng thật | Chạy motors_4test trên bo + dashboard_motor.py | **Chưa có log đạt**: lần thử ghi nhận dashboard không nhận được byte nào (treo ở trạng thái stale → lost); kiểm tra banner sau RESET chưa được báo lại — đang chờ kết quả bench mới |

## 8. So sánh & lựa chọn phương án

- **Encoder phần cứng cho cả 4 (phương án bị loại):** không đủ
  timer không xung đột — TIM8 trùng chân PC6/PC7, TIM2/TIM5 chỉ
  còn chân đã dùng. Chọn lai: 2 phần cứng + 2 phần mềm EXTI, đánh
  đổi < 4% CPU để giữ nguyên tắc "mỗi chân một chức năng".
- **Chống sụt áp:** tụ bulk 1000 µF là giải pháp phần cứng chuẩn
  nhưng bench chưa có linh kiện; ramp mềm + khởi động so le đạt
  cùng mục đích bằng firmware và vẫn giữ lại làm lớp bảo vệ thứ
  hai kể cả khi đã lắp tụ.
- **Tính số vòng trong firmware (v3.1) thay vì để dashboard tự
  chia:** dashboard không cần biết CPR của từng động cơ, tránh
  lệch số liệu khi hai nơi giữ hai bảng CPR khác nhau.
- **TB6612FNG thay vì L298N:** điện áp rơi trên cầu H thấp hơn
  nhiều, hiệu suất cao hơn ở điện áp 6V, kích thước nhỏ — phù
  hợp tải N20.

## 9. An toàn & xử lý sự cố

- STBY của cả hai TB6612 ở mức tắt ngay khi khởi tạo; motor chỉ
  chạy khi có lệnh rõ ràng. Trong project hợp nhất, mất link
  HC-12 quá 2 s ở chế độ Manual thì xe tự dừng (xử lý ở app_main),
  và công tắc dừng vật lý cắt cứng VM độc lập phần mềm (xem tài
  liệu NGUỒN).

| Triệu chứng | Nguyên nhân hay gặp | Xử lý |
|---|---|---|
| Motor quay nhưng dashboard báo NO_COUNT | Dây encoder: đen bị nối xuống GND (đúng phải là VCC), hoặc C1/C2 chưa đúng chân | Đấu lại theo bảng 1.1/1.3 |
| STALL ngay khi tải nhẹ | VM yếu/sụt, hoặc kẹt cơ khí hộp số | Đo VM tại chân TB6612 khi chạy; kiểm tra trục |
| STM32 reset đúng lúc motor khởi động | Đỉnh dòng làm sụp rail, thiếu tụ | Kiểm tra ramp có còn bật; thêm tụ 100 µF tại VM; khởi động so le |
| Dashboard không nhận dữ liệu | main.c thiếu gọi `Motors4Test_RunOnce()`, hoặc sai COM/baud | Nhấn RESET xem có banner `BAN 4 MOTOR v3.2` không — có banner mà không có CSV mới là lỗi vòng lặp |

## 10. Hạn chế & hướng phát triển

- CPR vẫn là giá trị tạm 2800: mọi con số "vòng" mới chỉ đúng
  tương đối cho tới khi hiệu chuẩn từng động cơ trên phần cứng.
- Dừng theo số vòng bị vượt một đoạn bằng quãng đường giảm tốc
  của ramp (~tỉ lệ với tốc độ): đây là đánh đổi có chủ đích để
  bảo vệ nguồn; muốn dừng cứng tại mốc phải chuyển sang hãm điện
  và chấp nhận dòng dội.
- Điều khiển hiện là vòng hở theo duty (permille), chưa có vòng
  kín tốc độ: hai motor cùng lệnh có thể lệch RPM vài %. Brief
  v1.0 không yêu cầu PID; hướng phát triển tự nhiên là thêm bộ
  PI giữ RPM cho Pha chạy thẳng và cơ chế đồng bộ trái/phải.
