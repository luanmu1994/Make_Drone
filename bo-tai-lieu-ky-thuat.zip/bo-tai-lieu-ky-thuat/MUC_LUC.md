# Bộ tài liệu kỹ thuật — Xe mô hình STM32F407

Bốn tài liệu theo bốn phân hệ của project hoàn chỉnh (3 cảm biến
VL53L0X + 4 động cơ N20 + INMP441 + HC-12 trên một bo
STM32F407VET6). Mỗi tài liệu có cùng cấu trúc 10 mục phục vụ viết
báo cáo: **(1) pin mapping, (2) chức năng, (3) thuật toán,
(4) cấu hình và firmware, (5) sơ đồ khối & lưu đồ, (6) thông số
kỹ thuật & tiêu chí đánh giá, (7) kết quả kiểm thử, (8) so sánh &
lựa chọn phương án, (9) an toàn & xử lý sự cố, (10) hạn chế &
hướng phát triển** — và mô tả đúng phần cứng/firmware thực tế
của project, gồm cả các quyết định đã sửa sau khi bench; kết quả
chưa có số liệu phần cứng được ghi rõ "chưa thực nghiệm" thay vì
để trống.

| # | Tài liệu | Phân hệ | Linh kiện chính |
|---|---|---|---|
| 01 | `01_MOTOR.md` | Truyền động | 4× GA12-N20 + encoder XY-N20, 2× TB6612FNG |
| 02 | `02_CAM_BIEN_KHOANG_CACH.md` | Đo khoảng cách | 3× CJVL53L0X V2 (VL53L0X), I2C1 |
| 03 | `03_CAM_BIEN_AM_THANH.md` | Giám sát âm thanh | INMP441, I2S3 + DMA |
| 04 | `04_NGUON.md` | Cấp nguồn | Pin Li-ion 2S, buck 6V/5V, rail 3.3V |

Tài liệu liên quan trong gói `project-hoan-chinh` (thư mục của
goal cảm biến): `PHUONG_AN_1BOARD_4MOTOR_3CAMBIEN.md` (bản đồ tài
nguyên 32 chân toàn hệ thống), `INMP441_I2S3.md`, `HC12.md`,
`HUONG_DAN_PROJECT_HOAN_CHINH.md`.
