# Tài liệu kỹ thuật — PHẦN NGUỒN

> Phân hệ cấp nguồn của xe: một **pin Li-ion 2S** (7.4V danh
> định, 8.4V khi đầy) là nguồn duy nhất, qua các rail hạ áp phục
> vụ 4 vùng tải khác nhau: động lực (motor), logic 3.3V, truyền
> thông 5V và sạc/giám sát. Nguồn là phân hệ có tính quyết định
> tới độ ổn định của mọi phân hệ còn lại — phần lớn các lỗi "ma"
> từng gặp ở bench (reset khi motor khởi động, rớt UART, link
> HC-12 chập chờn) đều truy về nguồn.

## 1. Pin mapping (sơ đồ phân phối)

```
Pin 2S (7.4V) ── cầu chì 5A ── công tắc dừng cứng (cắt VM) ──┬─ Buck → rail 6V ─── VM của 2× TB6612 (4 motor)
                                                             ├─ Rail 5V ────────── HC-12 phía xe
                                                             └─ Vào bo DevEBox ─── LDO 3.3V ── STM32, 3× VL53L0X,
                                                                                     encoder, INMP441, logic TB6612
Điểm sao (star ground): mọi GND hội tụ về một điểm tại đầu ra nguồn.
```

| Điểm nối | Nguồn cấp | Tải | Dòng thiết kế |
|---|---|---|---|
| VM (TB1 + TB2) | Rail 6V từ buck | 4 motor N20 | Buck ≥ 5A; cầu chì 5A; giới hạn bench 3A ở giai đoạn đầu |
| VCC logic TB6612 | 3.3V | Logic của 2 mạch lái | Nhỏ |
| VCC encoder ×4 | 3.3V (dây đen trên harness) | Mạch XY-N20 | Nhỏ |
| VL53L0X ×3 | 3.3V | Cảm biến khoảng cách | ~20 mA/module khi đo |
| INMP441 | 3.3V | Microphone | ~1–2 mA |
| HC-12 phía xe | **5V** | Module truyền thông | Đỉnh ~100 mA theo burst phát |
| STM32 + ngoại vi | 3.3V qua LDO trên bo | Toàn bộ logic | — |

### Các quy tắc đấu nối đã chốt

- **Rail 6V chỉ dành cho VM của motor.** HC-12 chịu tối đa 5.5V —
  cấp 6V vào HC-12 là hỏng module; cấp bằng 3.3V của LDO trên bo
  thì yếu cho các burst phát ~100 mA → link chập chờn. HC-12 bắt
  buộc dùng rail 5V riêng (xem tài liệu HC-12 trong gói project).
- Các tụ lọc đều mắc **song song** ngang rail (không bao giờ nối
  tiếp): **1000 µF** (≥16V) tại điểm phân phối rail 6V; **mỗi
  TB6612 một tụ 100 µF** (≥16V) + 100 nF gốm ngay tại chân VM–GND,
  chân tụ càng ngắn càng tốt (< 2–3 cm); cực (+) của tụ hóa về
  phía VM, vạch (−) về GND — đấu ngược cực tụ có thể phồng/nổ.
- **Star ground**: GND của buck, của 2 TB6612, của bo STM32 và
  của pin chụm về một điểm duy nhất; không nối vòng (ground loop)
  qua đường tín hiệu mảnh.
- **Công tắc dừng vật lý cắt cứng đường VM** (và firmware đọc
  trạng thái qua chân PE2 kiểu pull-up để khóa trạng thái SAFE):
  việc dừng xe không phụ thuộc phần mềm — yêu cầu an toàn của
  Brief.

## 2. Chức năng

- Cung cấp 3 rail điện áp đúng định mức cho từng nhóm tải từ một
  pin duy nhất, với dự trữ dòng cho các đỉnh tải khi 4 motor khởi
  động/đảo chiều đồng thời.
- Bảo vệ: cầu chì 5A chống chập/quá tải kéo dài; tụ lọc chống
  sụt áp tức thời; công tắc dừng cắt động lực độc lập phần mềm.
- Là điểm can thiệp đầu tiên khi chẩn đoán lỗi hệ thống: điện áp
  tại chân module (không phải tại đầu nguồn) là số liệu bắt buộc
  trong mọi quy trình debug của project (ví dụ mục kiểm tra VCC
  3.2–3.4V tại chân VL53L0X khi INIT FAIL).

## 3. Thuật toán (các cơ chế vận hành liên quan đến nguồn)

Phân hệ nguồn không có thuật toán riêng trên vi điều khiển, nhưng
ba cơ chế của hệ thống được thiết kế xoay quanh đặc tính nguồn:

### 3.1. Bù thiếu tụ bulk bằng phần mềm (firmware motor v3)

Bench hiện có tụ 100 µF nhưng **chưa có tụ 1000 µF** cho rail.
Thay vì chờ linh kiện, firmware bù bằng hai cơ chế (chi tiết ở
tài liệu MOTOR): **ramp PWM mềm** — duty tăng tối đa 20‰/10 ms
nên dòng khởi động dàn trải trong 0,5 s thay vì đánh đỉnh tức
thời; và **khởi động so le 150 ms** giữa các động cơ để đỉnh
dòng không chồng nhau. Biện pháp tạm thời phía phần cứng: mắc
song song nhiều tụ 100 µF sẵn có (4 chiếc ≈ 400 µF) tại điểm
phân phối cũng cải thiện đáng kể. Triệu chứng cho biết đã đến
lúc bắt buộc phải có tụ: STM32 reset / rớt UART / đếm encoder
nhảy loạn **đúng tại thời điểm** motor khởi động, đảo chiều
hoặc hãm.

### 3.2. Trình tự lên nguồn và giới hạn dòng bench

- Giai đoạn test đầu: dùng nguồn bench có giới hạn dòng đặt
  **3A**, dây ngắn — bài test 1 motor có thể chạy không cần tụ
  phụ; thêm tụ 100 µF tại VM của mạch lái đang test ngay khi
  thấy triệu chứng ở 3.1.
- Khi chuyển sang pin 2S qua buck (chạy 4 motor): tụ theo mục 1
  là bắt buộc, cầu chì 5A lắp trước khi cấp điện lần đầu.

### 3.3. Giám sát an toàn phía firmware

`app_main` đọc chân PE2 mỗi vòng lặp: công tắc dừng đang nhấn →
khóa trạng thái SAFE (chỉ mở khi công tắc nhả + có lệnh START
mới), đồng thời phần cứng đã cắt VM nên motor mất điện ngay cả
khi firmware treo. Đây là lớp an toàn hai tầng: phần cứng cắt
điện, phần mềm khóa trạng thái.

## 4. Cấu hình và firmware

- Không có cấu hình CubeMX cho phân hệ nguồn, trừ chân liên quan:
  **PE2 = GPIO Input, pull-up** (đọc công tắc dừng).
- Các thông số phải khớp giữa phần cứng và tính toán firmware:
  điện áp VM 6V ↔ định mức motor 6V (~300 RPM tại điện áp này —
  mọi tính toán RPM/CPR trong tài liệu MOTOR đều theo mốc này);
  nếu thay đổi điện áp rail, toàn bộ mốc tốc độ thay đổi theo.
- Kiểm tra định kỳ trên bench: đo điện áp tại VM của từng TB6612
  khi 4 motor chạy đồng thời (sụt dưới ~5.5V là dấu hiệu buck yếu
  hoặc dây nguồn mảnh); đo 3.3V tại chân cảm biến xa nhất.

**Trạng thái:** sơ đồ phân phối + quy tắc đấu nối đã chốt và áp
dụng thống nhất trong mọi gói bench (1 motor, 4 motor, hợp nhất).
Phần cứng nguồn hoàn chỉnh (buck 2S → 6V ≥ 5A, tụ 1000 µF, cầu
chì, công tắc dừng) chưa được lắp và đo kiểm trọn vẹn trên xe —
các bài bench tới nay chạy bằng nguồn bench giới hạn dòng; việc
còn mở là lắp rail pin thật và đo sụt áp khi 4 motor chạy đồng
thời theo mục 4.

## 5. Sơ đồ khối & lưu đồ

Sơ đồ khối của phân hệ chính là sơ đồ phân phối ở mục 1. Lưu đồ
lên nguồn an toàn trên bench:

```
Cắm nguồn bench (giới hạn 3A) ──► đo rail khi chưa tải ──► cấp cho logic,
kiểm tra banner/log ──► bật VM, chạy 1 motor ──► chạy 4 motor,
đo sụt áp tại VM từng TB6612 ──► đạt mới chuyển sang pin 2S qua buck
```

Lưu đồ xử lý sự cố sụt áp: thấy reset/rớt link đúng lúc motor
khởi động → đo VM tại chân mạch lái *trong lúc* khởi động → nếu
sụt sâu: tăng tụ tại VM, kiểm tra độ dài/tiết diện dây nguồn →
nếu vẫn sụt: kiểm tra buck/nguồn có đủ dòng đỉnh không.

## 6. Thông số kỹ thuật & tiêu chí đánh giá

| Hạng mục | Giá trị | Tiêu chí đạt |
|---|---|---|
| Pin | Li-ion 2S: 8.4V đầy / 7.4V danh định | — |
| Rail motor | 6V từ buck ≥ 5A, cầu chì 5A | VM đo tại TB6612 không sụt dưới ~5.5V khi 4 motor chạy đồng thời và khi đảo chiều |
| Rail logic | 3.3V | Tại chân cảm biến xa nhất: 3.2–3.4V |
| Rail HC-12 | 5V riêng, tụ 100 µF + 100 nF tại module | Link không rớt khi motor khởi động (đối chiếu đèn link trên dashboard) |
| Ổn định hệ thống | — | Không reset STM32, không rớt UART khi 4 motor khởi động đồng loạt từ trạng thái dừng |

## 7. Kết quả kiểm thử

| Bài test | Kết quả |
|---|---|
| Bench 1 motor bằng nguồn bench giới hạn dòng, dây ngắn | Chạy được không cần tụ phụ — đúng dự đoán mục 3.2 (tụ chỉ bắt buộc khi có triệu chứng sụt) |
| Cơ chế bù bằng firmware (ramp mềm + so le) | Đã kiểm chứng ở tầng firmware/mô phỏng (xem tài liệu MOTOR mục 7): duty tăng đều 0→100% trong 0,5 s, không có bước nhảy dòng |
| Lắp rail pin 2S → buck 6V hoàn chỉnh và đo sụt áp | **Chưa thực hiện** — phần cứng nguồn hoàn chỉnh chưa lắp; các con số ở mục 6 hiện là tiêu chí thiết kế, chưa phải số đo |

## 8. So sánh & lựa chọn phương án

- **Buck về 6V vs cấp thẳng 2S (7.4–8.4V) cho VM:** TB6612FNG
  chịu được tới 15V nên phương án cấp thẳng "chạy được", nhưng
  motor định mức 6V sẽ quay nhanh hơn danh định ~25–40%, mọi
  mốc RPM/CPR trong firmware đều lệch theo điện áp pin và tuổi
  thọ motor giảm. Chọn buck 6V để giữ đúng điểm làm việc đã
  hiệu chuẩn.
- **Nguồn chung một pin vs pin riêng cho logic:** một pin + các
  rail hạ áp giúp hệ thống gọn và có một điểm cắt nguồn duy
  nhất cho an toàn; cái giá là phải quản lý nhiễu/sụt chung —
  xử lý bằng star ground + tụ + ramp (mục 1, 3). Chọn nguồn
  chung có kỷ luật đấu nối thay vì hai pin.
- **Tụ bulk phần cứng vs bù phần mềm:** lý tưởng là cả hai;
  hiện có bù phần mềm trước (đã chạy), tụ 1000 µF bổ sung sau
  khi có linh kiện — thứ tự này giúp bench không bị chặn tiến
  độ vì một con tụ.

## 9. An toàn & xử lý sự cố

- **Cắt cứng VM bằng công tắc dừng** là lớp an toàn độc lập:
  kể cả khi firmware treo, motor vẫn mất điện. PE2 chỉ là kênh
  để firmware *biết* trạng thái công tắc, không nằm trên đường
  cắt điện.
- Cầu chì 5A bảo vệ đường pin; lắp trước lần cấp điện đầu tiên
  bằng pin thật.
- Đảo cực pin là lỗi chưa có bảo vệ phần cứng: bắt buộc kiểm
  tra cực tính bằng đồng hồ trước khi cắm; tụ hóa đấu ngược cực
  có thể phồng/nổ — đã quy định ký hiệu cực trong mục 1.
- Không sạc pin 2S ngay trên xe khi hệ thống đang nối (ngoài
  phạm vi thiết kế hiện tại).

| Triệu chứng | Nguyên nhân hay gặp | Xử lý |
|---|---|---|
| Reset/rớt UART đúng lúc motor start/đảo chiều | Sụt rail do đỉnh dòng | Thêm tụ tại VM; xác nhận ramp mềm đang bật; đo VM lúc sự cố |
| Link HC-12 chập chờn khi xe chạy | HC-12 cấp bằng 3.3V yếu, burst phát làm sụt | Chuyển sang rail 5V + tụ 100 µF tại module |
| Một TB6612 nóng bất thường | Quá tải/kẹt motor của kênh đó, hoặc VM cao hơn 6V | Kiểm tra rail có đúng 6V không; đối chiếu cờ STALL |

## 10. Hạn chế & hướng phát triển

- Tụ 1000 µF cho rail chưa có: hệ thống đang dựa vào bù phần
  mềm; khi lên xe chạy tải thật, vẫn nên lắp đủ tụ theo mục 1
  để có biên an toàn phần cứng.
- Chưa có giám sát điện áp pin trong firmware: xe không biết
  pin sắp cạn, và pin Li-ion xả sâu sẽ hỏng. Hướng phát triển:
  thêm kênh ADC đo điện áp pin qua cầu phân áp, cảnh báo về
  dashboard và tự dừng khi dưới ngưỡng (~6.4V cho 2S).
- Chưa có bảo vệ đảo cực và chưa có mạch sạc tích hợp. Hướng
  phát triển: MOSFET bảo vệ đảo cực ở đầu vào, cân nhắc module
  quản lý pin 2S có bảo vệ quá xả.
- Chưa có số đo sụt áp thực tế trên rail pin: bài đo ở mục 7 là
  việc đầu tiên phải làm khi lắp xong phần cứng nguồn.
