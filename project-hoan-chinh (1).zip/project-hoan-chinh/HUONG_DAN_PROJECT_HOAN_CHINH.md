# Project hoàn chỉnh — 3× VL53L0X + 4× motor N20 + HC-12/dashboard

Phương án theo `PHAN_TICH_PROJECT_HOAN_CHINH.md` (mục 4.2 kiến trúc,
4.3 FSM, 5 telemetry, 7 an toàn). Phần INMP441 (mục 6 của tài liệu đó)
**đã ghép xong (G5, 11/11/2026)**: `sound_app` thu I2S3+DMA và tính
mức âm 0–100, `sos_detect` phát hiện mẫu tiếng kêu cứu — cả hai hợp
nhất vào 2 trường sound sẵn có của telemetry, dashboard không sửa.
Chi tiết ở mục cập nhật 2026-11-11 (G5) cuối tài liệu này.

## File trong gói

Giữ nguyên **không sửa một dòng** từ hai bài test riêng đã kiểm chứng:

| File | Nguồn |
|---|---|
| `vl53l0x_min.c/.h` | Driver ST-flow v5 bản nhiều thiết bị + chẩn đoán `init_stage`/BUS CHECK |
| `vl53l0x_3sensor.c/.h` | Median trượt §4.2 (Step/Get/IsStale/LostCount/Recover) |
| `motor_n20.c/.h` | Driver motor v3 (ramp mềm) |
| `soft_enc.c/.h` | Encoder mềm EXTI cho M3/M4 |

Viết mới cho bản hợp nhất:

| File | Việc |
|---|---|
| `motors_app.c/.h` | Đúng cấu hình chân của `motors_4test` v3.1 nhưng bỏ demo/phím, thay bằng API Set/SetSides/Stop cho FSM và telemetry |
| `nav_fsm.c/.h` | Luật §4.3: fail-safe (FRONT stale > 1 s hoặc mất ≥ 2 cảm biến → BLOCKED), ngưỡng 1000/500/250, so 2 bên chênh 100 mm, dwell AVOID 500 ms, mẫu PWM FORWARD +600 / WARNING +350 / AVOID 150–550 / BLOCKED 0 (‰) |
| `telemetry.c/.h` | Khung AA55 + CRC16-Modbus trên USART2 9600, payload 24 byte đúng `dashboard.py`, nhận lệnh 0x10 (START/STOP/MANUAL/AUTO/SET_PWM) và trả ACK 0x7F |
| `app_main.c/.h` | Vòng điều phối: Step cảm biến → dịch vụ motor 10 ms (bù nhịp ramp) → xử lý lệnh → watchdog link Manual 2 s → FSM 10 Hz → telemetry + CSV debug 5 Hz; công tắc dừng PE2 khóa SAFE; tự thử khôi phục cảm biến offline mỗi 10 s khi đang dừng (tối đa 3 lần/con) |
| `main_test_snippet.c` | Đoạn dán vào main.c |

Ghép thêm ở bước G5 (11/11/2026):

| File | Việc |
|---|---|
| `sos_detect.c/.h` | Module phát hiện mẫu tiếng kêu cứu (DSP rule-based) — chép **nguyên văn** từ gói `phat-hien-keu-cuu` đã kiểm chứng, không sửa một dòng |
| `sound_app.c/.h` | Thu INMP441: I2S3 Master Receive + DMA1 Stream 0 Ch 0 Circular, buffer 6400 word32, xử lý theo khối 100 ms (callback nửa/đầy buffer): trích slot LEFT → tính mức âm 0–100 (RMS sau trừ DC, báo động mức > 80 giữ 1,5 s) → `SOS_Feed()`; hai báo động hợp nhất vào `sound_alarm` |

Đã kiểm chứng trước khi giao: biên dịch + link sạch toàn bộ 8 file C
(-Wall -Wextra -Werror, stub HAL); 15 ca test logic FSM đạt (gồm dwell
và fail-safe phá dwell); khung telemetry 0x01 do firmware phát được
chính code giải mã của `dashboard.py` đọc đúng từng trường và CRC, và
ngược lại khung lệnh do dashboard dựng được firmware phân tích đúng.
Sau khi ghép G5: biên dịch + link sạch **toàn bộ 11 file C** với
`-std=c99 -Wall -Wextra -Werror`; harness chạy qua đúng callback DMA
thật của `sound_app` đạt cả 3 ca (im lặng → mức 0, không báo; 4 burst
giọng 300 ms → sự kiện SOS qua `sound_app`, báo động bật; tiếng lớn
liên tục → mức 94, báo động mức bật); bộ test SOS độc lập chạy lại
trên bản `sos_detect.c` trong gói này vẫn đạt toàn bộ.

## Cách dựng project trong CubeMX

Mở project **Motors_4Test** đã chạy được (phần motor là phần cấu hình
phức tạp nhất và đã gỡ xong lỗi .ioc) rồi **Save As** thành project mới,
thêm các ngoại vi còn thiếu theo checklist:

- [ ] **I2C1**: PB6 = SCL, PB7 = SDA; Speed **100 kHz** (Standard Mode)
      — 3 module song song không dùng 400 kHz, xem mục xử lý INIT FAIL
      trong hướng dẫn bản rolling.
- [ ] **PC0, PC1, PC2**: GPIO_Output, mức ban đầu **LOW** (XSHUT của
      FRONT/LEFT/RIGHT).
- [ ] **USART2**: PA2 = TX, PA3 = RX, **9600** 8N1 (HC-12); bật ngắt
      USART2 global interrupt.
- [ ] **PE2**: GPIO_Input, Pull-up (công tắc dừng vật lý, nhấn = nối GND).
- [ ] **I2S3** (âm thanh, G5 đã ghép — xem `INMP441_I2S3.md`): SPI3
      Mode = I2S, Master Receive, Philips, 24 bits on 32 bits frame,
      16 kHz, **Master Clock Output = Disable**; DMA SPI3_RX =
      **DMA1 Stream 0, Channel 0, Circular** + bật NVIC DMA1_Stream0.
      Generate xong rà `gpio.c`: PC10/PA4/PC12 = AF6 và **PC7 vẫn
      AF2** (MCK bật nhầm sẽ chiếm PC7, mất kênh B encoder M1).
- [ ] Giữ nguyên từ project motor: TIM1 (PE9/PE11 PWM), TIM12 (PB14/PB15
      PWM), TIM3 (PC6/PC7 encoder), TIM4 (PD12/PD13 encoder), EXTI
      PD14/PD15 + PE12/PE13 cả hai cạnh + NVIC EXTI15_10, USART1 115200.
- [ ] Generate xong kiểm tra: `tim.c` có đủ `MX_TIM1/3/4/12_Init`,
      `usart.c` có `MX_USART1/2_UART_Init`, `gpio.c` **không** đặt PC6
      sang AF5 (PC6 phải là AF2 của TIM3).

Sau đó thêm 11 file .c vào `Core/Src`, 10 file .h vào `Core/Inc`
(gồm cả snippet để tham chiếu), dán 3 đoạn theo `main_test_snippet.c`,
và **xóa** `motors_4test.c/.h` khỏi project hợp nhất (bản hợp nhất dùng
`motors_app` thay thế — hai file cùng định nghĩa callback EXTI sẽ lỗi
trùng lặp nếu để cả hai).

## Thứ tự bring-up (đừng nhảy bước)

1. **Chỉ cấp nguồn + mở USART1**: log boot phải có banner project,
   BUS CHECK, 3 dòng INIT của cảm biến (nếu còn FAIL thì xử lý theo
   bảng stage trong hướng dẫn bản rolling — lỗi đó không liên quan
   phần motor), dòng CSV 5 Hz bắt đầu chạy, cuối là
   `APP: san sang - MANUAL, chua chay`.
2. **Test FSM bằng tay** (chưa cần dashboard): che cảm biến trước ở
   các khoảng cách — chưa START nên motor không quay, nhưng mở
   dashboard_3sensor (USART1, 115200) vẫn xem được median/zone như cũ
   vì CSV debug vẫn in.
3. **Nối HC-12, mở dashboard.py** (9600): khung telemetry 5 Hz phải
   lên (3 khoảng cách, FSM, PWM/RPM = 0). Bấm AUTO rồi START với mô
   hình kê cao (bánh không chạm đất): che cảm biến trước xuống
   60 cm → WARNING (PWM 35%), 40 cm → AVOID theo phía thoáng hơn,
   20 cm → BLOCKED dừng. Bấm STOP phải dừng trong < 100 ms.
4. **Manual**: bấm MANUAL, START, kéo PWM trên dashboard — 4 motor
   quay tiến theo % đã đặt. Tắt dashboard (hoặc rút HC-12) quá 2 giây
   → motor tự dừng, log có dòng `mat link HC-12 o Manual > 2 s`.
   Lưu ý giới hạn đã nêu trong tài liệu phân tích: SET_PWM của
   dashboard là **% không dấu** nên Manual chỉ lái tiến theo độ lớn —
   muốn lái lùi/rẽ trong Manual cần mở rộng giao thức ở phía dashboard.
5. **Công tắc dừng**: đang chạy thì nhấn công tắc PE2 → motor dừng và
   START bị từ chối (ACK status 1) cho tới khi nhả công tắc.
6. Cho xuống đất chạy thử trong phòng, đối chiếu 9 tiêu chí nghiệm thu
   của Brief.

## Còn để ngỏ

- CPR của 4 encoder vẫn là mặc định 2800 — RPM/số vòng trên dashboard
  chỉ đúng sau khi hiệu chuẩn ở bài test motor riêng; ghi 4 con số thật
  vào `MotorsApp_SetCpr()` trong `AppMain_Init` hoặc sửa mặc định.
- Âm thanh (G5) đã ghép (xem mục cập nhật cuối tài liệu) nhưng thang
  0–100 đang dùng hệ số **tạm** trong `sound_app.h`
  (`SOUND_DBFS_AT_0/100`) — phải hiệu chuẩn 3 trạng thái trên xe thật
  (tĩnh / motor chạy không tải / có tải) rồi mới tin ngưỡng 80.

## Phương án tài nguyên 1 board

Xem `PHUONG_AN_1BOARD_4MOTOR_3CAMBIEN.md` + `so_do_tai_nguyen.png` trong gói này: bản đồ 32 chân / 4 timer / ngắt / DMA chứng minh 4 motor + 3 cảm biến chạy đồng thời không chiếm tài nguyên của nhau, kèm ngân sách CPU và giới hạn thật.

## Cập nhật 2026-11-09: dòng MOT + dashboard tổng hợp

`app_main` nay in thêm trên USART1 mỗi 200 ms một dòng
`MOT,p1,r1,v1,f1,...` (mỗi motor: PWM thực áp phần nghìn, RPM×10, số
vòng×1000, flags — đều có dấu) ngay sau dòng CSV cảm biến, để bench có
dây xem được cả motor trên cùng một cổng. Dashboard đọc dòng này là
`dashboard_tong_hop.py` trong gói **dashboard-tong-hop** (3 thẻ cảm
biến + 4 thẻ motor + FSM/APP trên một màn hình). Giao thức HC-12 và
dashboard.py không thay đổi.

## Cập nhật 2026-11-10: INMP441 dùng I2S3

Khi làm bước G5 (âm thanh), đấu INMP441 theo `INMP441_I2S3.md` /
`so_do_inmp441_i2s3.png` trong gói này: I2S3 Master Receive,
SCK=PC10, WS=PA4, SD=PC12, MCK tắt, DMA1 Stream 0 Ch 0 — thay cho
phương án I2S2 đã nêu ở các mục trước.

## Cập nhật 2026-11-11: phần module HC-12

Đấu dây và cấu hình HC-12 (cả phía xe lẫn phía PC) xem `HC12.md` /
`so_do_hc12.png` trong gói này. Điểm cần nhớ: cấp 5V (không dùng rail
6V của motor), tụ 100 µF tại VCC module phía xe, hai module cấu hình
AT giống hệt nhau (9600 / C001 / FU3 / P8 — mặc định xuất xưởng đã
đúng), SET để hở khi chạy. Phần giao thức AA55 trong telemetry.c và
dashboard.py đã có sẵn và đã kiểm chứng hai chiều.

## Cập nhật 2026-11-11: ghép phân hệ âm thanh + SOS vào project (G5)

Theo yêu cầu "ghép vào sản phẩm hoàn chỉnh", phân hệ âm thanh đã vào
project thay vì nằm ở gói rời `phat-hien-keu-cuu`:

- `sos_detect.c/.h` nằm trong `Core/Src` + `Core/Inc`, **nguyên văn**
  bản đã kiểm chứng ở gói rời (cùng md5) — nhận diện của file là dòng
  đầu `sos_detect.h`. Module tránh vật cản rời không cần ghép: luật
  của nó đã chính là `nav_fsm.c` đang chạy trong project.
- `sound_app.c/.h` (dòng nhận diện `BAN GHEP SOS v1` ở đầu file) là
  lớp thu: `SoundApp_Init()` được `AppMain_Init()` gọi sau
  `MX_I2S3_Init()`; DMA circular tự chạy nền, callback nửa/đầy buffer
  (định nghĩa duy nhất trong `sound_app.c`) xử lý từng khối 100 ms.
  Nếu DMA/I2S3 chưa chạy, log báo một dòng và mọi phân hệ khác chạy
  bình thường — âm thanh chỉ giám sát, không điều khiển.
- `app_main` nay điền telemetry từ `sound_app`: `sound` = mức 0–100,
  `sound_alarm` = (mức > 80) HOẶC (SOS báo). Khi SOS kích hoạt,
  USART1 in `SOS: NGHI NGO TIENG KEU CUU (su kien #N, nen ... dBFS)`;
  mỗi 200 ms có thêm dòng bench
  `SND,muc,bao_muc,bao_sos,su_kien_sos,nen_dBFSx10,chay_dma` ngay sau
  dòng `MOT,` để hiệu chuẩn (dashboard cũ bỏ qua dòng lạ này).
- Banner boot đổi thành `... + INMP441/SOS ===` và có thêm dòng
  `APP: SOUND INMP441 I2S3 + DMA + SOS da chay` khi DMA lên — lấy
  hai dòng này làm dấu kiểm chứng file đã chép đúng bản mới.
- Chưa kiểm chứng trên phần cứng thật (đúng như trạng thái G5 trước
  đây): cần log boot có dòng SOUND ở trên + dòng `SND,...` chạy số
  khi có tiếng động, sau đó mới hiệu chuẩn thang 0–100 và ngưỡng SOS
  bằng tiếng kêu thật trên xe.
