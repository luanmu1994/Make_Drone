/**
 ******************************************************************************
 * @file    vl53l0x_min.h  (BAN 3 CAM BIEN - ST-FLOW v5 MULTI)
 * @brief   Driver VL53L0X cap thanh ghi, DA THIET BI - KHONG dung ST API.
 *          Cung loi do + hieu chuan nhu ban ST-FLOW v5 da chung minh tren
 *          1 cam bien (gom PerformRefSpadManagement + PerformRefCalibration
 *          port tu ST), nhung trang thai cua moi cam bien nam trong
 *          VL53M_Dev rieng nen chay duoc nhieu cam bien tren cung I2C1.
 *
 *          Mo hinh dung:
 *            - app tao 1 VL53M_Dev cho moi cam bien, dat xshut_port/pin
 *              truoc, giu ca 3 XSHUT o muc THAP
 *            - goi VL53M_Init(&dev, dia_chi_moi) lan luot tung cam bien:
 *              ham tu keo XSHUT len, init o dia chi mac dinh 0x29, roi
 *              gan dia chi moi (0x30/0x31/0x32) cho cam bien do
 *            - do bang VL53M_ReadMm(&dev, &mm)
 ******************************************************************************
 */
#ifndef VL53L0X_MIN_H
#define VL53L0X_MIN_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

#define VL53M_DEFAULT_ADDR7   0x29U   /* dia chi mac dinh khi boot          */
#define VL53M_TIMEOUT_MS      500U
#define VL53M_NO_TARGET_MM    8190    /* >= gia tri nay coi nhu khong co vat */

/* Trang thai 1 cam bien. App chi can dat xshut_port/xshut_pin truoc khi
   goi VL53M_Init; moi truong con lai do driver quan ly (memset khi init). */
typedef struct {
    uint8_t       addr7;          /* dia chi I2C 7-bit hien tai           */
    GPIO_TypeDef *xshut_port;     /* app dat: GPIOC                       */
    uint16_t      xshut_pin;      /* app dat: GPIO_PIN_0/1/2              */
    uint8_t       init_stage;     /* Init dung o buoc nao (0 = OK) - xem
                                     bang stage trong huong dan           */
    uint8_t       id_byte;        /* byte Model ID doc duoc (0xFF = chua
                                     doc duoc lan nao)                    */
    /* --- noi bo driver --- */
    uint8_t  stop_variable;
    uint8_t  spad_count;
    uint8_t  spad_aperture;
    uint8_t  seq_config;
    uint8_t  good_map[6];
    bool     mgmt_ok;
    uint32_t mgmt_count;
    uint8_t  mgmt_aperture;
    uint16_t mgmt_peak;
    bool     refcal_ok;
    uint8_t  vhv_settings;
    uint8_t  phase_cal;
    uint8_t  last_error;
    uint16_t last_raw;
    uint8_t  last_status;
    uint16_t last_signal;
    uint16_t last_ambient;
    uint16_t last_spad_rtn;
    uint8_t  stage;
    uint8_t  start_reg;
    uint8_t  int_reg;
} VL53M_Dev;

/* Khoi tao 1 cam bien: keo XSHUT cua no len (cac cam bien khac phai dang
   tat), init o 0x29, gan dia chi new_addr7, chay full ST-flow (tuning,
   seq 0xE8, RefSpadManagement, RefCalibration). Tra ve false neu khong
   thay cam bien / loi I2C / loi khoi tao. */
bool VL53M_Init(VL53M_Dev *dev, uint8_t new_addr7);

/* Tat cam bien bang XSHUT (giu muc thap). */
void VL53M_Shutdown(VL53M_Dev *dev);

/* Do 1 lan single-shot. Thanh cong: *out_mm = khoang cach mm (1..8189).
   That bai (I2C loi / timeout / loi laser / khong co vat): false. */
bool VL53M_ReadMm(VL53M_Dev *dev, int32_t *out_mm);

/* Chan doan lan do / init gan nhat cua 1 cam bien (giong ban v5). */
uint8_t  VL53M_LastDeviceError(const VL53M_Dev *dev);
uint16_t VL53M_LastRawMm(const VL53M_Dev *dev);
uint8_t  VL53M_LastFailStage(const VL53M_Dev *dev);
uint8_t  VL53M_LastStartReg(const VL53M_Dev *dev);
uint8_t  VL53M_LastIntReg(const VL53M_Dev *dev);
uint8_t  VL53M_SpadCount(const VL53M_Dev *dev);
uint8_t  VL53M_SpadIsAperture(const VL53M_Dev *dev);
uint8_t  VL53M_SeqConfig(const VL53M_Dev *dev);
uint8_t  VL53M_LastStatusByte(const VL53M_Dev *dev);
uint16_t VL53M_LastSignalRaw(const VL53M_Dev *dev);
uint16_t VL53M_LastAmbientRaw(const VL53M_Dev *dev);
uint16_t VL53M_LastSpadRtnRaw(const VL53M_Dev *dev);
bool     VL53M_MgmtOk(const VL53M_Dev *dev);
uint32_t VL53M_MgmtCount(const VL53M_Dev *dev);
uint8_t  VL53M_MgmtAperture(const VL53M_Dev *dev);
uint16_t VL53M_MgmtPeakRaw(const VL53M_Dev *dev);
bool     VL53M_RefCalOk(const VL53M_Dev *dev);
uint8_t  VL53M_VhvSettings(const VL53M_Dev *dev);
uint8_t  VL53M_PhaseCal(const VL53M_Dev *dev);
void     VL53M_GetGoodMap(const VL53M_Dev *dev, uint8_t out[6]);

/* Chan doan init: buoc Init dung lai (0 = OK) va byte ID doc duoc. */
uint8_t VL53M_InitStage(const VL53M_Dev *dev);
uint8_t VL53M_IdByte(const VL53M_Dev *dev);

/* Kiem tra nhanh co thiet bi nao ACK o dia chi 7-bit nay khong
   (HAL_I2C_IsDeviceReady) - dung cho BUS CHECK luc boot. */
bool VL53M_ProbeAddr(uint8_t addr7);

bool VL53M_RdReg(VL53M_Dev *dev, uint8_t reg, uint8_t *val);
bool VL53M_RdReg16(VL53M_Dev *dev, uint8_t reg, uint16_t *val);
bool VL53M_RdBuf(VL53M_Dev *dev, uint8_t reg, uint8_t *buf, uint16_t n);

#endif /* VL53L0X_MIN_H */
