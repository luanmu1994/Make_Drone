/* BAN GHEP SOS v1 - nhan dien file: dong nay phai o dau sound_app.h
 *
 * PHAN HE AM THANH CUA PROJECT HOAN CHINH (buoc G5, da ghep):
 *   INMP441 --I2S3 Master Receive--> DMA1 Stream 0 Ch 0 (Circular)
 *   --> sound_app (file nay) --> 2 dau ra:
 *       (1) muc am 0-100 + bao dong muc > 80 (yeu cau Brief, giu
 *           nguyen truong sound/sound_alarm cua telemetry);
 *       (2) sos_detect: phat hien MAU TIENG KEU CUU (DSP rule-based)
 *           -> cung hop nhat vao sound_alarm, dashboard khong sua.
 *
 * Dau noi (xem INMP441_I2S3.md): SCK=PC10, WS=PA4, SD=PC12 (AF6),
 * L/R = GND (kenh LEFT), MCK DISABLE (PC7 la encoder M1), Fs 16 kHz,
 * Philips 24-bit tren khung 32-bit.
 *
 * Nguyen tac an toan (tai lieu ky thuat 03, muc 9): phan he am thanh
 * CHI GIAM SAT, khong dieu khien. Neu I2S3/DMA chua chay (chua cau
 * hinh CubeMX, loi khoi dong DMA...) thi SoundApp_Init tra ve 0,
 * muc am giu 0, cac phan he khac chay binh thuong.
 *
 * HIEU CHUAN BAT BUOC truoc khi tin thang 0-100: hai hang so
 * SOUND_DBFS_MIN/MAX duoi day la GIA TRI TAM (phong yen -> muc thap,
 * tieng het sat mic -> gan 100). On tu than cua 4 motor lam nen am
 * tang: phai do nen 3 trang thai (tinh / motor chay khong tai /
 * chay co tai) tren xe that roi sua 2 hang so nay sao cho xe chay
 * binh thuong nam duoi nguong bao dong 80 mot khoang an toan.
 */
#ifndef SOUND_APP_H
#define SOUND_APP_H

#include <stdint.h>

/* --- Tinh chinh thang muc am 0-100 (sua o day sau hieu chuan) --- */
#define SOUND_DBFS_AT_0      (-50.0f)  /* RMS (dBFS) tuong ung muc 0   */
#define SOUND_DBFS_AT_100    (-10.0f)  /* RMS (dBFS) tuong ung muc 100 */
#define SOUND_ALARM_LEVEL    80u       /* nguong Brief: muc > 80       */
#define SOUND_ALARM_HOLD_MS  1500u     /* giu bao dong muc de dashboard
                                          khong nhap nhay theo khoi 100 ms */

typedef struct {
    uint8_t  running;       /* 1 = DMA dang thu duoc                  */
    uint16_t level;         /* muc am 0-100 (cho telemetry)           */
    uint8_t  level_alarm;   /* 1 = muc > 80 dang trong thoi gian giu  */
    uint8_t  sos_alarm;     /* 1 = SOS dang giu bao dong keu cuu      */
    uint32_t sos_events;    /* tong so su kien keu cuu (sos_detect)   */
    float    sos_floor_dbfs;/* nen on dai giong SOS dang hoc (dBFS)   */
    uint32_t blocks;        /* so khoi 100 ms da xu ly (debug)        */
} sound_app_stats_t;

/* Khoi dong thu am: SOS_Init + bat DMA vong tron tren I2S3.
 * Goi 1 lan trong AppMain_Init(), SAU MX_I2S3_Init().
 * Tra ve 1 neu DMA chay, 0 neu khong (app chinh khong bi anh huong). */
uint8_t SoundApp_Init(void);

uint16_t SoundApp_Level(void);      /* 0-100 */
uint8_t  SoundApp_Alarm(void);      /* level_alarm OR sos_alarm */
uint8_t  SoundApp_SosAlarm(void);
void     SoundApp_GetStats(sound_app_stats_t *out);

#endif /* SOUND_APP_H */
