/* PROJECT HOAN CHINH - vong dieu phoi (phuong an 4.2):
 *   moi luot RunOnce = 1 lan VL53_3_Step (<= ~75 ms) + cac dich vu theo
 *   tick: motor 10 ms (bu nhip), FSM 100 ms, telemetry/CSV 200 ms,
 *   lenh USART2 xu ly ngay trong luot -> do tre STOP < 100 ms.
 * Che do: MANUAL (dashboard lai bang SET_PWM, mat link > 2 s tu dung)
 *         AUTO   (FSM lai, mat link van chay doc lap - Brief muc 7).
 * Cong tac dung vat ly PE2 (input pull-up, nhan = GND): cat cung VM la
 * chinh; firmware doc PE2 de khoa trang thai SAFE cho den khi cong tac
 * nha ra VA co lenh START moi. */
#ifndef APP_MAIN_H
#define APP_MAIN_H

void AppMain_Init(void);    /* goi 1 lan sau tat ca MX_*_Init() */
void AppMain_RunOnce(void); /* goi lien tuc trong while(1), khong them delay lon */

#endif /* APP_MAIN_H */
