/* BAN 4 MOTOR v2 - nhan dien file: dong nay phai o dau soft_enc.h */
#ifndef SOFT_ENC_H
#define SOFT_ENC_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* =====================================================================
 * Encoder quadrature giai ma bang PHAN MEM qua ngat ngoai EXTI.
 * Dung cho cac dong co khong con Timer Encoder Mode trong (M3, M4),
 * vi:
 *  - TIM2/TIM5 chi co chan PA0/PA1 (PA0 la nut WK_UP tren board) hoac
 *    PA15/PB3 (PB3 la SPI1 cua flash/NRF tren board);
 *  - TIM8 dung PC6/PC7 - trung chan voi TIM3 cua M1.
 * Tai ngat: moi dong co ~14.000 xung/s o toc do toi da (300 RPM truc ra,
 * 2800 dem/vong x4) - khong dang ke voi STM32F407 168 MHz.
 *
 * Cach dung:
 *  - CubeMX: 2 chan C1/C2 dat GPIO_EXTI, kich ca 2 canh (Rising/Falling),
 *    Pull-up, bat NVIC EXTI15_10 (neu chan thuoc line 10..15).
 *  - Trong HAL_GPIO_EXTI_Callback(): goi SoftEnc_OnEdge() cho tung
 *    encoder mem. Ham tu doc lai trang thai 2 chan va chi tinh khi
 *    trang thai thay doi, nen goi thua cung khong sao.
 *  - Giai ma x4 (moi canh cua ca 2 kenh = 1 dem), giong Timer Encoder
 *    Mode TI12 cua M1/M2 nen so dem/vong va cong thuc RPM khop nhau.
 * ===================================================================== */

typedef struct {
    GPIO_TypeDef *port_a; uint16_t pin_a;  /* C1 - pha A */
    GPIO_TypeDef *port_b; uint16_t pin_b;  /* C2 - pha B */
    volatile int32_t delta;   /* so dem tich luy ke tu lan TakeDelta truoc */
    volatile int64_t total;   /* tong so dem (de debug/hieu chuan) */
    uint8_t state;            /* trang thai truoc: (A<<1)|B */
} SoftEnc_t;

void SoftEnc_Init(SoftEnc_t *e);

/* Goi trong HAL_GPIO_EXTI_Callback. Doc trang thai hien tai, doi chieu
 * bang chuyen trang thai quadrature, cong/tru 1 dem neu hop le. */
void SoftEnc_OnEdge(SoftEnc_t *e);

/* Lay so dem ke tu lan goi truoc va xoa ve 0 (an toan voi ngat). */
int32_t SoftEnc_TakeDelta(SoftEnc_t *e);

#endif /* SOFT_ENC_H */
