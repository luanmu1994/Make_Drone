/* BAN 4 MOTOR v3 - nhan dien file: dong nay phai o dau motor_n20.h
 * (v3 = v2 + RAMP PWM mem: duty tang/giam dan theo buoc, dao chieu di qua 0.
 *  Muc dich: chay 4 dong co KHONG can tu bulk 1000uF o rail - dong khoi dong
 *  va dong dao chieu khong con dot bien cung luc. Van giu encoder mem EXTI
 *  cua v2 va tuong thich nguoc voi bai test 1 dong co.) */
#ifndef MOTOR_N20_H
#define MOTOR_N20_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include "soft_enc.h"

/* =====================================================================
 * Driver 1 dong co DC encoder N20 (board XY-N20, encoder Hall 2 pha)
 * qua 1 kenh cua TB6612FNG + doc toc do bang Timer Encoder Mode.
 *
 * Day cua dong co (doc tu anh that, doi chieu silk tren board XY-N20,
 * thu tu chan M2 - VCC - C2 - C1 - GND - M1):
 *   Do    = M2  : cuc dong co  -> AO2 cua TB6612
 *   Trang = M1  : cuc dong co  -> AO1 cua TB6612
 *   Den   = VCC : nguon encoder 3.3V  (!!! day DEN khong phai GND)
 *   Xanh duong (Blue) = GND encoder   (!!! day GND lai mau xanh duong)
 *   Xanh la (Green)   = C1 : encoder pha A -> chan Timer CH1
 *   Vang  = C2  : encoder pha B -> chan Timer CH2
 *
 * Encoder: Hall quadrature, 7 xung/kenh/vong TRUC MOTOR (truoc hop so),
 * dia nam cham 14 cuc. Timer Encoder Mode TI12 dem ca 2 canh x 2 kenh
 * = x4, nen so dem moi vong truc motor = 7 x 4 = 28.
 * So dem moi vong TRUC RA = 28 x ti so truyen hop so.
 * ===================================================================== */

/* So dem moi vong truc ra - MAC DINH tam tinh theo hop so 100:1.
 * BAT BUOC hieu chuan bang che do CALIB trong motor_1test (phim 'c'):
 * quay tay truc ra dung 10 vong, firmware in ra so dem/vong that,
 * sua lai con so nay roi build lai. RPM chi dung khi so nay dung. */
#define N20_COUNTS_PER_OUTPUT_REV   2800u   /* = 7 PPR x 4 (x4) x 100 (hop so) */

/* Buoc ramp mac dinh: moi lan Update (10 ms) duty chi duoc thay doi
 * toi da bay nhieu phan nghin. 20 = 2000 phan nghin/giay -> 0 len 100%
 * trong 0,5 giay. Tang len 50 neu thay phan ung cham (0,2 giay),
 * giam xuong 10 neu nguon con sut ap khi khoi dong (1 giay). */
#define N20_RAMP_STEP_10MS_DEFAULT   20u

/* Co loi (bitmask, in o cot cuoi cua dong CSV) */
#define N20_FLAG_RUNNING     0x01u  /* dang co lenh quay (|PWM| > 0) */
#define N20_FLAG_BRAKE       0x02u  /* dang ham (brake) */
#define N20_FLAG_NO_COUNT    0x04u  /* co lenh quay >=25% trong 1s ma encoder khong dem duoc xung nao: kiem tra day C1/C2/nguon encoder */
#define N20_FLAG_STALL       0x08u  /* encoder co dem nhung RPM ~0 khi PWM >= 50% trong 1s: ket co khi / qua tai / nguon VM yeu */

typedef struct {
    /* --- Phan cung (dien vao luc Init) --- */
    TIM_HandleTypeDef *hpwm;        /* Timer PWM, vd &htim1 */
    uint32_t           pwm_channel; /* vd TIM_CHANNEL_1 */
    GPIO_TypeDef      *in1_port; uint16_t in1_pin;  /* AIN1 */
    GPIO_TypeDef      *in2_port; uint16_t in2_pin;  /* AIN2 */
    GPIO_TypeDef      *stby_port; uint16_t stby_pin;/* STBY (co the dung chung nhieu kenh) */
    TIM_HandleTypeDef *henc;        /* Timer Encoder Mode, vd &htim3.
                                       Neu dung encoder MEM (EXTI): de NULL
                                       va dien soft_enc o duoi. */
    SoftEnc_t         *soft_enc;    /* Encoder mem EXTI (M3/M4), NULL = dung henc */

    /* --- Cau hinh --- */
    uint32_t counts_per_output_rev; /* so dem / 1 vong truc ra (sau hieu chuan) */
    int8_t   encoder_sign;          /* +1 giu nguyen, -1 neu chieu dem nguoc voi chieu quay dat */

    /* --- Cau hinh ramp --- */
    uint16_t ramp_step_10ms;    /* buoc ramp moi 10 ms (phan nghin). 0 = dung mac dinh 20 */

    /* --- Trang thai / thong so do duoc --- */
    int16_t  cmd_permille;      /* lenh toc do DICH (target): -1000..+1000 (dau = chieu) */
    int16_t  applied_permille;  /* toc do THUC AP xuong dong co sau ramp (theo doi qua CSV) */
    uint8_t  braking;           /* 1 = dang o che do ham */
    int64_t  total_counts;      /* tong so dem tich luy (co dau) ke tu Init/Reset */
    int32_t  delta_100ms;       /* so dem trong cua so 100 ms gan nhat */
    int32_t  rpm_x10;           /* toc do truc ra x10 (vd 2535 = 253.5 RPM), co dau theo chieu */
    uint32_t pulse_hz_x10;      /* tan so xung kenh C1 x10 (Hz) - de doi chieu may do/oscilloscope */
    uint32_t flags;             /* N20_FLAG_* */
    uint32_t run_ms;            /* tong thoi gian da co lenh quay (ms) */

    /* noi bo */
    int16_t  out_written;       /* gia tri applied da ghi xuong phan cung lan truoc */
    int8_t   out_dir;           /* chieu da ghi: 1 thuan, -1 nguoc, 0 troi, 2 ham */
    uint16_t last_counter;
    int32_t  window_counts;
    uint32_t window_start_ms;
    uint32_t low_speed_ms;      /* dem thoi gian toc do ~0 khi dang co lenh */
    uint32_t no_count_ms;
} MotorN20_t;

/* Khoi tao: bat STBY, dung PWM + Encoder timer. Goi SAU MX_*_Init(). */
void MotorN20_Init(MotorN20_t *m);

/* Dat toc do DICH: -1000..+1000 phan nghin. >0 quay thuan (AIN1=H, AIN2=L),
 * <0 quay nguoc, 0 = dung. Ham nay chi dat dich; MotorN20_Update se dua
 * duty that (applied_permille) ve dich dan dan theo ramp_step_10ms:
 * tang/giam deu dan, dao chieu thi giam ve 0 truoc roi moi lat chan chieu.
 * SetPermille(0) = dung MEM (ramp xuong 0 roi troi). */
void MotorN20_SetPermille(MotorN20_t *m, int16_t permille);

/* Ham dien (short brake: AIN1=AIN2=H). */
void MotorN20_Brake(MotorN20_t *m);

/* Dua STBY xuong 0 (driver nghi, dong co troi) / len 1. */
void MotorN20_Standby(MotorN20_t *m, uint8_t standby_on);

/* Cap nhat doc encoder + tinh RPM. Goi moi 10 ms tu vong lap chinh.
 * RPM duoc tinh lai moi cua so 100 ms, loc muot EMA. */
void MotorN20_Update(MotorN20_t *m, uint32_t now_ms);

/* So vong truc ra x1000 (co dau): 123456 = 123.456 vong */
int64_t MotorN20_RevolutionsX1000(const MotorN20_t *m);

/* Goc truc ra trong vong hien tai: 0..3599 (x10 do) */
int32_t MotorN20_AngleX10(const MotorN20_t *m);

/* Toc do dai (mm/s x10) neu biet duong kinh banh xe; wheel_d_mm = 0 -> tra 0 */
int32_t MotorN20_LinearSpeedX10(const MotorN20_t *m, uint32_t wheel_d_mm);

/* Xoa bo dem + thong so (dung cho hieu chuan va test lai) */
void MotorN20_ResetCounter(MotorN20_t *m);

#endif /* MOTOR_N20_H */
