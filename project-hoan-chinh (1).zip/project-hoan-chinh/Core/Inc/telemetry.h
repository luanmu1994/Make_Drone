/* PROJECT HOAN CHINH - Telemetry HC-12 qua USART2 (PA2/PA3, 9600).
 * Giao thuc CO DINH theo dashboard.py (khong tu che):
 *   Khung: [0xAA][0x55][Type][Seq][Len][Payload...][CRC16 lo][CRC16 hi]
 *   CRC16-Modbus (poly 0xA001) tinh tren Type..het Payload.
 *   Type 0x01 Telemetry STM32->PC: payload 24 byte LE
 *     mode u8 (0=Manual 1=Auto), fsm u8 (0..4), running u8,
 *     front/left/right i16 (mm, -1 = INVALID),
 *     pwm u8 x4 (%), rpm i16 x4, sound u16 (0-100), sound_alarm u8
 *   Type 0x10 Lenh PC->STM32: cmd u8 (1=START 2=STOP 3=MANUAL 4=AUTO
 *     5=SET_PWM) + pwm u8 x4 (%)
 *   Type 0x7F ACK STM32->PC: [seq cua lenh, status u8] (0 = OK)        */
#ifndef TELEMETRY_H
#define TELEMETRY_H

#include <stdint.h>
#include <stdbool.h>

#define TELEM_TYPE_STATE   0x01
#define TELEM_TYPE_CMD     0x10
#define TELEM_TYPE_ACK     0x7F

#define TELEM_CMD_START    1
#define TELEM_CMD_STOP     2
#define TELEM_CMD_MANUAL   3
#define TELEM_CMD_AUTO     4
#define TELEM_CMD_SET_PWM  5

typedef struct {
    uint8_t mode;          /* 0 = Manual, 1 = Auto                        */
    uint8_t fsm;           /* nav_state_t 0..4                            */
    uint8_t running;       /* 0/1                                         */
    int16_t dist_mm[3];    /* FRONT, LEFT, RIGHT; -1 = INVALID            */
    uint8_t pwm_pct[4];    /* %                                           */
    int16_t rpm[4];
    uint16_t sound_level;  /* 0..100 tu SoundApp (INMP441, G5 da ghep)    */
    uint8_t sound_alarm;   /* 0/1: muc > 80 HOAC SOS phat hien keu cuu    */
} telem_state_t;

/* Bat dau nhan bang ngat USART2. Goi sau MX_USART2_UART_Init(). */
void Telemetry_Init(void);

/* Lay 1 lenh 0x10 da nhan (neu co): tra ve true va dien cmd/pwm/seq.
   app_main goi lien tuc trong vong lap; moi lenh lay ra phai duoc
   app_main tra loi bang Telemetry_Ack(seq, status). */
bool Telemetry_TakeCommand(uint8_t *cmd, uint8_t pwm_pct[4], uint8_t *seq);

/* Gui ACK cho lenh (type 0x7F). status 0 = OK, khac 0 = bi tu choi. */
void Telemetry_Ack(uint8_t cmd_seq, uint8_t status);

/* Gui goi trang thai 0x01 (khong blocking: dung Transmit_IT, bo qua
   chu ky nay neu duong truyen dang ban). */
void Telemetry_SendState(const telem_state_t *st);

/* Thong ke lien ket (hien thi debug): so goi hop le, so goi loi CRC. */
uint32_t Telemetry_RxPackets(void);
uint32_t Telemetry_RxCrcErrors(void);

#endif /* TELEMETRY_H */
