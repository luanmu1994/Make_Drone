/* PHAT HIEN TIENG KEU CUU - nhan dien file: dong nay phai o dau sos_detect.h
 *
 * Thuat toan phat hien MAU TIENG KEU CUU (DSP rule-based, khong AI,
 * dung pham vi Brief v1.0) cho kenh am thanh INMP441 @ Fs 16 kHz:
 *
 *   1) TACH DAI GIONG NOI: chuoi loc thong cao 250 Hz + thong thap
 *      3400 Hz (biquad Butterworth bac 2, he so RBJ tinh san cho
 *      16 kHz) - loai rum dong co tan thap va ret tan cao.
 *   2) NEN ON THICH NGHI: muc nen (RMS dai giong) duoc hoc lien tuc
 *      bang EMA cham chi khi khung dang yen - nguong phat hien la
 *      TUONG DOI (nen x 3.2, ~ +10 dB) nen motor chay lam nen on
 *      tang thi nguong tu nang theo, khong bao dong gia nhu nguong
 *      co dinh. Co them san tuyet doi -40 dBFS.
 *   3) KHUNG 10 ms duoc coi la "co tieng" khi: RMS dai giong vuot
 *      nguong tuong doi VA nang luong dai giong chiem > 55% tong
 *      nang luong (tieng nguoi thong tri dai cua no; beep tan cao /
 *      rum tan thap bi loai o day).
 *   4) PHAN DOAN BURST: cum khung co tieng lien tiep (cho phep
 *      dut quang <= 80 ms) thanh mot burst. Burst hop le dai
 *      150-900 ms (mot tieng het/am tiet keu). Burst >= 1200 ms
 *      tinh la TIENG KEU LIEN TUC va kich hoat ngay.
 *   5) KHOP MAU: >= 3 burst hop le trong cua so 5 s, khoang nghi
 *      giua cac burst 100-900 ms -> mau "keu - nghi - keu - nghi -
 *      keu" dac trung cua tieng keu cuu -> bao dong giu 10 s.
 *
 * GIOI HAN PHAI NOI THANG: module nhan dien MAU NHIP + DAI TAN +
 * DO LON cua tieng het lap lai, KHONG nhan dien duoc noi dung loi
 * noi ("cuu" hay tu khac). Ket qua dung ngon ngu la "nghi ngo
 * tieng keu cuu" de nguoi giam sat xac minh, khong phai bang chung.
 * Tieng het nhip dieu cua tre em, co vu... co the bao gia - can
 * hieu chuan nguong tren tieng keu that khi trien khai (xem huong
 * dan kem theo).
 *
 * Giao dien: SOS_Feed() nhan mau int32 (kenh LEFT, da chuan hoa
 * day thang int32: mau 24-bit cua INMP441 dich trai ve int32) theo
 * tung khoi DMA bat ky kich thuoc; module tu chia khung 10 ms.
 * Thuan C99 + float (STM32F407 co FPU), khong phu thuoc HAL.
 */
#ifndef SOS_DETECT_H
#define SOS_DETECT_H

#include <stdint.h>

#define SOS_FS_HZ              16000
#define SOS_FRAME_SAMPLES      160      /* 10 ms */

/* --- Hang so tinh chinh (sua o day) --- */
#define SOS_RATIO_MIN_X1000    550      /* dai giong phai > 55% nang luong */
#define SOS_MARGIN_X100        320      /* nguong = nen x 3.20 (~ +10 dB)  */
#define SOS_ABS_MIN_RMS        0.0100f  /* san tuyet doi: -40 dBFS         */
#define SOS_BURST_MIN_MS       150u
#define SOS_BURST_MAX_MS       900u
#define SOS_SUSTAIN_MS         1200u    /* keu lien tuc dai hon -> bao ngay */
#define SOS_GAP_MS             80u      /* quang dut van tinh cung 1 burst */
#define SOS_PAUSE_MIN_MS       100u
#define SOS_PAUSE_MAX_MS       900u
#define SOS_PATTERN_BURSTS     3u       /* so burst hop le de khop mau     */
#define SOS_PATTERN_WINDOW_MS  5000u
#define SOS_ALARM_HOLD_MS      10000u   /* giu bao dong sau khi khop mau   */

typedef struct {
    float    floor_dbfs;     /* muc nen on hien tai trong dai giong (dBFS) */
    uint32_t event_count;    /* tong so su kien keu cuu da phat hien       */
    uint32_t last_event_ms;  /* moc thoi gian (theo dong ho khung) su kien gan nhat */
    uint8_t  chain_count;    /* so burst hop le dang trong chuoi khop mau  */
} sos_stats_t;

void SOS_Init(void);

/* Nap mau am thanh (kenh LEFT). Goi tu callback DMA nua buffer. */
void SOS_Feed(const int32_t *samples, uint32_t count);

/* 1 neu dang trong thoi gian giu bao dong keu cuu. Dong ho lay theo
 * luong mau da nap (Feed chay lien tuc nen tuong duong thoi gian thuc). */
uint8_t SOS_AlarmActive(void);

void SOS_GetStats(sos_stats_t *out);

#endif /* SOS_DETECT_H */
