/**
 ******************************************************************************
 * @file    vl53l0x_3sensor.h  (BAN 3 CAM BIEN - MEDIAN TRUOT 4.2)
 * @brief   Lay du lieu 3 VL53L0X cung bus I2C1 (PB6/PB7) theo PHUONG AN 4.2
 *          trong PHAN_TICH_PROJECT_HOAN_CHINH.md: MEDIAN TRUOT + DIEU PHOI
 *          HOP TAC (cooperative), thay cho kieu cu "doc lien 5 mau x 3 con"
 *          khoa vong lap ~1,1 giay:
 *
 *            - Moi luot vong lap chinh chi doc 1 single-shot cua 1 cam
 *              bien, quay vong FRONT -> LEFT -> RIGHT (VL53_3_Step).
 *            - Ket qua (ke ca lan do loi/khong co vat, ghi la INVALID)
 *              duoc day vao cua so truot 5 lan-do gan nhat cua rieng con
 *              do; median lay tu cac mau hop le trong cua so.
 *            - Moi luot bi khoa toi da ~1 lan do (~75 ms binh thuong),
 *              giua hai lan do luon co khoang cho Motor Update / FSM /
 *              telemetry chay -> do tre STOP < 100 ms nhu muc 4.2.
 *            - Tan suat mau moi cua moi con ~ 3 lan do/vong (~220 ms),
 *              median lam moi ~4 Hz.
 *
 *          Phan cung / dia chi giu nguyen ban 3 cam bien truoc:
 *            S1 FRONT - XSHUT PC0 - dia chi 0x30
 *            S2 LEFT  - XSHUT PC1 - dia chi 0x31
 *            S3 RIGHT - XSHUT PC2 - dia chi 0x32
 *          Moi cam bien van chay full ST-flow v5 (RefSpadManagement +
 *          RefCalibration) trong VL53M_Init - loi driver KHONG doi.
 *
 *          Log USART1 van dung dang CSV cu (dashboard/test cu doc duoc):
 *          tick_ms,front_mm,left_mm,right_mm,f_zone,l_zone,r_zone,
 *          valid_sensors,error_count
 ******************************************************************************
 */
#ifndef VL53L0X_3SENSOR_H
#define VL53L0X_3SENSOR_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

/* Nguong (mm): 100cm canh bao, 50cm tranh, 25cm dung, hysteresis 50mm */
#define THRESH_WARN_MM          1000
#define THRESH_AVOID_MM         500
#define THRESH_STOP_MM          250
#define HYSTERESIS_MM           50

#define VL53_INVALID_MM         (-1)
#define VL53_NUM_SENSORS        3U

/* Cua so truot: 5 lan do gan nhat / cam bien, can >= 3 mau hop le trong
   cua so moi cong bo median (cung tieu chi 3/5 nhu ban burst cu). */
#define VL53_WINDOW_SIZE        5U
#define VL53_MIN_VALID          3U

/* Cam bien coi la "mat du lieu" neu > 1 s khong co mau hop le nao
   (khop luat fail-safe muc 4.3: F mat > 1 s -> BLOCKED). */
#define VL53_STALE_MS           1000U

/* So lan do loi LIEN TIEP cua 1 con truoc khi danh dau offline trong
   phien chay (20 lan x ~220 ms/vong ~ 4-5 giay). Con offline bi bo qua
   trong vong quay; khoi phuc bang VL53_3_Recover() - xem ghi chu o ham. */
#define VL53_FAILS_TO_OFFLINE   20U

/* Chu ky in CSV khi dung VL53_3_RunOnce (5 Hz nhu telemetry muc 4.2). */
#define VL53_CSV_PERIOD_MS      200U

/* Chi so cam bien */
#define VL53_FRONT              0U
#define VL53_LEFT               1U
#define VL53_RIGHT              2U
#define VL53_NONE               0xFFU

/* Dia chi I2C 7-bit sau khi gan */
#define VL53_ADDR_FRONT         0x30U
#define VL53_ADDR_LEFT          0x31U
#define VL53_ADDR_RIGHT         0x32U

typedef enum {
    ZONE_SAFE = 0,      /* > 1000 mm     */
    ZONE_WARNING,       /* 500 - 1000 mm */
    ZONE_AVOID,         /* 250 - 500 mm  */
    ZONE_STOP,          /* <= 250 mm     */
    ZONE_INVALID        /* loi / chua du mau hop le trong cua so */
} vl53_zone_t;

typedef struct {
    int32_t     mm[VL53_NUM_SENSORS];       /* median cua so, -1 = INVALID */
    vl53_zone_t zone[VL53_NUM_SENSORS];
    bool        online[VL53_NUM_SENSORS];   /* init OK va chua bi offline  */
    uint8_t     win_valid[VL53_NUM_SENSORS];/* so mau hop le trong cua so  */
    uint32_t    age_ms[VL53_NUM_SENSORS];   /* ms tu mau hop le gan nhat;
                                               UINT32_MAX = chua tung co   */
    uint32_t    sample_ok[VL53_NUM_SENSORS];/* tong mau hop le tu boot     */
    uint32_t    error_count;                /* tong lan doc loi tu boot    */
    uint8_t     last_sensor;                /* con vua do o Step gan nhat  */
    uint32_t    last_step_ms;               /* thoi gian lan Step gan nhat */
    uint32_t    max_step_ms;                /* Step lau nhat tu boot       */
} vl53_3data_t;

/* Khoi tao ca 3: giu XSHUT ca 3 o muc thap, bat tung con o 0x29, gan dia
   chi moi, chay ST-flow. Cam bien nao loi se bi tat va danh dau offline,
   2 con con lai van chay tiep. Ham nay blocking vai giay - chi goi 1 lan
   luc boot, nhu ban cu. */
bool VL53_3_Init(void);

/* *** Ham trung tam cua phuong an 4.2 ***
   Do DUNG 1 single-shot cua cam bien tiep theo trong vong quay
   FRONT -> LEFT -> RIGHT (bo qua con offline), day ket qua vao cua so
   truot cua con do va cap nhat median/zone cua no. Tra ve chi so cam
   bien vua do (VL53_FRONT/LEFT/RIGHT), hoac VL53_NONE neu ca 3 offline.
   Goi 1 lan moi luot while(1); TUYET DOI khong tu in CSV, khong tu delay
   - viec in/FSM/motor do vong lap dieu phoi quyet dinh theo tick. */
uint8_t VL53_3_Step(void);

/* In 1 dong CSV tu median hien tai (khong do them mau nao). Vong dieu
   phoi goi ham nay moi VL53_CSV_PERIOD_MS (200 ms = 5 Hz). */
void VL53_3_PrintCsv(void);

/* Cach dung don gian cho bench rieng le (chua gop motor/FSM):
   moi luot = VL53_3_Step() + tu in CSV 5 Hz. Khong can HAL_Delay -
   ban than lan do da tao nhip. Khi gop project, dung Step() truc tiep
   theo khung scheduler trong main_test_snippet.c thay vi ham nay. */
void VL53_3_RunOnce(void);

/* Anh chup trang thai moi nhat cho nav_fsm / telemetry doc (khong do
   them, khong blocking). */
vl53_3data_t VL53_3_Get(void);

/* true neu cam bien khong online, chua tung co mau hop le, hoac mau hop
   le gan nhat da cach hon VL53_STALE_MS - dung cho luat fail-safe 4.3. */
bool VL53_3_IsStale(uint8_t idx);

/* So cam bien dang khong co median hop le (ke ca offline) - luat 4.3:
   >= 2 con mat -> BLOCKED. */
uint8_t VL53_3_LostCount(void);

/* Khoi phuc 1 cam bien da offline: tat bang XSHUT, init lai tu 0x29 va
   gan lai dia chi cu (an toan vi 2 con con lai khong con nghe o 0x29).
   CANH BAO: ham nay chay full ST-flow, blocking vai giay nhu luc boot -
   chi goi khi motor dang dung (vi du khi FSM dang BLOCKED), khong goi
   trong vong dieu phoi binh thuong. */
bool VL53_3_Recover(uint8_t idx);

const char *VL53_ZoneName(vl53_zone_t z);

#endif /* VL53L0X_3SENSOR_H */
