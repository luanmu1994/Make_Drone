/* PROJECT HOAN CHINH - lop ung dung 4 dong co (thay demo/phim cua motors_4test)
 * Phan cung giu nguyen 100% phuong an 4 motor:
 *   M1 truoc-trai : TB1 kenh A, PWM PE9 (TIM1_CH1), AIN PB0/PB1, enc TIM3 PC6/PC7
 *   M2 truoc-phai : TB1 kenh B, PWM PE11 (TIM1_CH2), BIN PE5/PE6, enc TIM4 PD12/PD13
 *   M3 sau-trai   : TB2 kenh A, PWM PB14 (TIM12_CH1), AIN PD8/PD9, enc MEM PD14/PD15
 *   M4 sau-phai   : TB2 kenh B, PWM PB15 (TIM12_CH2), BIN PD10/PD11, enc MEM PE12/PE13
 *   STBY mach 1 = PE0, mach 2 = PE1.
 * Driver motor_n20 v3 (ramp mem) + soft_enc giu nguyen, khong sua. */
#ifndef MOTORS_APP_H
#define MOTORS_APP_H

#include <stdint.h>

#define MOTORS_NUM 4
#define MOTOR_FL 0   /* M1 truoc-trai  */
#define MOTOR_FR 1   /* M2 truoc-phai  */
#define MOTOR_RL 2   /* M3 sau-trai    */
#define MOTOR_RR 3   /* M4 sau-phai    */

/* Khoi tao ca 4 dong co (cau hinh chan + MotorN20_Init). Goi sau MX_*_Init. */
void MotorsApp_Init(void);

/* Dich vu ramp/encoder: goi voi nhip ~10 ms (app_main tu bu nhip khi vong
   lap bi lan do cam bien khoa lau hon - xem app_main). */
void MotorsApp_Update10ms(uint32_t now_ms);

/* Dat toc do dich tung dong co: -1000..+1000 phan nghin (dau = chieu).
   Chi dat dich - duty that len dan theo ramp trong driver. */
void MotorsApp_Set(uint8_t idx, int16_t permille);
void MotorsApp_SetAll(int16_t permille);
/* Dat theo 2 ben: trai = M1+M3, phai = M2+M4 (dung cho mau tranh vat can) */
void MotorsApp_SetSides(int16_t left_permille, int16_t right_permille);
void MotorsApp_StopAll(void);    /* dich 0 cho ca 4 (dung mem theo ramp) */
void MotorsApp_BrakeAll(void);   /* ham dien ca 4 (ngay lap tuc) */

/* Du lieu cho telemetry:
   pwm_pct  : |applied|/10 -> 0..100 (%)
   rpm      : RPM truc ra (da lam tron tu rpm_x10)
   flags_or : OR co loi N20_FLAG_* cua ca 4 dong co */
void MotorsApp_GetTelemetry(uint8_t pwm_pct[MOTORS_NUM],
                            int16_t rpm[MOTORS_NUM], uint32_t *flags_or);

/* CPR cua tung dong co (mac dinh 2800 - BAT BUOC hieu chuan o bai test
   motor rieng roi ghi lai 4 con so vao day qua ham nay luc khoi dong). */
void MotorsApp_SetCpr(uint8_t idx, uint32_t cpr);

/* Du lieu cho dong log bench "MOT,..." tren USART1 (dashboard tong hop):
   moi dong co mot bo 4 so: pwm phan nghin co dau (applied), rpm_x10 co
   dau, so vong x1000 co dau, flags N20_FLAG_* cua rieng dong co do. */
void MotorsApp_GetBench(int16_t pwm_permille[MOTORS_NUM],
                        int32_t rpm_x10[MOTORS_NUM],
                        int64_t rev_x1000[MOTORS_NUM],
                        uint32_t flags[MOTORS_NUM]);

#endif /* MOTORS_APP_H */
