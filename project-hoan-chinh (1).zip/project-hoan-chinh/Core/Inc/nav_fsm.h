/* PROJECT HOAN CHINH - FSM + Rule-Based tranh vat can (Brief muc 7,
 * phan tich tich hop muc 4.3). Gia tri enum KHOP truong fsm trong goi
 * telemetry 0x01 cua dashboard.py - khong doi thu tu. */
#ifndef NAV_FSM_H
#define NAV_FSM_H

#include <stdint.h>
#include "vl53l0x_3sensor.h"

typedef enum {
    NAV_FORWARD = 0,    /* F > 1000 mm                                  */
    NAV_WARNING = 1,    /* 500 < F <= 1000                              */
    NAV_AVOID_LEFT = 2, /* F <= 500, trai thoang hon phai > 100 mm      */
    NAV_AVOID_RIGHT = 3,/* F <= 500, phai thoang hon trai >= 100 mm     */
    NAV_BLOCKED = 4     /* F <= 250 / ca 3 <= 500 / loi du lieu         */
} nav_state_t;

void NavFsm_Init(void);

/* Danh gia luat tren anh chup cam bien moi nhat (goi 10 Hz tu app_main).
   Fail-safe uu tien tuyet doi va co hieu luc ngay: FRONT stale (chua
   tung co mau hoac > 1 s khong co mau hop le) hoac mat >= 2 cam bien
   -> BLOCKED. Trang thai AVOID duoc giu toi thieu NAV_DWELL_MS de
   chong rung qua lai giua hai huong tranh. */
nav_state_t NavFsm_Update(const vl53_3data_t *d, uint32_t now_ms);

/* Trang thai hien tai (sau lan Update gan nhat). */
nav_state_t NavFsm_State(void);

/* Ap mau PWM cua trang thai hien tai xuong 4 dong co (qua MotorsApp):
   FORWARD ca 4 +600, WARNING ca 4 +350,
   AVOID_LEFT  ben trai +150 / ben phai +550 (AVOID_RIGHT nguoc lai),
   BLOCKED ca 4 = 0. Don vi phan nghin. */
void NavFsm_Apply(void);

const char *NavFsm_Name(nav_state_t s);

#endif /* NAV_FSM_H */
