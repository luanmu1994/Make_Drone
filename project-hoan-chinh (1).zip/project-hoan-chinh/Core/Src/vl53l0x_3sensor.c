/**
 ******************************************************************************
 * @file    vl53l0x_3sensor.c  (BAN 3 CAM BIEN - MEDIAN TRUOT 4.2)
 * @brief   Xem vl53l0x_3sensor.h. Khac biet cot loi so voi ban burst cu:
 *
 *          Ban cu:  read_sensor() doc lien 5 mau x 3 con trong 1 luot
 *                   -> ~15 single-shot ~ 1,1 s khoa cung vong lap.
 *          Ban nay: VL53_3_Step() chi lam 1 single-shot cho 1 con, theo
 *                   vong quay. Cua so truot giu 5 LAN DO gan nhat (lan
 *                   loi/khong-co-vat cung chiem 1 o, ghi INVALID) nen:
 *                     - vat bi lay di thi median cu tu het han sau toi da
 *                       5 lan do cua con do (~1,1 s), khong "dinh" mai;
 *                     - can >= 3/5 hop le moi cong bo median - cung muc
 *                       tin cay nhu tieu chi 3/5 cua ban burst;
 *                     - luc moi boot, moi con can 3 lan do hop le
 *                       (~3 vong quay ~ 0,7 s) moi co median dau tien.
 ******************************************************************************
 */
#include "vl53l0x_3sensor.h"
#include "vl53l0x_min.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart1;

typedef struct {
    VL53M_Dev   dev;
    const char *tag;        /* "S1 FRONT" ...                            */
    uint8_t     new_addr;
    bool        online;
    /* cua so truot: VL53_WINDOW_SIZE lan do gan nhat, INVALID = lan do
       loi / khong co vat; win_head tro toi o sap bi ghi de (o cu nhat) */
    int32_t     window[VL53_WINDOW_SIZE];
    uint8_t     win_head;
    int32_t     mm;                 /* median hien tai, -1 = INVALID     */
    vl53_zone_t zone;
    bool        had_median;         /* da tung cong bo median hop le     */
    uint32_t    last_valid_tick;    /* HAL_GetTick luc mau hop le gan nhat */
    bool        ever_valid;
    uint8_t     consec_fail;
    uint32_t    sample_ok;
} sensor_t;

static sensor_t s_s[VL53_NUM_SENSORS] = {
    { .dev = { .xshut_port = GPIOC, .xshut_pin = GPIO_PIN_0 },
      .tag = "S1 FRONT", .new_addr = VL53_ADDR_FRONT, .zone = ZONE_INVALID },
    { .dev = { .xshut_port = GPIOC, .xshut_pin = GPIO_PIN_1 },
      .tag = "S2 LEFT",  .new_addr = VL53_ADDR_LEFT,  .zone = ZONE_INVALID },
    { .dev = { .xshut_port = GPIOC, .xshut_pin = GPIO_PIN_2 },
      .tag = "S3 RIGHT", .new_addr = VL53_ADDR_RIGHT, .zone = ZONE_INVALID },
};
static uint32_t s_error_count;
static uint8_t  s_next;             /* con sap do trong vong quay        */
static uint8_t  s_last_sensor = VL53_NONE;
static uint32_t s_last_step_ms;
static uint32_t s_max_step_ms;
static uint32_t s_last_csv_tick;
static bool     s_csv_started;

static void uart_log(const char *s)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 100);
}

const char *VL53_ZoneName(vl53_zone_t z)
{
    switch (z) {
        case ZONE_SAFE:    return "SAFE";
        case ZONE_WARNING: return "WARNING";
        case ZONE_AVOID:   return "AVOID";
        case ZONE_STOP:    return "STOP";
        default:           return "INVALID";
    }
}

static vl53_zone_t classify(int32_t mm)
{
    if (mm == VL53_INVALID_MM) return ZONE_INVALID;
    if (mm <= THRESH_STOP_MM)  return ZONE_STOP;
    if (mm <= THRESH_AVOID_MM) return ZONE_AVOID;
    if (mm <= THRESH_WARN_MM)  return ZONE_WARNING;
    return ZONE_SAFE;
}

static vl53_zone_t apply_hysteresis(vl53_zone_t prev, int32_t mm)
{
    vl53_zone_t raw = classify(mm);
    if (raw == ZONE_INVALID || prev == ZONE_INVALID) return raw;
    if (raw < prev) {
        int32_t edge = (prev == ZONE_WARNING) ? THRESH_WARN_MM  :
                       (prev == ZONE_AVOID)   ? THRESH_AVOID_MM : THRESH_STOP_MM;
        if (mm <= edge + HYSTERESIS_MM) return prev;
    }
    return raw;
}

static void reset_window(sensor_t *s)
{
    for (uint8_t i = 0; i < VL53_WINDOW_SIZE; i++) s->window[i] = VL53_INVALID_MM;
    s->win_head = 0;
    s->mm = VL53_INVALID_MM;
    s->zone = ZONE_INVALID;
    s->had_median = false;
    s->ever_valid = false;
    s->consec_fail = 0;
}

/* Gom cac mau hop le trong cua so, sap xep, tra median;
   chua du VL53_MIN_VALID mau hop le -> VL53_INVALID_MM. */
static int32_t window_median(const sensor_t *s, uint8_t *valid_out)
{
    int32_t v[VL53_WINDOW_SIZE];
    uint8_t n = 0;
    for (uint8_t i = 0; i < VL53_WINDOW_SIZE; i++)
        if (s->window[i] != VL53_INVALID_MM) v[n++] = s->window[i];
    if (valid_out) *valid_out = n;
    if (n < VL53_MIN_VALID) return VL53_INVALID_MM;
    for (uint8_t i = 0; i + 1 < n; i++)
        for (uint8_t j = 0; j + 1 < n - i; j++)
            if (v[j] > v[j + 1]) { int32_t t = v[j]; v[j] = v[j + 1]; v[j + 1] = t; }
    return v[n / 2];
}

static void print_dbg3(const sensor_t *s)
{
    char dbg[192];
    snprintf(dbg, sizeof(dbg),
             "DBG3 %s stage=%u start=0x%02X int=0x%02X err=%u raw=%u "
             "sig_mcps_x100=%lu status=0x%02X\r\n",
             s->tag,
             (unsigned)VL53M_LastFailStage(&s->dev),
             (unsigned)VL53M_LastStartReg(&s->dev),
             (unsigned)VL53M_LastIntReg(&s->dev),
             (unsigned)VL53M_LastDeviceError(&s->dev),
             (unsigned)VL53M_LastRawMm(&s->dev),
             (unsigned long)((uint32_t)VL53M_LastSignalRaw(&s->dev) * 100U / 128U),
             (unsigned)VL53M_LastStatusByte(&s->dev));
    uart_log(dbg);
}

static bool init_one(sensor_t *s)
{
    char d[192];
    if (VL53M_Init(&s->dev, s->new_addr)) {
        snprintf(d, sizeof(d),
                 "INIT %s addr=0x%02X: OK mgmt count=%lu aperture=%u "
                 "peak_mcps_x100=%lu refcal=%u vhv=0x%02X phase=0x%02X\r\n",
                 s->tag, (unsigned)s->new_addr,
                 (unsigned long)VL53M_MgmtCount(&s->dev),
                 (unsigned)VL53M_MgmtAperture(&s->dev),
                 (unsigned long)((uint32_t)VL53M_MgmtPeakRaw(&s->dev) * 100U / 128U),
                 (unsigned)VL53M_RefCalOk(&s->dev),
                 (unsigned)VL53M_VhvSettings(&s->dev),
                 (unsigned)VL53M_PhaseCal(&s->dev));
        uart_log(d);
        return true;
    }
    /* Tat con loi lai ngay: neu de no song o 0x29, con tiep theo
       bat len se xung dot dia chi va init sai ca chuoi. */
    VL53M_Shutdown(&s->dev);
    snprintf(d, sizeof(d),
             "INIT %s: FAIL stage=%u id=0x%02X - tat cam bien nay; "
             "doi chieu bang stage trong huong dan\r\n",
             s->tag, (unsigned)VL53M_InitStage(&s->dev),
             (unsigned)VL53M_IdByte(&s->dev));
    uart_log(d);
    return false;
}

bool VL53_3_Init(void)
{
    uart_log("\r\n=== VL53L0X x3 MEDIAN TRUOT (PHUONG AN 4.2) START ===\r\n");
    s_error_count = 0;
    s_next = 0;
    s_last_sensor = VL53_NONE;
    s_last_step_ms = 0;
    s_max_step_ms = 0;
    s_csv_started = false;

    /* Buoc 1: tat ca 3 cam bien, cho tat han */
    for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++) {
        s_s[i].online = false;
        s_s[i].sample_ok = 0;
        reset_window(&s_s[i]);
        VL53M_Shutdown(&s_s[i].dev);
    }
    HAL_Delay(10);

    /* BUS CHECK: ca 3 dang tat thi 0x29 phai TRONG. Neu co thiet bi tra
       loi nghia la XSHUT khong tat duoc cam bien (chan XSHUT chua cau
       hinh GPIO Output, hoac day XSHUT cam nham chan GPIO1 canh ben). */
    if (VL53M_ProbeAddr(0x29))
        uart_log("BUS CHECK: CANH BAO - 0x29 van co thiet bi khi ca 3 "
                 "XSHUT dang THAP -> XSHUT khong dieu khien duoc cam bien\r\n");
    else
        uart_log("BUS CHECK: 0x29 trong khi ca 3 tat - OK\r\n");

    /* Buoc 2: bat tung con, init o 0x29, gan dia chi moi (trong VL53M_Init) */
    for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++)
        s_s[i].online = init_one(&s_s[i]);

    uart_log("tick_ms,front_mm,left_mm,right_mm,f_zone,l_zone,r_zone,"
             "valid_sensors,error_count\r\n");
    s_last_csv_tick = HAL_GetTick();
    s_csv_started = true;
    return s_s[0].online || s_s[1].online || s_s[2].online;
}

uint8_t VL53_3_Step(void)
{
    /* Tim con online tiep theo trong vong quay (toi da 3 buoc). */
    uint8_t idx = VL53_NONE;
    for (uint8_t k = 0; k < VL53_NUM_SENSORS; k++) {
        uint8_t cand = (uint8_t)((s_next + k) % VL53_NUM_SENSORS);
        if (s_s[cand].online) { idx = cand; break; }
    }
    if (idx == VL53_NONE) {
        s_last_sensor = VL53_NONE;
        return VL53_NONE;
    }
    s_next = (uint8_t)((idx + 1U) % VL53_NUM_SENSORS);
    s_last_sensor = idx;
    sensor_t *s = &s_s[idx];

    /* --- Dung 1 single-shot cua con nay --- */
    uint32_t t0 = HAL_GetTick();
    int32_t v = VL53_INVALID_MM;
    bool ok = VL53M_ReadMm(&s->dev, &v);
    s_last_step_ms = HAL_GetTick() - t0;
    if (s_last_step_ms > s_max_step_ms) s_max_step_ms = s_last_step_ms;

    /* Day LAN DO nay vao cua so (loi/khong co vat cung chiem 1 o). */
    s->window[s->win_head] = ok ? v : VL53_INVALID_MM;
    s->win_head = (uint8_t)((s->win_head + 1U) % VL53_WINDOW_SIZE);

    if (ok) {
        s->last_valid_tick = HAL_GetTick();
        s->ever_valid = true;
        s->consec_fail = 0;
        s->sample_ok++;
    } else {
        s_error_count++;
        if (s->consec_fail < 0xFFU) s->consec_fail++;

        if (s->consec_fail >= VL53_FAILS_TO_OFFLINE) {
            /* Chet han trong phien: tat + bo qua trong vong quay.
               Khoi phuc chu dong bang VL53_3_Recover() khi motor dung. */
            char d[128];
            snprintf(d, sizeof(d),
                     "DBG3 %s OFFLINE sau %u lan do loi lien tiep\r\n",
                     s->tag, (unsigned)s->consec_fail);
            uart_log(d);
            print_dbg3(s);
            VL53M_Shutdown(&s->dev);
            s->online = false;
            reset_window(s);
            return idx;
        }
    }

    /* Cap nhat median/zone cua rieng con nay. */
    int32_t med = window_median(s, NULL);
    if (med != VL53_INVALID_MM) {
        s->mm = med;
        s->zone = apply_hysteresis(s->zone, med);
        s->had_median = true;
    } else {
        if (s->had_median) {
            /* Median vua mat sau khi da tung tot: in DBG3 dung 1 lan cho
               su kien nay (khong in moi lan do loi -> tranh ngap UART). */
            print_dbg3(s);
            s->had_median = false;
        }
        s->mm = VL53_INVALID_MM;
        s->zone = ZONE_INVALID;
    }
    return idx;
}

void VL53_3_PrintCsv(void)
{
    uint8_t valid = 0;
    for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++)
        if (s_s[i].mm != VL53_INVALID_MM) valid++;

    char line[128];
    snprintf(line, sizeof(line), "%lu,%ld,%ld,%ld,%s,%s,%s,%u,%lu\r\n",
             (unsigned long)HAL_GetTick(),
             (long)s_s[0].mm, (long)s_s[1].mm, (long)s_s[2].mm,
             VL53_ZoneName(s_s[0].zone), VL53_ZoneName(s_s[1].zone),
             VL53_ZoneName(s_s[2].zone),
             (unsigned)valid, (unsigned long)s_error_count);
    uart_log(line);
}

void VL53_3_RunOnce(void)
{
    (void)VL53_3_Step();
    uint32_t now = HAL_GetTick();
    if (!s_csv_started || (now - s_last_csv_tick) >= VL53_CSV_PERIOD_MS) {
        s_last_csv_tick = now;
        s_csv_started = true;
        VL53_3_PrintCsv();
    }
}

vl53_3data_t VL53_3_Get(void)
{
    vl53_3data_t out;
    uint32_t now = HAL_GetTick();
    for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++) {
        out.mm[i] = s_s[i].mm;
        out.zone[i] = s_s[i].zone;
        out.online[i] = s_s[i].online;
        (void)window_median(&s_s[i], &out.win_valid[i]);
        out.age_ms[i] = s_s[i].ever_valid ? (now - s_s[i].last_valid_tick)
                                          : UINT32_MAX;
        out.sample_ok[i] = s_s[i].sample_ok;
    }
    out.error_count = s_error_count;
    out.last_sensor = s_last_sensor;
    out.last_step_ms = s_last_step_ms;
    out.max_step_ms = s_max_step_ms;
    return out;
}

bool VL53_3_IsStale(uint8_t idx)
{
    if (idx >= VL53_NUM_SENSORS) return true;
    if (!s_s[idx].online || !s_s[idx].ever_valid) return true;
    return (HAL_GetTick() - s_s[idx].last_valid_tick) > VL53_STALE_MS;
}

uint8_t VL53_3_LostCount(void)
{
    uint8_t n = 0;
    for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++)
        if (s_s[i].mm == VL53_INVALID_MM) n++;
    return n;
}

bool VL53_3_Recover(uint8_t idx)
{
    if (idx >= VL53_NUM_SENSORS) return false;
    sensor_t *s = &s_s[idx];
    VL53M_Shutdown(&s->dev);
    s->online = false;
    reset_window(s);
    HAL_Delay(10);
    s->online = init_one(s);
    if (!s->online) reset_window(s);
    return s->online;
}
