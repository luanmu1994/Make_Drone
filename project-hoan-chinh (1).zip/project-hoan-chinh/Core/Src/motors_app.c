/* PROJECT HOAN CHINH - xem motors_app.h.
 * Cau hinh chan sao nguyen tu motors_4test.c v3.1 (da kiem chung o bai
 * test motor rieng); chi bo demo/phim UART, thay bang API cho
 * app_main / nav_fsm / telemetry dieu khien. */
#include "motors_app.h"
#include "motor_n20.h"
#include "soft_enc.h"
#include "main.h"

extern TIM_HandleTypeDef htim1;   /* PWM M1 (CH1 PE9), M2 (CH2 PE11) */
extern TIM_HandleTypeDef htim12;  /* PWM M3 (CH1 PB14), M4 (CH2 PB15) */
extern TIM_HandleTypeDef htim3;   /* Encoder M1: PC6/PC7 */
extern TIM_HandleTypeDef htim4;   /* Encoder M2: PD12/PD13 */

static MotorN20_t motors[MOTORS_NUM];
static SoftEnc_t  soft3, soft4;   /* encoder mem cua M3, M4 */

/* Callback ngat EXTI cho encoder mem M3/M4 (giong het bai test motor).
 * Neu project da co HAL_GPIO_EXTI_Callback o noi khac thi XOA ham nay
 * va goi 2 dong SoftEnc_OnEdge(...) trong ham do. */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    (void)GPIO_Pin;
    SoftEnc_OnEdge(&soft3);
    SoftEnc_OnEdge(&soft4);
}

void MotorsApp_Init(void)
{
    /* ---- M1: TB1 kenh A, encoder TIM3 ---- */
    motors[0].hpwm = &htim1; motors[0].pwm_channel = TIM_CHANNEL_1;
    motors[0].in1_port = GPIOB; motors[0].in1_pin = GPIO_PIN_0;
    motors[0].in2_port = GPIOB; motors[0].in2_pin = GPIO_PIN_1;
    motors[0].stby_port = GPIOE; motors[0].stby_pin = GPIO_PIN_0;
    motors[0].henc = &htim3; motors[0].soft_enc = NULL;

    /* ---- M2: TB1 kenh B, encoder TIM4 ---- */
    motors[1].hpwm = &htim1; motors[1].pwm_channel = TIM_CHANNEL_2;
    motors[1].in1_port = GPIOE; motors[1].in1_pin = GPIO_PIN_5;
    motors[1].in2_port = GPIOE; motors[1].in2_pin = GPIO_PIN_6;
    motors[1].stby_port = GPIOE; motors[1].stby_pin = GPIO_PIN_0;
    motors[1].henc = &htim4; motors[1].soft_enc = NULL;

    /* ---- M3: TB2 kenh A, encoder mem EXTI PD14/PD15 ---- */
    soft3.port_a = GPIOD; soft3.pin_a = GPIO_PIN_14;
    soft3.port_b = GPIOD; soft3.pin_b = GPIO_PIN_15;
    motors[2].hpwm = &htim12; motors[2].pwm_channel = TIM_CHANNEL_1;
    motors[2].in1_port = GPIOD; motors[2].in1_pin = GPIO_PIN_8;
    motors[2].in2_port = GPIOD; motors[2].in2_pin = GPIO_PIN_9;
    motors[2].stby_port = GPIOE; motors[2].stby_pin = GPIO_PIN_1;
    motors[2].henc = NULL; motors[2].soft_enc = &soft3;

    /* ---- M4: TB2 kenh B, encoder mem EXTI PE12/PE13 ---- */
    soft4.port_a = GPIOE; soft4.pin_a = GPIO_PIN_12;
    soft4.port_b = GPIOE; soft4.pin_b = GPIO_PIN_13;
    motors[3].hpwm = &htim12; motors[3].pwm_channel = TIM_CHANNEL_2;
    motors[3].in1_port = GPIOD; motors[3].in1_pin = GPIO_PIN_10;
    motors[3].in2_port = GPIOD; motors[3].in2_pin = GPIO_PIN_11;
    motors[3].stby_port = GPIOE; motors[3].stby_pin = GPIO_PIN_1;
    motors[3].henc = NULL; motors[3].soft_enc = &soft4;

    for (int i = 0; i < MOTORS_NUM; i++) {
        motors[i].counts_per_output_rev = N20_COUNTS_PER_OUTPUT_REV;
        motors[i].encoder_sign = 1;
        motors[i].ramp_step_10ms = 20;   /* 0->100% trong 0,5 s */
        MotorN20_Init(&motors[i]);
    }
}

void MotorsApp_Update10ms(uint32_t now_ms)
{
    for (int i = 0; i < MOTORS_NUM; i++)
        MotorN20_Update(&motors[i], now_ms);
}

void MotorsApp_Set(uint8_t idx, int16_t permille)
{
    if (idx < MOTORS_NUM) MotorN20_SetPermille(&motors[idx], permille);
}

void MotorsApp_SetAll(int16_t permille)
{
    for (int i = 0; i < MOTORS_NUM; i++)
        MotorN20_SetPermille(&motors[i], permille);
}

void MotorsApp_SetSides(int16_t left_permille, int16_t right_permille)
{
    MotorN20_SetPermille(&motors[MOTOR_FL], left_permille);
    MotorN20_SetPermille(&motors[MOTOR_RL], left_permille);
    MotorN20_SetPermille(&motors[MOTOR_FR], right_permille);
    MotorN20_SetPermille(&motors[MOTOR_RR], right_permille);
}

void MotorsApp_StopAll(void)
{
    MotorsApp_SetAll(0);
}

void MotorsApp_BrakeAll(void)
{
    for (int i = 0; i < MOTORS_NUM; i++) MotorN20_Brake(&motors[i]);
}

void MotorsApp_GetTelemetry(uint8_t pwm_pct[MOTORS_NUM],
                            int16_t rpm[MOTORS_NUM], uint32_t *flags_or)
{
    uint32_t f = 0;
    for (int i = 0; i < MOTORS_NUM; i++) {
        int32_t a = motors[i].applied_permille;
        if (a < 0) a = -a;
        a /= 10;
        if (a > 100) a = 100;
        pwm_pct[i] = (uint8_t)a;
        rpm[i] = (int16_t)(motors[i].rpm_x10 / 10);
        f |= motors[i].flags;
    }
    if (flags_or) *flags_or = f;
}

void MotorsApp_SetCpr(uint8_t idx, uint32_t cpr)
{
    if (idx < MOTORS_NUM && cpr > 0) motors[idx].counts_per_output_rev = cpr;
}

void MotorsApp_GetBench(int16_t pwm_permille[MOTORS_NUM],
                        int32_t rpm_x10[MOTORS_NUM],
                        int64_t rev_x1000[MOTORS_NUM],
                        uint32_t flags[MOTORS_NUM])
{
    for (int i = 0; i < MOTORS_NUM; i++) {
        pwm_permille[i] = motors[i].applied_permille;
        rpm_x10[i] = motors[i].rpm_x10;
        rev_x1000[i] = MotorN20_RevolutionsX1000(&motors[i]);
        flags[i] = motors[i].flags;
    }
}
