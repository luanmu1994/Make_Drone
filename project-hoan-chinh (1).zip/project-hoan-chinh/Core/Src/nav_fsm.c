/* PROJECT HOAN CHINH - xem nav_fsm.h.
 * Luat doi chieu dong-thoi voi ban xem truoc trong dashboard_3sensor.py
 * (ham fsm_preview) - sua luat thi sua ca hai noi. */
#include "nav_fsm.h"
#include "motors_app.h"

#define NAV_DWELL_MS 500U   /* giu trang thai AVOID toi thieu 0,5 s */

static nav_state_t s_state;
static uint32_t    s_state_since;

static nav_state_t evaluate(const vl53_3data_t *d)
{
    int32_t f = d->mm[VL53_FRONT];
    int32_t l = d->mm[VL53_LEFT];
    int32_t r = d->mm[VL53_RIGHT];

    /* Fail-safe (Brief: loi cam bien nghiem trong -> trang thai an toan) */
    if (!d->online[VL53_FRONT] || d->age_ms[VL53_FRONT] > VL53_STALE_MS)
        return NAV_BLOCKED;
    if (VL53_3_LostCount() >= 2)
        return NAV_BLOCKED;

    if (f == VL53_INVALID_MM) return NAV_BLOCKED;
    if (f <= THRESH_STOP_MM)  return NAV_BLOCKED;

    if (l != VL53_INVALID_MM && r != VL53_INVALID_MM &&
        f <= THRESH_AVOID_MM && l <= THRESH_AVOID_MM && r <= THRESH_AVOID_MM)
        return NAV_BLOCKED;                    /* ca 3 huong deu hep */

    if (f > THRESH_WARN_MM)  return NAV_FORWARD;
    if (f > THRESH_AVOID_MM) return NAV_WARNING;

    /* F <= 500: chon huong thoang hon; huong INVALID coi nhu 0 (bit) */
    int32_t lv = (l == VL53_INVALID_MM) ? 0 : l;
    int32_t rv = (r == VL53_INVALID_MM) ? 0 : r;
    if (lv == 0 && rv == 0) return NAV_BLOCKED;
    if (lv > rv + 100) return NAV_AVOID_LEFT;
    if (rv >= lv + 100) return NAV_AVOID_RIGHT;
    return (lv > rv) ? NAV_AVOID_LEFT : NAV_AVOID_RIGHT;  /* hoa -> phai */
}

void NavFsm_Init(void)
{
    s_state = NAV_BLOCKED;   /* chua co du lieu thi dung yen - an toan */
    s_state_since = 0;
}

nav_state_t NavFsm_Update(const vl53_3data_t *d, uint32_t now_ms)
{
    nav_state_t raw = evaluate(d);

    if (raw != s_state) {
        bool dwell_blocks =
            (s_state == NAV_AVOID_LEFT || s_state == NAV_AVOID_RIGHT) &&
            raw != NAV_BLOCKED &&
            (now_ms - s_state_since) < NAV_DWELL_MS;
        if (!dwell_blocks) {
            s_state = raw;
            s_state_since = now_ms;
        }
    }
    return s_state;
}

nav_state_t NavFsm_State(void)
{
    return s_state;
}

void NavFsm_Apply(void)
{
    switch (s_state) {
        case NAV_FORWARD:
            MotorsApp_SetAll(600);
            break;
        case NAV_WARNING:
            MotorsApp_SetAll(350);
            break;
        case NAV_AVOID_LEFT:
            MotorsApp_SetSides(150, 550);
            break;
        case NAV_AVOID_RIGHT:
            MotorsApp_SetSides(550, 150);
            break;
        case NAV_BLOCKED:
        default:
            MotorsApp_SetAll(0);
            break;
    }
}

const char *NavFsm_Name(nav_state_t s)
{
    switch (s) {
        case NAV_FORWARD:     return "FORWARD";
        case NAV_WARNING:     return "WARNING";
        case NAV_AVOID_LEFT:  return "AVOID_LEFT";
        case NAV_AVOID_RIGHT: return "AVOID_RIGHT";
        default:              return "BLOCKED";
    }
}
