/* BAN 4 MOTOR v3 - nhan dien file: dong nay phai o dau motor_n20.c */
#include "motor_n20.h"

/* TB6612FNG bang chan ly (PWM = chan PWMA):
 *   AIN1=H, AIN2=L -> quay thuan (CW)      AIN1=L, AIN2=H -> quay nguoc (CCW)
 *   AIN1=H, AIN2=H -> ham (short brake)    AIN1=L, AIN2=L, PWM=H -> dung troi
 *   STBY=L -> toan bo driver nghi (Hi-Z)   */

static void motor_write_dir(MotorN20_t *m, GPIO_PinState in1, GPIO_PinState in2)
{
    HAL_GPIO_WritePin(m->in1_port, m->in1_pin, in1);
    HAL_GPIO_WritePin(m->in2_port, m->in2_pin, in2);
}

static void motor_write_duty(MotorN20_t *m, uint16_t permille_abs)
{
    uint32_t period = __HAL_TIM_GET_AUTORELOAD(m->hpwm);
    uint32_t ccr = ((period + 1u) * (uint32_t)permille_abs) / 1000u;
    if (ccr > period + 1u) ccr = period + 1u;
    __HAL_TIM_SET_COMPARE(m->hpwm, m->pwm_channel, ccr);
}

/* Ghi trang thai applied xuong chan/duty - chi ghi khi thay doi.
 * applied > 0: chieu thuan; < 0: chieu nguoc; = 0: troi (hoac chuan bi
 * lat chieu theo target o nhip ramp ke tiep). */
static void motor_apply_output(MotorN20_t *m)
{
    int8_t dir = (m->applied_permille > 0) ? 1 : (m->applied_permille < 0) ? -1 : 0;
    if (m->applied_permille == m->out_written && dir == m->out_dir) return;
    m->out_written = m->applied_permille;
    m->out_dir = dir;
    if (dir > 0) {
        motor_write_dir(m, GPIO_PIN_SET, GPIO_PIN_RESET);
        motor_write_duty(m, (uint16_t)m->applied_permille);
    } else if (dir < 0) {
        motor_write_dir(m, GPIO_PIN_RESET, GPIO_PIN_SET);
        motor_write_duty(m, (uint16_t)(-m->applied_permille));
    } else {
        motor_write_dir(m, GPIO_PIN_RESET, GPIO_PIN_RESET);
        motor_write_duty(m, 0);
    }
}

/* 1 buoc ramp: dua applied ve phia target.
 * Khac dau va applied != 0 -> chi giam ve 0 (chua lat chieu). */
static void motor_ramp_step(MotorN20_t *m)
{
    int32_t step = (m->ramp_step_10ms != 0u) ? m->ramp_step_10ms
                                             : N20_RAMP_STEP_10MS_DEFAULT;
    int32_t a = m->applied_permille;
    int32_t t = m->cmd_permille;
    if (a == t) return;
    if (a != 0 && t != 0 && ((a < 0) != (t < 0))) {
        /* dao chieu: giam ve 0 truoc */
        if (a > 0) { a -= step; if (a < 0) a = 0; }
        else       { a += step; if (a > 0) a = 0; }
    } else {
        if (a < t) { a += step; if (a > t) a = t; }
        else       { a -= step; if (a < t) a = t; }
    }
    m->applied_permille = (int16_t)a;
}

void MotorN20_Init(MotorN20_t *m)
{
    m->cmd_permille = 0;
    m->applied_permille = 0;
    m->out_written = 0;
    m->out_dir = 0;
    m->braking = 0;
    m->total_counts = 0;
    m->delta_100ms = 0;
    m->rpm_x10 = 0;
    m->pulse_hz_x10 = 0;
    m->flags = 0;
    m->run_ms = 0;
    m->window_counts = 0;
    m->low_speed_ms = 0;
    m->no_count_ms = 0;
    if (m->counts_per_output_rev == 0u)
        m->counts_per_output_rev = N20_COUNTS_PER_OUTPUT_REV;
    if (m->encoder_sign == 0)
        m->encoder_sign = 1;

    motor_write_dir(m, GPIO_PIN_RESET, GPIO_PIN_RESET);
    MotorN20_Standby(m, 0); /* STBY = 1: cho phep driver hoat dong */

    motor_write_duty(m, 0);
    HAL_TIM_PWM_Start(m->hpwm, m->pwm_channel);

    if (m->soft_enc != NULL) {
        SoftEnc_Init(m->soft_enc);
        m->last_counter = 0;
    } else {
        __HAL_TIM_SET_COUNTER(m->henc, 0);
        HAL_TIM_Encoder_Start(m->henc, TIM_CHANNEL_ALL);
        m->last_counter = (uint16_t)__HAL_TIM_GET_COUNTER(m->henc);
    }
    m->window_start_ms = HAL_GetTick();
}

void MotorN20_Standby(MotorN20_t *m, uint8_t standby_on)
{
    /* Luu y: STBY cua TB6612 la chan cho phep: =1 chay, =0 nghi.
     * Tham so standby_on o day nghia la "dua vao standby" cho de goi. */
    HAL_GPIO_WritePin(m->stby_port, m->stby_pin,
                      standby_on ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

void MotorN20_SetPermille(MotorN20_t *m, int16_t permille)
{
    if (permille > 1000)  permille = 1000;
    if (permille < -1000) permille = -1000;
    /* v3: chi dat DICH. Duty that thay doi dan dan trong MotorN20_Update. */
    m->cmd_permille = permille;
    m->braking = 0;
}

void MotorN20_Brake(MotorN20_t *m)
{
    /* Ham la lenh khan: ap ngay, khong qua ramp. Dung tiet che khi dang
     * chay nhanh vi dong ham dot ngot la luc rail de bi doi ap nhat. */
    m->cmd_permille = 0;
    m->applied_permille = 0;
    m->braking = 1;
    m->out_written = 0;
    m->out_dir = 2;
    motor_write_dir(m, GPIO_PIN_SET, GPIO_PIN_SET);
    motor_write_duty(m, 1000);
}

void MotorN20_ResetCounter(MotorN20_t *m)
{
    if (m->soft_enc != NULL) {
        (void)SoftEnc_TakeDelta(m->soft_enc);
        m->soft_enc->total = 0;
    } else {
        __HAL_TIM_SET_COUNTER(m->henc, 0);
    }
    m->last_counter = 0;
    m->total_counts = 0;
    m->window_counts = 0;
}

void MotorN20_Update(MotorN20_t *m, uint32_t now_ms)
{
    int32_t d;
    if (m->soft_enc != NULL) {
        d = SoftEnc_TakeDelta(m->soft_enc);
    } else {
        uint16_t cnt = (uint16_t)__HAL_TIM_GET_COUNTER(m->henc);
        /* Timer encoder 16-bit: hieu 2 so uint16 ep sang int16 tu xu ly tran vong */
        d = (int16_t)(cnt - m->last_counter);
        m->last_counter = cnt;
    }
    if (m->encoder_sign < 0) d = -d;
    m->total_counts += d;
    m->window_counts += d;

    /* Ramp PWM mem: moi nhip Update (10 ms) duty that chi lech toi da
     * ramp_step_10ms so voi dich -> dong khoi dong/dao chieu trai deu,
     * rail 6V khong bi sut/dot ap cung luc ca 4 dong co. */
    if (!m->braking) {
        motor_ramp_step(m);
        motor_apply_output(m);
    }

    if (m->applied_permille != 0) m->run_ms += 10u;

    uint32_t elapsed = now_ms - m->window_start_ms;
    if (elapsed >= 100u) {
        m->delta_100ms = m->window_counts;

        /* RPM truc ra = (so dem / so dem moi vong) * (60000 ms / elapsed) */
        int64_t rpm_x10 = 0;
        if (m->counts_per_output_rev > 0u) {
            rpm_x10 = ((int64_t)m->window_counts * 600000) /
                      ((int64_t)m->counts_per_output_rev * (int64_t)elapsed);
        }
        /* Loc muot EMA alpha = 1/4 cho so in ra on dinh */
        m->rpm_x10 = (int32_t)(((int64_t)m->rpm_x10 * 3 + rpm_x10) / 4);

        /* Tan so xung 1 kenh (C1): moi xung C1 = 4 dem timer (che do x4) */
        int32_t dc = m->window_counts;
        if (dc < 0) dc = -dc;
        m->pulse_hz_x10 = (uint32_t)(((uint64_t)(uint32_t)dc * 10000u) / (4u * elapsed));

        /* --- Chan doan loi (theo duty THUC AP, khong theo dich) --- */
        uint32_t f = 0;
        if (m->applied_permille != 0) f |= N20_FLAG_RUNNING;
        if (m->braking)               f |= N20_FLAG_BRAKE;

        int32_t cmd_abs = (m->applied_permille < 0) ? -m->applied_permille : m->applied_permille;
        if (cmd_abs >= 250 && dc == 0) m->no_count_ms += elapsed; else m->no_count_ms = 0;
        if (m->no_count_ms >= 1000u) f |= N20_FLAG_NO_COUNT;

        int32_t rpm_abs = (m->rpm_x10 < 0) ? -m->rpm_x10 : m->rpm_x10;
        if (cmd_abs >= 500 && dc != 0 && rpm_abs < 50) m->low_speed_ms += elapsed;
        else m->low_speed_ms = 0;
        if (m->low_speed_ms >= 1000u) f |= N20_FLAG_STALL;

        m->flags = f;
        m->window_counts = 0;
        m->window_start_ms = now_ms;
    }
}

int64_t MotorN20_RevolutionsX1000(const MotorN20_t *m)
{
    if (m->counts_per_output_rev == 0u) return 0;
    return (m->total_counts * 1000) / (int64_t)m->counts_per_output_rev;
}

int32_t MotorN20_AngleX10(const MotorN20_t *m)
{
    if (m->counts_per_output_rev == 0u) return 0;
    int64_t r = m->total_counts % (int64_t)m->counts_per_output_rev;
    if (r < 0) r += (int64_t)m->counts_per_output_rev;
    return (int32_t)((r * 3600) / (int64_t)m->counts_per_output_rev);
}

int32_t MotorN20_LinearSpeedX10(const MotorN20_t *m, uint32_t wheel_d_mm)
{
    if (wheel_d_mm == 0u) return 0;
    /* v = RPM * pi * D / 60  (mm/s). Tinh x10, pi x1000 = 3142 */
    int64_t v = (int64_t)m->rpm_x10 * 3142 * (int64_t)wheel_d_mm / 60000;
    return (int32_t)v;
}
