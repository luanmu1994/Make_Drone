/* PROJECT HOAN CHINH - doan dan vao main.c that (KHONG copy ca file).
 *
 * Project CubeMX can co du cac MX_*_Init sau (xem checklist trong
 * HUONG_DAN_PROJECT_HOAN_CHINH.md):
 *   MX_GPIO_Init, MX_I2C1_Init (PB6/PB7, 100 kHz),
 *   MX_USART1_UART_Init (115200 debug), MX_USART2_UART_Init (9600 HC-12),
 *   MX_TIM1_Init (PWM M1/M2), MX_TIM12_Init (PWM M3/M4),
 *   MX_TIM3_Init (encoder M1), MX_TIM4_Init (encoder M2),
 *   MX_I2S3_Init (INMP441 - G5 da ghep: Master Receive, Philips,
 *   24 bits on 32 bits frame, 16 kHz, Master Clock Output DISABLE;
 *   DMA SPI3_RX = DMA1 Stream 0 Ch 0, Circular, bat NVIC DMA1_Stream0)
 *   + NVIC: EXTI15_10 (encoder mem M3/M4), USART2 (telemetry RX/TX IT)
 *   SAU KHI GENERATE I2S3: ra gpio.c - PC10/PA4/PC12 phai la AF6,
 *   PC7 PHAI VAN LA AF2 TIM3 (neu MCK bi bat, PC7 thanh AF6 va
 *   encoder M1 mat kenh B ma khong co loi build nao canh bao).
 *
 * 1) Dau main.c, trong USER CODE BEGIN Includes:
 *      #include "app_main.h"
 *
 * 2) Trong main(), USER CODE BEGIN 2 (sau cac MX_*_Init):
 *      AppMain_Init();
 *
 * 3) Trong while(1), USER CODE BEGIN 3:
 *      AppMain_RunOnce();
 *    (KHONG them HAL_Delay trong vong lap - nhip do AppMain tu quan ly:
 *     moi luot RunOnce bi khoa toi da boi 1 lan do cam bien ~75 ms,
 *     dich vu motor/FSM/telemetry chay theo tick o giua.)
 *
 * LUU Y callback (chi duoc dinh nghia 1 noi trong toan project):
 *   - HAL_GPIO_EXTI_Callback nam trong motors_app.c (encoder mem)
 *   - HAL_UART_RxCpltCallback / HAL_UART_TxCpltCallback trong telemetry.c
 *   - HAL_I2S_RxHalfCpltCallback / HAL_I2S_RxCpltCallback trong
 *     sound_app.c (nua buffer DMA INMP441 -> SOS + muc am)
 */
