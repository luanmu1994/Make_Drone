/* PROJECT HOAN CHINH - xem app_main.h va PHAN_TICH_PROJECT_HOAN_CHINH.md
 * (muc 4.2 bang nhip, muc 4.3 FSM, muc 5 telemetry, muc 7 an toan). */
#include "app_main.h"
#include "main.h"
#include "vl53l0x_3sensor.h"
#include "motors_app.h"
#include "nav_fsm.h"
#include "telemetry.h"
#include "sound_app.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart1;   /* log debug co day 115200 */

#define STOP_SW_PORT  GPIOE
#define STOP_SW_PIN   GPIO_PIN_2
#define LINK_LOSS_MANUAL_MS  2000U  /* Manual: > 2 s khong lenh -> dung */
#define RECOVER_RETRY_MS     10000U /* thu khoi phuc cam bien moi 10 s  */
#define RECOVER_MAX_TRIES    3

static uint8_t  s_mode_auto;        /* 0 = MANUAL, 1 = AUTO */
static uint8_t  s_running;
static uint8_t  s_safe_latch;       /* khoa boi cong tac dung vat ly */
static uint8_t  s_manual_pct[4];    /* SET_PWM gan nhat (%) */
static uint32_t s_last_cmd_ms;
static uint32_t s_last_motor_ms;
static uint32_t s_last_fsm_ms;
static uint32_t s_last_tx_ms;
static uint8_t  s_recover_tries[VL53_NUM_SENSORS];
static uint32_t s_recover_next_ms;
static uint32_t s_sos_events_seen;  /* de in log canh len su kien SOS */

static void log1(const char *s)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 100);
}

static bool stop_switch_pressed(void)
{
    return HAL_GPIO_ReadPin(STOP_SW_PORT, STOP_SW_PIN) == GPIO_PIN_RESET;
}

static void apply_manual_targets(void)
{
    for (int i = 0; i < 4; i++)
        MotorsApp_Set((uint8_t)i, (int16_t)s_manual_pct[i] * 10);
}

static void handle_command(uint8_t cmd, const uint8_t pwm[4], uint8_t seq,
                           uint32_t now)
{
    uint8_t status = 0;
    s_last_cmd_ms = now;            /* moi lenh hop le = link con song */
    switch (cmd) {
        case TELEM_CMD_START:
            if (stop_switch_pressed() || s_safe_latch) {
                status = 1;         /* cong tac dung dang khoa */
            } else {
                s_running = 1;
                log1("APP: START\r\n");
            }
            break;
        case TELEM_CMD_STOP:
            s_running = 0;
            MotorsApp_StopAll();
            log1("APP: STOP\r\n");
            break;
        case TELEM_CMD_MANUAL:
            s_mode_auto = 0;
            s_running = 0;
            MotorsApp_StopAll();
            log1("APP: MODE = MANUAL (cho START)\r\n");
            break;
        case TELEM_CMD_AUTO:
            s_mode_auto = 1;
            s_running = 0;
            MotorsApp_StopAll();
            log1("APP: MODE = AUTO (cho START)\r\n");
            break;
        case TELEM_CMD_SET_PWM:
            memcpy(s_manual_pct, pwm, 4);
            break;
        default:
            status = 2;             /* lenh khong ho tro */
            break;
    }
    Telemetry_Ack(seq, status);
}

void AppMain_Init(void)
{
    log1("\r\n=== PROJECT HOAN CHINH: 3 VL53L0X + 4 MOTOR + HC-12 + INMP441/SOS ===\r\n");
    (void)VL53_3_Init();            /* in INIT/BUS CHECK/USART1 nhu ban test */
    MotorsApp_Init();
    NavFsm_Init();
    Telemetry_Init();
    (void)SoundApp_Init();          /* G5: INMP441 I2S3+DMA + SOS; loi
                                       thu am khong anh huong dieu khien */
    s_sos_events_seen = 0;
    s_mode_auto = 0;
    s_running = 0;
    s_safe_latch = stop_switch_pressed() ? 1 : 0;
    memset(s_manual_pct, 0, sizeof(s_manual_pct));
    s_last_cmd_ms = s_last_motor_ms = s_last_fsm_ms = s_last_tx_ms
                  = HAL_GetTick();
    memset(s_recover_tries, 0, sizeof(s_recover_tries));
    s_recover_next_ms = HAL_GetTick() + RECOVER_RETRY_MS;
    log1("APP: san sang - MANUAL, chua chay. Cho lenh tu dashboard.\r\n");
}

void AppMain_RunOnce(void)
{
    /* 1) Do 1 cam bien (khoa toi da ~1 lan do) */
    (void)VL53_3_Step();
    uint32_t now = HAL_GetTick();

    /* 2) Dich vu motor 10 ms - bu nhip: lan Step vua roi co the da khoa
       ~75 ms, goi Update nhieu lan voi moc thoi gian ao de ramp cua
       driver (buoc co dinh moi lan Update) giu dung toc do thiet ke. */
    {
        uint32_t steps = (now - s_last_motor_ms) / 10U;
        if (steps > 8U) steps = 8U;
        for (uint32_t k = 1; k <= steps; k++)
            MotorsApp_Update10ms(s_last_motor_ms + k * 10U);
        s_last_motor_ms += steps * 10U;
        if (now - s_last_motor_ms > 1000U) s_last_motor_ms = now;
    }

    /* 3) Cong tac dung vat ly: khoa ngay, chi mo khoa bang nha cong tac
       + lenh START moi (START bi tu choi khi latch con hieu luc) */
    if (stop_switch_pressed()) {
        if (!s_safe_latch) {
            s_safe_latch = 1;
            s_running = 0;
            MotorsApp_StopAll();
            log1("APP: CONG TAC DUNG VAT LY - KHOA SAFE\r\n");
        }
    } else if (s_safe_latch && !s_running) {
        /* cong tac da nha: giu latch cho den START; START se xoa latch
           trong handle_command khi thay cong tac khong con nhan - o day
           chi can cho phep: */
        s_safe_latch = 0;
        log1("APP: cong tac da nha - cho START\r\n");
    }

    /* 4) Lenh tu dashboard (USART2) */
    {
        uint8_t cmd, pwm[4], seq;
        while (Telemetry_TakeCommand(&cmd, pwm, &seq))
            handle_command(cmd, pwm, seq, now);
    }

    /* 5) Watchdog link o Manual (Brief: mat ket noi -> dung dong co) */
    if (!s_mode_auto && s_running &&
        (now - s_last_cmd_ms) > LINK_LOSS_MANUAL_MS) {
        s_running = 0;
        MotorsApp_StopAll();
        log1("APP: mat link HC-12 o Manual > 2 s - DUNG\r\n");
    }

    /* 6) FSM 10 Hz + ap muc tieu */
    if ((now - s_last_fsm_ms) >= 100U) {
        s_last_fsm_ms = now;
        vl53_3data_t d = VL53_3_Get();
        (void)NavFsm_Update(&d, now);
        if (s_running && !s_safe_latch) {
            if (s_mode_auto) NavFsm_Apply();
            else apply_manual_targets();
        }
    }

    /* 7) Khoi phuc cam bien offline - chi khi dang dung (Recover
       blocking vai giay, chap nhan duoc luc dung), toi da 3 lan/con */
    if (!s_running && (now >= s_recover_next_ms)) {
        s_recover_next_ms = now + RECOVER_RETRY_MS;
        vl53_3data_t d = VL53_3_Get();
        for (uint8_t i = 0; i < VL53_NUM_SENSORS; i++) {
            if (!d.online[i] && s_recover_tries[i] < RECOVER_MAX_TRIES) {
                s_recover_tries[i]++;
                char b[64];
                snprintf(b, sizeof(b),
                         "APP: thu khoi phuc cam bien %u (lan %u)\r\n",
                         (unsigned)(i + 1), (unsigned)s_recover_tries[i]);
                log1(b);
                (void)VL53_3_Recover(i);
                break;              /* moi chu ky thu 1 con */
            }
        }
    }

    /* 8) Telemetry 5 Hz + CSV debug USART1 5 Hz */
    if ((now - s_last_tx_ms) >= 200U) {
        s_last_tx_ms = now;
        vl53_3data_t d = VL53_3_Get();
        telem_state_t st;
        st.mode = s_mode_auto;
        st.fsm = (uint8_t)NavFsm_State();
        st.running = s_running;
        for (int i = 0; i < 3; i++) st.dist_mm[i] = (int16_t)d.mm[i];
        MotorsApp_GetTelemetry(st.pwm_pct, st.rpm, NULL);
        /* Am thanh (G5 da ghep): muc 0-100 + bao dong hop nhat
           (muc > 80 HOAC phat hien mau tieng keu cuu SOS). */
        {
            sound_app_stats_t ss;
            SoundApp_GetStats(&ss);
            st.sound_level = ss.level;
            st.sound_alarm = (ss.level_alarm || ss.sos_alarm) ? 1 : 0;
            if (ss.sos_events != s_sos_events_seen) {
                s_sos_events_seen = ss.sos_events;
                char b[96];
                snprintf(b, sizeof(b),
                         "SOS: NGHI NGO TIENG KEU CUU (su kien #%lu, "
                         "nen %.1f dBFS)\r\n",
                         (unsigned long)ss.sos_events,
                         (double)ss.sos_floor_dbfs);
                log1(b);
            }
        }
        Telemetry_SendState(&st);
        VL53_3_PrintCsv();
        /* Dong MOT cho dashboard tong hop tren USART1 (bench co day):
           moi dong co 4 so: pwm(phan nghin), rpm_x10, rev_x1000, flags
           MOT,p1,r1,v1,f1, p2,r2,v2,f2, p3,r3,v3,f3, p4,r4,v4,f4      */
        {
            int16_t pm[4];
            int32_t rx[4];
            int64_t rv[4];
            uint32_t fl[4];
            char b[288];
            MotorsApp_GetBench(pm, rx, rv, fl);
            snprintf(b, sizeof(b),
                     "MOT,%d,%ld,%lld,%lu,%d,%ld,%lld,%lu,"
                     "%d,%ld,%lld,%lu,%d,%ld,%lld,%lu\r\n",
                     (int)pm[0], (long)rx[0], (long long)rv[0],
                     (unsigned long)fl[0],
                     (int)pm[1], (long)rx[1], (long long)rv[1],
                     (unsigned long)fl[1],
                     (int)pm[2], (long)rx[2], (long long)rv[2],
                     (unsigned long)fl[2],
                     (int)pm[3], (long)rx[3], (long long)rv[3],
                     (unsigned long)fl[3]);
            log1(b);
        }
        /* Dong SND cho bench hieu chuan am thanh tren USART1:
           SND,muc,bao_muc,bao_sos,su_kien_sos,nen_sos_dBFSx10,chay_dma
           (dashboard cu bo qua dong khong nhan dien duoc) */
        {
            sound_app_stats_t ss;
            char b[96];
            SoundApp_GetStats(&ss);
            snprintf(b, sizeof(b), "SND,%u,%u,%u,%lu,%ld,%u\r\n",
                     (unsigned)ss.level, (unsigned)ss.level_alarm,
                     (unsigned)ss.sos_alarm,
                     (unsigned long)ss.sos_events,
                     (long)(ss.sos_floor_dbfs * 10.0f),
                     (unsigned)ss.running);
            log1(b);
        }
    }
}
