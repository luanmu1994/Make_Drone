/**
 ******************************************************************************
 * @file    vl53l0x_min.c  (BAN 3 CAM BIEN - ST-FLOW v5 MULTI)
 * @brief   Xem vl53l0x_min.h. Moi truy cap deu qua HAL_I2C_Mem_Write/Read
 *          tren hi2c1, dia chi thanh ghi 8-bit (dung LSByte nhu cac ban port
 *          cong khai - VL53L0X dung dia chi thanh ghi 8-bit trong thuc te).
 *          Ban nay la driver v5 da chung minh tren 1 cam bien, refactor
 *          sang da thiet bi (VL53M_Dev) de chay 3 cam bien cung bus.
 ******************************************************************************
 */
#include "vl53l0x_min.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1;

/* Mot so thanh ghi dung nhieu lan */
#define REG_SYSRANGE_START            0x00
#define REG_SYSTEM_INTERRUPT_CLEAR    0x0B
#define REG_RESULT_INTERRUPT_STATUS   0x13
#define REG_RESULT_RANGE_STATUS       0x14
#define REG_RESULT_DISTANCE           0x1E  /* RESULT_RANGE_STATUS + 10 */
#define REG_IDENTIFICATION_MODEL_ID   0xC0
#define REG_VHV_CFG_EXTSUP_HV         0x89
#define REG_GLOBAL_SPAD_EN_REF_0      0xB0
#define REG_GLOBAL_REF_EN_START_SEL   0xB6
#define REG_DYNAMIC_SPAD_START_OFFSET 0x4F
#define REG_DYNAMIC_SPAD_NUM_REQ      0x4E

/* BAN 3 CAM BIEN: toan bo trang thai tung cam bien nam trong VL53M_Dev
   (khai bao o vl53l0x_min.h). s_dev tro toi thiet bi dang duoc truy cap;
   moi ham cong khai cua driver deu gan s_dev truoc khi lam viec. */
static VL53M_Dev *s_dev;

/* AUDIT v4: them du lieu chan doan doc tu khoi ket qua 12 byte (giong
   VL53L0X_GetRangingMeasurementData cua ST) + thong tin SPAD/seq-config
   luc init, de biet photon co ve that khong thay vi chi biet err/raw. */
/* ST-FLOW v5: ket qua cua PerformRefSpadManagement + PerformRefCalibration
   port tu ST API (vl53l0x_api_calibration.c) - xem phan ST-FLOW ben duoi. */
/* Chan doan v3: lan do gan nhat tac o buoc nao + gia tri thanh ghi luc tac
   stage: 0=OK, 1=loi I2C khi khoi dong do, 2=timeout cho bit start xoa,
          3=timeout cho interrupt ket qua, 4=loi doc status, 5=loi doc
          khoang cach, 6=loi laser (err 1/2), 7=raw>=8190 (khong co vat) */

/* ------------------------------------------------------------ I2C tho --- */
/* v3.1: moi giao dich I2C duoc thu lai 1 lan sau 1 ms neu that bai -
   chong nhieu/NACK thoang qua tren bus (da tung ghi nhan stage=1). */
static bool wr(uint8_t reg, uint8_t val)
{
    for (int t = 0; t < 2; t++) {
        if (HAL_I2C_Mem_Write(&hi2c1, ((uint16_t)s_dev->addr7 << 1), reg,
                              I2C_MEMADD_SIZE_8BIT, &val, 1, 100) == HAL_OK)
            return true;
        HAL_Delay(1);
    }
    return false;
}

static bool wr_buf(uint8_t reg, const uint8_t *buf, uint16_t n)
{
    for (int t = 0; t < 2; t++) {
        if (HAL_I2C_Mem_Write(&hi2c1, ((uint16_t)s_dev->addr7 << 1), reg,
                              I2C_MEMADD_SIZE_8BIT, (uint8_t *)buf, n,
                              100) == HAL_OK)
            return true;
        HAL_Delay(1);
    }
    return false;
}

static bool rd(uint8_t reg, uint8_t *val)
{
    for (int t = 0; t < 2; t++) {
        if (HAL_I2C_Mem_Read(&hi2c1, ((uint16_t)s_dev->addr7 << 1), reg,
                             I2C_MEMADD_SIZE_8BIT, val, 1, 100) == HAL_OK)
            return true;
        HAL_Delay(1);
    }
    return false;
}

static bool rd_buf(uint8_t reg, uint8_t *buf, uint16_t n)
{
    for (int t = 0; t < 2; t++) {
        if (HAL_I2C_Mem_Read(&hi2c1, ((uint16_t)s_dev->addr7 << 1), reg,
                             I2C_MEMADD_SIZE_8BIT, buf, n, 100) == HAL_OK)
            return true;
        HAL_Delay(1);
    }
    return false;
}

static bool rd16(uint8_t reg, uint16_t *val)
{
    uint8_t b[2];
    if (!rd_buf(reg, b, 2)) return false;
    *val = ((uint16_t)b[0] << 8) | b[1];
    return true;
}

static bool wait_bit_clear(uint8_t reg, uint8_t mask)
{
    uint32_t t0 = HAL_GetTick();
    uint8_t v;
    do {
        if (!rd(reg, &v)) return false;
        if ((v & mask) == 0) return true;
    } while ((HAL_GetTick() - t0) < VL53M_TIMEOUT_MS);
    return false;
}

/* ------------------------------------------------- SPAD (theo Pololu) --- */
static bool get_spad_info(uint8_t *count, uint8_t *is_aperture)
{
    uint8_t tmp;
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!wr(0xFF, 0x06)) return false;
    if (!rd(0x83, &tmp))  return false;
    if (!wr(0x83, tmp | 0x04)) return false;
    if (!wr(0xFF, 0x07)) return false;
    if (!wr(0x81, 0x01)) return false;
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0x94, 0x6b)) return false;
    if (!wr(0x83, 0x00)) return false;

    uint32_t t0 = HAL_GetTick();
    do {
        if (!rd(0x83, &tmp)) return false;
        if (tmp != 0x00) break;
        if ((HAL_GetTick() - t0) >= VL53M_TIMEOUT_MS) return false;
    } while (1);

    if (!wr(0x83, 0x01)) return false;
    if (!rd(0x92, &tmp)) return false;
    *count = tmp & 0x7F;
    *is_aperture = (tmp >> 7) & 0x01;

    if (!wr(0x81, 0x00)) return false;
    if (!wr(0xFF, 0x06)) return false;
    if (!rd(0x83, &tmp)) return false;
    if (!wr(0x83, tmp & ~0x04)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(0x80, 0x00)) return false;
    return true;
}

static bool set_reference_spads(uint8_t count, uint8_t is_aperture)
{
    uint8_t ref_spad_map[6];
    if (!rd_buf(REG_GLOBAL_SPAD_EN_REF_0, ref_spad_map, 6)) return false;

    if (!wr(0xFF, 0x01)) return false;
    if (!wr(REG_DYNAMIC_SPAD_START_OFFSET, 0x00)) return false;
    if (!wr(REG_DYNAMIC_SPAD_NUM_REQ, 0x2C)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(REG_GLOBAL_REF_EN_START_SEL, 0xB4)) return false;

    uint8_t first = is_aperture ? 12 : 0;
    uint8_t enabled = 0;
    for (uint8_t i = 0; i < 48; i++) {
        if (i < first || enabled == count) {
            ref_spad_map[i / 8] &= ~(1U << (i % 8));
        } else if ((ref_spad_map[i / 8] >> (i % 8)) & 0x01) {
            enabled++;
        }
    }
    return wr_buf(REG_GLOBAL_SPAD_EN_REF_0, ref_spad_map, 6);
}

/* ================= ST-FLOW v5: port tu vl53l0x_api_calibration.c ==========
   Muc dich: chay DUNG 2 thu tuc cua ST ma ban rut gon truoc day bo qua -
   PerformRefSpadManagement (tu suy ra so SPAD bang do tin hieu tham chieu
   noi bo, thay vi tin mu NVM) va PerformRefCalibration (VHV + phase).
   Logic sao chep tung buoc tu ma nguon ST, chi thay VL53L0X_WrByte/RdByte
   bang wr/rd cua driver nay. */

static bool rd32(uint8_t reg, uint32_t *val)
{
    uint8_t b[4];
    if (!rd_buf(reg, b, 4)) return false;
    *val = ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) |
           ((uint32_t)b[2] << 8) | b[3];
    return true;
}

/* Doc NVM "good spad map" nhu VL53L0X_get_info_from_device cua ST:
   cung phien truy cap 0x94, ma 0x24/0x25 doc tai 0x90. */
static bool get_good_spad_map(uint8_t map[6])
{
    uint8_t tmp;
    uint32_t dw;
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!wr(0xFF, 0x06)) return false;
    if (!rd(0x83, &tmp))  return false;
    if (!wr(0x83, tmp | 0x04)) return false;
    if (!wr(0xFF, 0x07)) return false;
    if (!wr(0x81, 0x01)) return false;
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0x94, 0x24)) return false;
    if (!rd32(0x90, &dw)) return false;
    map[0] = (uint8_t)(dw >> 24); map[1] = (uint8_t)(dw >> 16);
    map[2] = (uint8_t)(dw >> 8);  map[3] = (uint8_t)(dw);
    if (!wr(0x94, 0x25)) return false;
    if (!rd32(0x90, &dw)) return false;
    map[4] = (uint8_t)(dw >> 24); map[5] = (uint8_t)(dw >> 16);
    if (!wr(0x81, 0x00)) return false;
    if (!wr(0xFF, 0x06)) return false;
    if (!rd(0x83, &tmp))  return false;
    if (!wr(0x83, tmp & ~0x04)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(0x80, 0x00)) return false;
    return true;
}

static uint8_t spad_is_aperture(uint32_t idx)
{
    static const uint8_t quadrants[4] = { 10, 5, 0, 5 };
    return (quadrants[idx >> 6] == 0) ? 0 : 1;
}

static void get_next_good_spad(const uint8_t good[], uint32_t size,
                               uint32_t curr, int32_t *next)
{
    *next = -1;
    for (uint32_t coarse = curr / 8; coarse < size; coarse++) {
        uint32_t fine_start = (coarse == curr / 8) ? (curr % 8) : 0;
        uint8_t data = good[coarse];
        data >>= fine_start;
        for (uint32_t fine = fine_start; fine < 8; fine++) {
            if (data & 0x01) { *next = (int32_t)(coarse * 8 + fine); return; }
            data >>= 1;
        }
    }
}

static bool enable_spad_bit(uint8_t arr[], uint32_t size, uint32_t idx)
{
    if (idx / 8 >= size) return false;
    arr[idx / 8] |= (uint8_t)(1U << (idx % 8));
    return true;
}

static bool set_ref_spad_map(const uint8_t arr[6])
{
    return wr_buf(REG_GLOBAL_SPAD_EN_REF_0, arr, 6);
}

static bool enable_ref_spads(uint8_t aperture, const uint8_t good[],
                             uint8_t arr[], uint32_t start, uint32_t offset,
                             uint32_t count, uint32_t *last_spad)
{
    uint32_t current = offset;
    for (uint32_t i = 0; i < count; i++) {
        int32_t next = -1;
        get_next_good_spad(good, 6, current, &next);
        if (next == -1) return false;
        if (spad_is_aperture(start + (uint32_t)next) != aperture) return false;
        current = (uint32_t)next;
        if (!enable_spad_bit(arr, 6, current)) return false;
        current++;
    }
    *last_spad = current;
    if (!set_ref_spad_map(arr)) return false;
    uint8_t check[6];
    if (!rd_buf(REG_GLOBAL_SPAD_EN_REF_0, check, 6)) return false;
    for (int i = 0; i < 6; i++) if (arr[i] != check[i]) return false;
    return true;
}

/* 1 phien do single-shot tho (chi cho hoan tat, khong xu ly ket qua) */
static bool measure_single_raw(void)
{
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!wr(0x91, s_dev->stop_variable)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(0x80, 0x00)) return false;
    if (!wr(REG_SYSRANGE_START, 0x01)) return false;
    if (!wait_bit_clear(REG_SYSRANGE_START, 0x01)) return false;
    uint32_t t0 = HAL_GetTick();
    uint8_t st;
    do {
        if (!rd(REG_RESULT_INTERRUPT_STATUS, &st)) return false;
        if ((st & 0x07) != 0) break;
        if ((HAL_GetTick() - t0) >= VL53M_TIMEOUT_MS) return false;
    } while (1);
    return wr(REG_SYSTEM_INTERRUPT_CLEAR, 0x01);
}

/* VL53L0X_perform_single_ref_calibration */
static bool perform_single_ref_cal(uint8_t vhv_init_byte)
{
    if (!wr(REG_SYSRANGE_START, 0x01 | vhv_init_byte)) return false;
    uint32_t t0 = HAL_GetTick();
    uint8_t st;
    do {
        if (!rd(REG_RESULT_INTERRUPT_STATUS, &st)) return false;
        if ((st & 0x07) != 0) break;
        if ((HAL_GetTick() - t0) >= VL53M_TIMEOUT_MS) return false;
    } while (1);
    if (!wr(REG_SYSTEM_INTERRUPT_CLEAR, 0x01)) return false;
    return wr(REG_SYSRANGE_START, 0x00);
}

/* VL53L0X_perform_ref_calibration (VHV -> phase, doc nguoc gia tri) */
static bool perform_ref_calibration(uint8_t *vhv_out, uint8_t *phase_out)
{
    uint8_t saved_seq;
    if (!rd(0x01, &saved_seq)) return false;
    /* VHV: seq config = 0x01, start kem byte 0x40 */
    if (!wr(0x01, 0x01)) return false;
    if (!perform_single_ref_cal(0x40)) return false;
    /* Phase: seq config = 0x02, start byte 0x00 */
    if (!wr(0x01, 0x02)) return false;
    if (!perform_single_ref_cal(0x00)) return false;
    /* Doc nguoc VHV (0xCB) + Phase (0xEE) nhu ref_calibration_io cua ST */
    uint8_t ph = 0;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!rd(0xCB, vhv_out)) return false;
    if (!rd(0xEE, &ph)) return false;
    *phase_out = ph & 0xEF;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    return wr(0x01, saved_seq);
}

/* VL53L0X_perform_ref_signal_measurement: seq 0xC0, do 1 lan,
   doc RESULT_PEAK_SIGNAL_RATE_REF (0xB6, trang FF=01). */
static bool perform_ref_signal_measurement(uint16_t *peak)
{
    uint8_t saved_seq;
    if (!rd(0x01, &saved_seq)) return false;
    if (!wr(0x01, 0xC0)) return false;
    if (!measure_single_raw()) { (void)wr(0x01, saved_seq); return false; }
    if (!wr(0xFF, 0x01)) return false;
    if (!rd16(0xB6, peak)) return false;
    if (!wr(0xFF, 0x00)) return false;
    return wr(0x01, saved_seq);
}

static uint32_t absdiff_u16(uint16_t a, uint16_t b)
{
    return (a > b) ? (uint32_t)(a - b) : (uint32_t)(b - a);
}

/* VL53L0X_perform_ref_spad_management - port nguyen logic cua ST */
static bool perform_ref_spad_management(uint32_t *out_count,
                                        uint8_t *out_aperture)
{
    const uint32_t start_select = 0xB4;
    const uint32_t min_count = 3, max_count = 44;
    const uint16_t target = 0x0A00;    /* 20 MCPS o dang 9.7 */
    uint8_t enables[6] = { 0, 0, 0, 0, 0, 0 };
    uint8_t last_arr[6];
    uint32_t current = 0, last = 0;
    uint32_t need_apt = 0;
    uint16_t peak = 0;
    uint8_t vhv, phase;

    if (!wr(0xFF, 0x01)) return false;
    if (!wr(REG_DYNAMIC_SPAD_START_OFFSET, 0x00)) return false;
    if (!wr(REG_DYNAMIC_SPAD_NUM_REQ, 0x2C)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(REG_GLOBAL_REF_EN_START_SEL, 0xB4)) return false;
    if (!wr(0x80, 0x00)) return false;   /* POWER_MANAGEMENT_GO1 = 0 */

    /* ST chay ref calibration ngay trong thu tuc nay */
    if (!perform_ref_calibration(&vhv, &phase)) return false;
    s_dev->vhv_settings = vhv; s_dev->phase_cal = phase; s_dev->refcal_ok = true;

    /* Bat so SPAD non-aperture toi thieu */
    if (!enable_ref_spads(0, s_dev->good_map, enables, start_select,
                          current, min_count, &last)) return false;
    current = last;
    if (!perform_ref_signal_measurement(&peak)) return false;
    s_dev->mgmt_peak = peak;

    if (peak > target) {
        /* Qua manh voi non-aperture -> chuyen sang aperture */
        memset(enables, 0, sizeof(enables));
        while ((spad_is_aperture(start_select + current) == 0) &&
               (current < max_count)) current++;
        need_apt = 1;
        if (!enable_ref_spads(1, s_dev->good_map, enables, start_select,
                              current, min_count, &last)) return false;
        current = last;
        if (!perform_ref_signal_measurement(&peak)) return false;
        s_dev->mgmt_peak = peak;
        if (peak > target) {
            *out_count = min_count;
            *out_aperture = 1;
            return true;
        }
    }

    if (peak < target) {
        uint32_t ref_count = min_count;
        uint8_t is_apt = (uint8_t)need_apt;
        memcpy(last_arr, enables, 6);
        uint32_t last_diff = absdiff_u16(peak, target);
        bool complete = false;
        while (!complete) {
            int32_t next = -1;
            get_next_good_spad(s_dev->good_map, 6, current, &next);
            if (next == -1) return false;
            ref_count++;
            if (spad_is_aperture(start_select + (uint32_t)next) != need_apt)
                return false;
            current = (uint32_t)next;
            if (!enable_spad_bit(enables, 6, current)) return false;
            current++;
            if (!set_ref_spad_map(enables)) return false;
            if (!perform_ref_signal_measurement(&peak)) return false;
            s_dev->mgmt_peak = peak;
            uint32_t diff = absdiff_u16(peak, target);
            if (peak > target) {
                if (diff > last_diff) {
                    if (!set_ref_spad_map(last_arr)) return false;
                    ref_count--;
                }
                complete = true;
            } else {
                last_diff = diff;
                memcpy(last_arr, enables, 6);
            }
        }
        *out_count = ref_count;
        *out_aperture = is_apt;
        return true;
    }

    /* peak == target dung luc toi thieu */
    *out_count = min_count;
    *out_aperture = (uint8_t)need_apt;
    return true;
}

/* ------------------------------------- Bang tuning mac dinh cua ST/Pololu */
static const uint8_t TUNING[][2] = {
    {0xFF,0x01},{0x00,0x00},{0xFF,0x00},{0x09,0x00},{0x10,0x00},{0x11,0x00},
    {0x24,0x01},{0x25,0xFF},{0x75,0x00},
    {0xFF,0x01},{0x4E,0x2C},{0x48,0x00},{0x30,0x20},
    {0xFF,0x00},{0x30,0x09},{0x54,0x00},{0x31,0x04},{0x32,0x03},{0x40,0x83},
    {0x46,0x25},{0x60,0x00},{0x27,0x00},{0x50,0x06},{0x51,0x00},{0x52,0x96},
    {0x56,0x08},{0x57,0x30},{0x61,0x00},{0x62,0x00},{0x64,0x00},{0x65,0x00},
    {0x66,0xA0},
    {0xFF,0x01},{0x22,0x32},{0x47,0x14},{0x49,0xFF},{0x4A,0x00},
    {0xFF,0x00},{0x7A,0x0A},{0x7B,0x00},{0x78,0x21},
    {0xFF,0x01},{0x23,0x34},{0x42,0x00},{0x44,0xFF},{0x45,0x26},{0x46,0x05},
    {0x40,0x40},{0x0E,0x06},{0x20,0x1A},{0x43,0x40},
    {0xFF,0x00},{0x34,0x03},{0x35,0x44},
    {0xFF,0x01},{0x31,0x04},{0x4B,0x09},{0x4C,0x05},{0x4D,0x04},
    {0xFF,0x00},{0x44,0x00},{0x45,0x20},{0x47,0x08},{0x48,0x28},{0x67,0x00},
    {0x70,0x04},{0x71,0x01},{0x72,0xFE},{0x76,0x00},{0x77,0x00},
    {0xFF,0x01},{0x0D,0x01},
    {0xFF,0x00},{0x80,0x01},{0x01,0xF8},
    {0xFF,0x01},{0x8E,0x01},{0x00,0x01},{0xFF,0x00},{0x80,0x00},
};

/* ---------------------------------------------------------------- Init --- */
bool VL53M_Init(VL53M_Dev *dev, uint8_t new_addr7)
{
    uint8_t id, hv, spad_count, is_aperture;
    GPIO_TypeDef *xshut_port = dev->xshut_port;   /* app dat truoc khi goi */
    uint16_t xshut_pin = dev->xshut_pin;

    s_dev = dev;
    memset(dev, 0, sizeof(*dev));
    dev->xshut_port = xshut_port;
    dev->xshut_pin = xshut_pin;
    dev->addr7 = VL53M_DEFAULT_ADDR7;             /* luc boot luon la 0x29 */

    /* Keo XSHUT cua cam bien nay len cho no boot - cac cam bien con lai
       phai dang tat (app dam bao) de chi co 1 con o dia chi 0x29. */
    HAL_GPIO_WritePin(dev->xshut_port, dev->xshut_pin, GPIO_PIN_SET);
    HAL_Delay(10);                                /* cho boot xong */

    /* Chan doan stage: init dung o buoc nao thi init_stage giu so buoc do
       (0 = OK). id_byte = 0xFF nghia la chua doc duoc ID lan nao. */
    dev->id_byte = 0xFF;
    dev->init_stage = 1;                          /* doc Model ID */
    if (!rd(REG_IDENTIFICATION_MODEL_ID, &id)) return false;
    dev->id_byte = id;
    dev->init_stage = 2;                          /* ID sai */
    if (id != 0xEE) return false;                    /* khong phai VL53L0X */

    /* I2C IO o che do 2.8V (mac dinh cua Pololu init(true)) */
    dev->init_stage = 3;
    if (!rd(REG_VHV_CFG_EXTSUP_HV, &hv)) return false;
    if (!wr(REG_VHV_CFG_EXTSUP_HV, hv | 0x01)) return false;

    dev->init_stage = 4;                          /* data-init / stop var */
    if (!wr(0x88, 0x00)) return false;               /* I2C standard mode */

    /* Data-init: lay stop_variable (theo API/Pololu) */
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!rd(0x91, &s_dev->stop_variable)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(0x80, 0x00)) return false;

    /* Gan dia chi I2C moi cho cam bien nay (reg 0x8A) roi xac nhan lai
       Model ID tai dia chi moi. Moi buoc sau chay o dia chi moi, nen
       cam bien tiep theo lai duoc bat o 0x29 ma khong xung dot. */
    dev->init_stage = 5;                          /* gan dia chi moi */
    if (new_addr7 != VL53M_DEFAULT_ADDR7) {
        if (!wr(0x8A, (uint8_t)(new_addr7 & 0x7F))) return false;
        dev->addr7 = new_addr7;
        if (!rd(REG_IDENTIFICATION_MODEL_ID, &id)) return false;
        if (id != 0xEE) return false;
    }

    dev->init_stage = 6;                          /* SPAD info / good map */
    if (!get_spad_info(&spad_count, &is_aperture)) return false;
    s_dev->spad_count = spad_count;         /* AUDIT v4: luu lai de app in dump */
    s_dev->spad_aperture = is_aperture;
    /* ST-FLOW v5: KHONG set SPAD theo NVM o day nua - viec chon SPAD de
       cho PerformRefSpadManagement o cuoi Init (giong flow cua ST).
       Doc san NVM good spad map cho thu tuc do dung. */
    if (!get_good_spad_map(s_dev->good_map))
        memset(s_dev->good_map, 0xFF, sizeof(s_dev->good_map));   /* fallback all-good */

    dev->init_stage = 7;                          /* tuning + cau hinh */
    for (unsigned i = 0; i < (sizeof(TUNING) / sizeof(TUNING[0])); i++)
        if (!wr(TUNING[i][0], TUNING[i][1])) return false;

    /* Gioi han signal rate 0.25 MCPS (FixPoint 7.9 -> 0.25 * 128 = 32) */
    {
        uint8_t b[2] = { 0x00, 0x20 };
        if (!wr_buf(0x44, b, 2)) return false;
    }

    /* Interrupt "new sample ready" + GPIO active-low (ta doc polling,
       cau hinh nay chi de trang thai cam bien nhat quan nhu Pololu). */
    if (!wr(0x0A, 0x04)) return false;
    if (!rd(0x84, &hv)) return false;
    if (!wr(0x84, hv & ~0x10)) return false;
    if (!wr(REG_SYSTEM_INTERRUPT_CLEAR, 0x01)) return false;

    /* AUDIT v4 - SUA THEO ST StaticInit: sau khi nap tuning (0x01 = 0xF8),
       ST TAT 2 buoc TCC (bit 0x10) va MSRC (bit 0x04) trong
       SYSTEM_SEQUENCE_CONFIG, trang thai cuoi = 0xE8. Ban cu de nguyen
       0xF8 (TCC van bat) - day la khac biet that giua driver nay va flow
       chinh thuc cua ST, ap dung de A/B test tren may that. */
    {
        uint8_t seq;
        if (!rd(0x01, &seq)) return false;
        seq &= (uint8_t)~0x10;         /* tat TCC  */
        seq &= (uint8_t)~0x04;         /* tat MSRC */
        if (!wr(0x01, seq)) return false;
        s_dev->seq_config = seq;
    }

    /* ST-FLOW v5: chay 2 thu tuc cua ST ma cac ban truoc bo qua.
       1) PerformRefSpadManagement: tu suy ra so SPAD bang cach do tin
          hieu tham chieu NOI BO (khong can vat ngoai) - neu ca NVM lan
          thu tuc nay deu khong ra duoc tin hieu thi phia thu co van de
          that, khong con la cau hinh nua.
       2) PerformRefCalibration (VHV + phase) - da chay ben trong (1),
          chi chay rieng neu (1) that bai truoc khi kip goi no.      */
    {
        uint32_t mc = 0;
        uint8_t ma = 0;
        dev->init_stage = 8;                      /* SPAD mgmt / ref cal */
        s_dev->mgmt_ok = perform_ref_spad_management(&mc, &ma);
        if (s_dev->mgmt_ok) {
            s_dev->mgmt_count = mc;
            s_dev->mgmt_aperture = ma;
        } else {
            /* Fallback: quay ve hanh vi ban cu (SPAD theo NVM) de van
               do tiep duoc va co log doi chieu. */
            if (!set_reference_spads(spad_count, is_aperture)) return false;
        }
        if (!s_dev->refcal_ok) {
            uint8_t vhv = 0, phase = 0;
            if (perform_ref_calibration(&vhv, &phase)) {
                s_dev->vhv_settings = vhv;
                s_dev->phase_cal = phase;
                s_dev->refcal_ok = true;
            }
        }
    }
    dev->init_stage = 0;                          /* OK */
    return true;
}

/* Tat cam bien bang XSHUT (giu o muc thap = tat han) */
void VL53M_Shutdown(VL53M_Dev *dev)
{
    HAL_GPIO_WritePin(dev->xshut_port, dev->xshut_pin, GPIO_PIN_RESET);
}

uint8_t VL53M_InitStage(const VL53M_Dev *dev) { return dev->init_stage; }
uint8_t VL53M_IdByte(const VL53M_Dev *dev)    { return dev->id_byte; }

bool VL53M_ProbeAddr(uint8_t addr7)
{
    return HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)addr7 << 1, 3, 100)
           == HAL_OK;
}

/* ----------------------------------------------------------------- Read -- */
bool VL53M_ReadMm(VL53M_Dev *dev, int32_t *out_mm)
{
    s_dev = dev;
    uint8_t status;
    uint16_t mm;

    /* Khoi dong single-shot (dung stop_variable nhu API/Pololu) */
    s_dev->stage = 1;
    if (!wr(0x80, 0x01)) return false;
    if (!wr(0xFF, 0x01)) return false;
    if (!wr(0x00, 0x00)) return false;
    if (!wr(0x91, s_dev->stop_variable)) return false;
    if (!wr(0x00, 0x01)) return false;
    if (!wr(0xFF, 0x00)) return false;
    if (!wr(0x80, 0x00)) return false;
    if (!wr(REG_SYSRANGE_START, 0x01)) return false;

    /* Cho thiet bi san sang: bit SYSRANGE_START tu xoa */
    s_dev->stage = 2;
    if (!wait_bit_clear(REG_SYSRANGE_START, 0x01)) {
        (void)rd(REG_SYSRANGE_START, &s_dev->start_reg);
        return false;
    }

    /* Cho co ket qua */
    s_dev->stage = 3;
    {
        uint32_t t0 = HAL_GetTick();
        do {
            if (!rd(REG_RESULT_INTERRUPT_STATUS, &status)) return false;
            s_dev->int_reg = status;
            if ((status & 0x07) != 0) break;
            if ((HAL_GetTick() - t0) >= VL53M_TIMEOUT_MS) {
                (void)rd(REG_SYSRANGE_START, &s_dev->start_reg);
                return false;
            }
        } while (1);
    }

    /* AUDIT v4: doc ca khoi 12 byte tu 0x14 nhu ST GetRangingMeasurementData
       (truoc day chi doc status + khoang cach, vut mat signal/ambient/SPAD):
         [0]=range status  [2..3]=EffectiveSpadRtnCount (8.8)
         [6..7]=SignalRate (9.7)  [8..9]=AmbientRate (9.7)  [10..11]=mm   */
    s_dev->stage = 4;
    {
        uint8_t blk[12];
        if (!rd_buf(REG_RESULT_RANGE_STATUS, blk, 12)) return false;
        status = blk[0];
        s_dev->last_status = status;
        s_dev->last_spad_rtn = ((uint16_t)blk[2] << 8) | blk[3];
        s_dev->last_signal   = ((uint16_t)blk[6] << 8) | blk[7];
        s_dev->last_ambient  = ((uint16_t)blk[8] << 8) | blk[9];
        mm = ((uint16_t)blk[10] << 8) | blk[11];
    }
    s_dev->last_error = (status >> 3) & 0x1F;
    s_dev->stage = 5;
    (void)wr(REG_SYSTEM_INTERRUPT_CLEAR, 0x01);
    s_dev->last_raw = mm;

    /* v2: KHONG loai mau chi vi ma loi thiet bi khac 0. Phan lon ma
       (3=noVHV, 5=SNR, 6=phase, 7=sigma, 11=range complete...) chi la
       CANH BAO - chinh tai lieu/dien dan ST ghi nhan nhieu cam bien tra
       ma canh bao trong khi khoang cach van dung, va driver Pololu bo
       qua hoan toan ma nay. Chi loai khi:
         - loi phan cung laser that (1=VCSEL continuity, 2=watchdog)
         - gia tri sentinel khong-co-vat (>= 8190 mm). */
    if (s_dev->last_error == 1 || s_dev->last_error == 2) { s_dev->stage = 6; return false; }
    if (mm >= VL53M_NO_TARGET_MM)                { s_dev->stage = 7; return false; }
    s_dev->stage = 0;
    *out_mm = (int32_t)mm;
    return true;
}

uint8_t VL53M_LastDeviceError(const VL53M_Dev *dev) { return dev->last_error; }
uint16_t VL53M_LastRawMm(const VL53M_Dev *dev)    { return dev->last_raw; }
uint8_t VL53M_LastFailStage(const VL53M_Dev *dev) { return dev->stage; }
uint8_t VL53M_LastStartReg(const VL53M_Dev *dev)  { return dev->start_reg; }
uint8_t VL53M_LastIntReg(const VL53M_Dev *dev)    { return dev->int_reg; }
uint8_t  VL53M_SpadCount(const VL53M_Dev *dev)    { return dev->spad_count; }
uint8_t  VL53M_SpadIsAperture(const VL53M_Dev *dev) { return dev->spad_aperture; }
uint8_t  VL53M_SeqConfig(const VL53M_Dev *dev)    { return dev->seq_config; }
uint8_t  VL53M_LastStatusByte(const VL53M_Dev *dev) { return dev->last_status; }
uint16_t VL53M_LastSignalRaw(const VL53M_Dev *dev)  { return dev->last_signal; }
uint16_t VL53M_LastAmbientRaw(const VL53M_Dev *dev) { return dev->last_ambient; }
uint16_t VL53M_LastSpadRtnRaw(const VL53M_Dev *dev) { return dev->last_spad_rtn; }
bool     VL53M_MgmtOk(const VL53M_Dev *dev)       { return dev->mgmt_ok; }
uint32_t VL53M_MgmtCount(const VL53M_Dev *dev)    { return dev->mgmt_count; }
uint8_t  VL53M_MgmtAperture(const VL53M_Dev *dev) { return dev->mgmt_aperture; }
uint16_t VL53M_MgmtPeakRaw(const VL53M_Dev *dev)  { return dev->mgmt_peak; }
bool     VL53M_RefCalOk(const VL53M_Dev *dev)     { return dev->refcal_ok; }
uint8_t  VL53M_VhvSettings(const VL53M_Dev *dev)  { return dev->vhv_settings; }
uint8_t  VL53M_PhaseCal(const VL53M_Dev *dev)     { return dev->phase_cal; }
void     VL53M_GetGoodMap(const VL53M_Dev *dev, uint8_t out[6])
{
    memcpy(out, dev->good_map, 6);
}

bool VL53M_RdReg(VL53M_Dev *dev, uint8_t reg, uint8_t *val)
{
    s_dev = dev;
    return rd(reg, val);
}
bool VL53M_RdReg16(VL53M_Dev *dev, uint8_t reg, uint16_t *val)
{
    s_dev = dev;
    return rd16(reg, val);
}
bool VL53M_RdBuf(VL53M_Dev *dev, uint8_t reg, uint8_t *buf, uint16_t n)
{
    s_dev = dev;
    return rd_buf(reg, buf, n);
}
