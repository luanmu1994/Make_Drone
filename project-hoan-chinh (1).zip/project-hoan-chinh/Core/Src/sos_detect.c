/* PHAT HIEN TIENG KEU CUU - xem sos_detect.h */
#include "sos_detect.h"
#include <math.h>
#include <string.h>

/* --- Chuoi loc dai giong: HP 250 Hz -> LP 3400 Hz (Fs 16 kHz) ---
 * He so biquad RBJ Butterworth (Q = 1/sqrt(2)), da doi chieu dap
 * ung: 100 Hz con 0.16, 300 Hz 0.82, 1 kHz 1.00, 3 kHz 0.81,
 * 5.2 kHz con 0.23 (theo bien do). */
static const float HP_B[3] = { 0.93293216f, -1.86586431f, 0.93293216f };
static const float HP_A[2] = { -1.86136115f, 0.87036748f };
static const float LP_B[3] = { 0.22711796f, 0.45423593f, 0.22711796f };
static const float LP_A[2] = { -0.27666461f, 0.18513647f };

typedef struct { float x1, x2, y1, y2; } biquad_t;
static biquad_t s_hp, s_lp;

static float biquad_run(biquad_t *q, const float b[3], const float a[2], float x)
{
    float y = b[0] * x + b[1] * q->x1 + b[2] * q->x2
                       - a[0] * q->y1 - a[1] * q->y2;
    q->x2 = q->x1; q->x1 = x;
    q->y2 = q->y1; q->y1 = y;
    return y;
}

/* --- Trang thai --- */
static int32_t  s_carry[SOS_FRAME_SAMPLES];
static uint32_t s_carry_n;
static uint32_t s_frame_idx;          /* dong ho khung: 1 khung = 10 ms */
static float    s_floor;              /* RMS nen trong dai giong        */
static uint32_t s_events;
static uint32_t s_last_event_frame;
static uint32_t s_alarm_until_frame;

/* May trang thai burst */
static uint8_t  s_in_burst;
static uint8_t  s_burst_consumed;     /* burst da dung de kich hoat sustain */
static uint32_t s_burst_start_frame;  /* khung dau tien co tieng        */
static uint32_t s_burst_active;       /* so khung co tieng trong burst  */
static uint32_t s_burst_last_frame;   /* khung co tieng cuoi cung       */
static uint32_t s_gap_frames;         /* so khung yen lien tiep sau burst */

/* Chuoi khop mau */
static uint8_t  s_chain;
static uint32_t s_chain_first_start;
static uint32_t s_chain_last_end;

#define FRAME_MS  (1000u / (SOS_FS_HZ / SOS_FRAME_SAMPLES))   /* 10 */

static void kich_hoat(uint32_t now_frame)
{
    s_events++;
    s_last_event_frame = now_frame;
    s_alarm_until_frame = now_frame + SOS_ALARM_HOLD_MS / FRAME_MS;
    s_chain = 0;                      /* xoa chuoi, tranh kich lai lien tuc */
}

static void ket_thuc_burst(uint32_t now_frame)
{
    uint32_t dur_ms = s_burst_active * FRAME_MS;
    s_in_burst = 0;

    if (s_burst_consumed) return;     /* da bao o giua burst roi */
    if (dur_ms >= SOS_SUSTAIN_MS) {   /* tieng keu lien tuc dai */
        kich_hoat(now_frame);
        return;
    }
    if (dur_ms < SOS_BURST_MIN_MS || dur_ms > SOS_BURST_MAX_MS)
        return;                       /* qua ngan (vo tay) / qua dai khong dung mau */

    /* Burst hop le: dua vao chuoi khop mau */
    if (s_chain > 0) {
        uint32_t pause_ms = (s_burst_start_frame - s_chain_last_end) * FRAME_MS;
        uint32_t window_ms = (s_burst_last_frame - s_chain_first_start) * FRAME_MS;
        if (pause_ms < SOS_PAUSE_MIN_MS || pause_ms > SOS_PAUSE_MAX_MS ||
            window_ms > SOS_PATTERN_WINDOW_MS)
            s_chain = 0;              /* dut mau -> bat dau chuoi moi tu burst nay */
    }
    if (s_chain == 0) {
        s_chain = 1;
        s_chain_first_start = s_burst_start_frame;
    } else {
        s_chain++;
    }
    s_chain_last_end = s_burst_last_frame;

    if (s_chain >= SOS_PATTERN_BURSTS)
        kich_hoat(now_frame);
}

static void xu_ly_khung(const float *raw_sq_band_src, float rms_raw, float rms_band)
{
    uint32_t now = s_frame_idx;
    (void)raw_sq_band_src;

    float nguong = s_floor * (SOS_MARGIN_X100 / 100.0f);
    if (nguong < SOS_ABS_MIN_RMS) nguong = SOS_ABS_MIN_RMS;
    float ratio = (rms_raw > 1e-9f) ? (rms_band / rms_raw) : 0.0f;
    uint8_t co_tieng = (rms_band > nguong) &&
                       (ratio * 1000.0f > SOS_RATIO_MIN_X1000);

    /* Hoc nen on hai toc do, chi o khung khong co tieng:
     * - nen gan muc hien tai: EMA nhanh (tau ~ 5 s);
     * - nen lon hon han (dong co vua khoi dong): EMA rat cham
     *   (tau ~ 50 s) de nen moi duoc hoc trong nua phut chay xe
     *   ma mot tieng beep/het ngan vai giay khong kip nang nguong. */
    if (!co_tieng) {
        float alpha = (rms_band < s_floor * 1.5f) ? 0.002f : 0.0002f;
        s_floor += (rms_band - s_floor) * alpha;
        if (s_floor < SOS_ABS_MIN_RMS * 0.5f) s_floor = SOS_ABS_MIN_RMS * 0.5f;
        if (s_floor > 0.08f) s_floor = 0.08f;
    }

    if (co_tieng) {
        if (!s_in_burst) {
            s_in_burst = 1;
            s_burst_consumed = 0;
            s_burst_start_frame = now;
            s_burst_active = 0;
        }
        s_burst_active++;
        /* Kich hoat sustain NGAY khi burst dang keo dai du lau,
         * khong cho tieng keu ket thuc (nguoi keu co the da ngat). */
        if (!s_burst_consumed && s_burst_active * FRAME_MS >= SOS_SUSTAIN_MS) {
            s_burst_consumed = 1;
            kich_hoat(now);
        }
        s_burst_last_frame = now;
        s_gap_frames = 0;
    } else if (s_in_burst) {
        s_gap_frames++;
        if (s_gap_frames * FRAME_MS > SOS_GAP_MS)
            ket_thuc_burst(now);
    }

    s_frame_idx++;
}

void SOS_Init(void)
{
    memset(&s_hp, 0, sizeof(s_hp));
    memset(&s_lp, 0, sizeof(s_lp));
    s_carry_n = 0;
    s_frame_idx = 0;
    s_floor = 0.00562f;               /* -45 dBFS khoi tao */
    s_events = 0;
    s_last_event_frame = 0;
    s_alarm_until_frame = 0;
    s_in_burst = 0;
    s_burst_active = 0;
    s_gap_frames = 0;
    s_chain = 0;
}

void SOS_Feed(const int32_t *samples, uint32_t count)
{
    for (uint32_t i = 0; i < count; i++) {
        s_carry[s_carry_n++] = samples[i];
        if (s_carry_n < SOS_FRAME_SAMPLES) continue;
        s_carry_n = 0;

        double raw_sq = 0.0, band_sq = 0.0;
        for (int k = 0; k < SOS_FRAME_SAMPLES; k++) {
            float x = (float)s_carry[k] * (1.0f / 2147483648.0f);
            float y = biquad_run(&s_hp, HP_B, HP_A, x);
            y = biquad_run(&s_lp, LP_B, LP_A, y);
            raw_sq += (double)x * x;
            band_sq += (double)y * y;
        }
        float rms_raw = (float)sqrt(raw_sq / SOS_FRAME_SAMPLES);
        float rms_band = (float)sqrt(band_sq / SOS_FRAME_SAMPLES);
        xu_ly_khung(NULL, rms_raw, rms_band);
    }
}

uint8_t SOS_AlarmActive(void)
{
    return (s_frame_idx < s_alarm_until_frame) ? 1u : 0u;
}

void SOS_GetStats(sos_stats_t *out)
{
    if (!out) return;
    out->floor_dbfs = 20.0f * log10f(s_floor);
    out->event_count = s_events;
    out->last_event_ms = s_last_event_frame * FRAME_MS;
    out->chain_count = s_chain;
}
