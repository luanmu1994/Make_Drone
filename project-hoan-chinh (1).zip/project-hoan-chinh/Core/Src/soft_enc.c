/* BAN 4 MOTOR v2 - nhan dien file: dong nay phai o dau soft_enc.c */
#include "soft_enc.h"

/* Bang chuyen trang thai quadrature x4.
 * Trang thai s = (A<<1)|B. Chieu thuan (A som pha hon B):
 *   00 -> 10 -> 11 -> 01 -> 00 : moi buoc +1
 * Chieu nguoc: moi buoc -1. Buoc nhay 2 trang thai (00->11) la nhieu/
 * rung: cho 0. Index = (state_truoc << 2) | state_sau. */
static const int8_t quad_table[16] = {
    0, -1,  1,  0,
    1,  0,  0, -1,
   -1,  0,  0,  1,
    0,  1, -1,  0
};

static uint8_t soft_enc_read_state(const SoftEnc_t *e)
{
    uint8_t a = (HAL_GPIO_ReadPin(e->port_a, e->pin_a) == GPIO_PIN_SET) ? 1u : 0u;
    uint8_t b = (HAL_GPIO_ReadPin(e->port_b, e->pin_b) == GPIO_PIN_SET) ? 1u : 0u;
    return (uint8_t)((a << 1) | b);
}

void SoftEnc_Init(SoftEnc_t *e)
{
    e->delta = 0;
    e->total = 0;
    e->state = soft_enc_read_state(e);
}

void SoftEnc_OnEdge(SoftEnc_t *e)
{
    uint8_t now = soft_enc_read_state(e);
    int8_t step = quad_table[((uint8_t)(e->state << 2)) | now];
    e->state = now;
    if (step != 0) {
        e->delta += step;
        e->total += step;
    }
}

int32_t SoftEnc_TakeDelta(SoftEnc_t *e)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    int32_t d = e->delta;
    e->delta = 0;
    if (primask == 0u) __enable_irq();
    return d;
}
