/* BAN GHEP SOS v1 - nhan dien file: dong nay phai o dau sound_app.c
 * Xem sound_app.h, INMP441_I2S3.md va HUONG_DAN_PHAT_HIEN_KEU_CUU.md. */
#include "sound_app.h"
#include "main.h"
#include "sos_detect.h"
#include <math.h>
#include <string.h>

extern I2S_HandleTypeDef hi2s3;     /* CubeMX: SPI3 mode I2S, Master RX */
extern UART_HandleTypeDef huart1;   /* log debug co day 115200 */

/* Buffer DMA: khung stereo 32-bit (slot LEFT + slot RIGHT).
 * 1 khoi xu ly = nua buffer = 1600 khung = 100 ms o Fs 16 kHz,
 * dung kich thuoc khoi ma test PC cua sos_detect da dung (1600 mau).
 * Tong buffer = 6400 word32 = 25,6 KB RAM. */
#define SOUND_FRAMES_PER_BLOCK   1600u
#define SOUND_DMA_WORDS          (SOUND_FRAMES_PER_BLOCK * 2u * 2u)

static uint32_t s_dma_buf[SOUND_DMA_WORDS];
static int32_t  s_left[SOUND_FRAMES_PER_BLOCK];

static volatile uint8_t  s_running;
static volatile uint16_t s_level;
static volatile uint8_t  s_level_alarm;
static volatile uint32_t s_blocks;
static uint32_t s_alarm_until_ms;

static void log1(const char *s)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 100);
}

/* Xu ly 1 khoi 100 ms: raw tro toi SOUND_FRAMES_PER_BLOCK khung stereo
 * trong buffer DMA (moi khung = 2 word32: LEFT roi RIGHT). */
static void process_block(const uint32_t *raw)
{
    /* Tach slot LEFT. Word DMA cua khung 24-bit/32-bit la 24 bit du
     * lieu nam sat phia MSB, 8 bit thap = 0 - tuc chinh la mau 24-bit
     * dich trai ve thang int32 ma SOS_Feed yeu cau. Slot RIGHT bo qua
     * (L/R = GND nen mic khong ghi kenh phai). */
    double sum = 0.0;
    for (uint32_t i = 0; i < SOUND_FRAMES_PER_BLOCK; i++) {
        s_left[i] = (int32_t)raw[i * 2u];
        sum += (double)s_left[i];
    }
    double mean = sum / (double)SOUND_FRAMES_PER_BLOCK;

    /* Muc am: RMS sau khi tru DC (muc 3.2 cua tai lieu ky thuat 03).
     * Tinh tren chinh cac mau truoc khi nap SOS (SOS tu loc dai). */
    double sq = 0.0;
    for (uint32_t i = 0; i < SOUND_FRAMES_PER_BLOCK; i++) {
        double x = ((double)s_left[i] - mean) * (1.0 / 2147483648.0);
        sq += x * x;
    }
    double rms = sqrt(sq / (double)SOUND_FRAMES_PER_BLOCK);
    float dbfs = (rms > 1e-9) ? (float)(20.0 * log10(rms)) : -100.0f;
    float lv = (dbfs - SOUND_DBFS_AT_0) * 100.0f
             / (SOUND_DBFS_AT_100 - SOUND_DBFS_AT_0);
    if (lv < 0.0f) lv = 0.0f;
    if (lv > 100.0f) lv = 100.0f;
    s_level = (uint16_t)(lv + 0.5f);

    if (s_level > SOUND_ALARM_LEVEL)
        s_alarm_until_ms = HAL_GetTick() + SOUND_ALARM_HOLD_MS;
    s_level_alarm = (HAL_GetTick() < s_alarm_until_ms) ? 1u : 0u;

    /* Diem noi DUY NHAT voi sos_detect (dung huong dan ghep): */
    SOS_Feed(s_left, SOUND_FRAMES_PER_BLOCK);
    s_blocks++;
}

uint8_t SoundApp_Init(void)
{
    SOS_Init();
    s_running = 0;
    s_level = 0;
    s_level_alarm = 0;
    s_blocks = 0;
    s_alarm_until_ms = 0;
    memset(s_dma_buf, 0, sizeof(s_dma_buf));

    /* HAL I2S 32-bit: Size tinh theo word 32-bit cua khung, nen so
     * luong truyen = SOUND_DMA_WORDS (moi mau stereo chiem 1 word). */
    if (HAL_I2S_Receive_DMA(&hi2s3, (uint16_t *)s_dma_buf,
                            SOUND_DMA_WORDS) != HAL_OK) {
        log1("APP: SOUND I2S3 DMA khong chay - muc am giu 0, "
             "cac phan he khac chay binh thuong\r\n");
        return 0;
    }
    s_running = 1;
    log1("APP: SOUND INMP441 I2S3 + DMA + SOS da chay (Fs 16 kHz)\r\n");
    return 1;
}

uint16_t SoundApp_Level(void) { return s_level; }

uint8_t SoundApp_SosAlarm(void) { return SOS_AlarmActive(); }

uint8_t SoundApp_Alarm(void)
{
    return (s_level_alarm || SOS_AlarmActive()) ? 1u : 0u;
}

void SoundApp_GetStats(sound_app_stats_t *out)
{
    if (!out) return;
    sos_stats_t ss;
    SOS_GetStats(&ss);
    out->running = s_running;
    out->level = s_level;
    out->level_alarm = s_level_alarm;
    out->sos_alarm = SOS_AlarmActive();
    out->sos_events = ss.event_count;
    out->sos_floor_dbfs = ss.floor_dbfs;
    out->blocks = s_blocks;
}

/* Callback DMA I2S - dinh nghia DUY NHAT o file nay trong project
 * (HAL_UART_* o telemetry.c, HAL_GPIO_EXTI o motors_app.c). */
void HAL_I2S_RxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
    if (hi2s == &hi2s3)
        process_block(&s_dma_buf[0]);
}

void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s)
{
    if (hi2s == &hi2s3)
        process_block(&s_dma_buf[SOUND_DMA_WORDS / 2u]);
}
