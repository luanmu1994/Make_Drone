/* PROJECT HOAN CHINH - xem telemetry.h.
 * RX: ngat tung byte -> ring buffer -> Telemetry_TakeCommand ghep khung
 *     va kiem CRC trong ngu canh vong lap (khong xu ly trong ISR).
 * TX: Transmit_IT, 1 buffer duy nhat - dang ban thi bo qua chu ky nay.
 * LUU Y: file nay dinh nghia HAL_UART_RxCpltCallback / TxCpltCallback.
 * Neu project can callback UART cho muc dich khac, hop nhat vao day. */
#include "telemetry.h"
#include "main.h"
#include <string.h>

extern UART_HandleTypeDef huart2;

#define HDR0 0xAA
#define HDR1 0x55
#define MAX_PAYLOAD 32
#define RX_RING_SIZE 256

static uint8_t  s_rx_byte;
static volatile uint8_t s_ring[RX_RING_SIZE];
static volatile uint16_t s_ring_head, s_ring_tail;

static uint8_t  s_tx_buf[2 + 3 + 24 + 2];   /* khung lon nhat = type 0x01 */
static volatile bool s_tx_busy;
static uint8_t  s_tx_seq;

static uint32_t s_rx_packets, s_rx_crc_errors;

/* ------------------------------------------------------------- CRC16 --- */
static uint16_t crc16_modbus(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc & 1) ? (uint16_t)((crc >> 1) ^ 0xA001)
                            : (uint16_t)(crc >> 1);
    }
    return crc;
}

/* ------------------------------------------------------------ TX path -- */
static void tx_frame(uint8_t type, const uint8_t *payload, uint8_t len)
{
    if (s_tx_busy) return;
    uint8_t *f = s_tx_buf;
    f[0] = HDR0; f[1] = HDR1;
    f[2] = type;
    f[3] = s_tx_seq++;
    f[4] = len;
    if (len) memcpy(&f[5], payload, len);
    uint16_t crc = crc16_modbus(&f[2], (uint16_t)(3 + len));
    f[5 + len] = (uint8_t)(crc & 0xFF);
    f[6 + len] = (uint8_t)(crc >> 8);
    s_tx_busy = true;
    if (HAL_UART_Transmit_IT(&huart2, f, (uint16_t)(7 + len)) != HAL_OK)
        s_tx_busy = false;
}

void Telemetry_Ack(uint8_t cmd_seq, uint8_t status)
{
    uint8_t p[2] = { cmd_seq, status };
    tx_frame(TELEM_TYPE_ACK, p, 2);
}

static void put_u16le(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xFF);
    p[1] = (uint8_t)(v >> 8);
}

void Telemetry_SendState(const telem_state_t *st)
{
    uint8_t p[24];
    p[0] = st->mode;
    p[1] = st->fsm;
    p[2] = st->running;
    for (int i = 0; i < 3; i++)
        put_u16le(&p[3 + 2 * i], (uint16_t)st->dist_mm[i]);
    for (int i = 0; i < 4; i++) p[9 + i] = st->pwm_pct[i];
    for (int i = 0; i < 4; i++)
        put_u16le(&p[13 + 2 * i], (uint16_t)st->rpm[i]);
    put_u16le(&p[21], st->sound_level);
    p[23] = st->sound_alarm;
    tx_frame(TELEM_TYPE_STATE, p, 24);
}

/* ------------------------------------------------------------ RX path -- */
void Telemetry_Init(void)
{
    s_ring_head = s_ring_tail = 0;
    s_tx_busy = false;
    (void)HAL_UART_Receive_IT(&huart2, &s_rx_byte, 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart2) {
        uint16_t next = (uint16_t)((s_ring_head + 1) % RX_RING_SIZE);
        if (next != s_ring_tail) {
            s_ring[s_ring_head] = s_rx_byte;
            s_ring_head = next;
        }
        (void)HAL_UART_Receive_IT(&huart2, &s_rx_byte, 1);
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart2) s_tx_busy = false;
}

static bool ring_get(uint8_t *b)
{
    if (s_ring_tail == s_ring_head) return false;
    *b = s_ring[s_ring_tail];
    s_ring_tail = (uint16_t)((s_ring_tail + 1) % RX_RING_SIZE);
    return true;
}

/* May ghep khung: 0 HDR0 -> 1 HDR1 -> 2 TYPE -> 3 SEQ -> 4 LEN -> 5 PAYLOAD
   -> 6 CRC_LO -> 7 CRC_HI -> kiem tra + phat lenh */
static uint8_t s_ps;
static uint8_t s_f_type, s_f_seq, s_f_len, s_f_idx;
static uint8_t s_f_payload[MAX_PAYLOAD];
static uint8_t s_f_crc_lo;

bool Telemetry_TakeCommand(uint8_t *cmd, uint8_t pwm_pct[4], uint8_t *seq)
{
    uint8_t b;
    while (ring_get(&b)) {
        switch (s_ps) {
            case 0: s_ps = (b == HDR0) ? 1 : 0; break;
            case 1: s_ps = (b == HDR1) ? 2 : 0; break;
            case 2: s_f_type = b; s_ps = 3; break;
            case 3: s_f_seq = b; s_ps = 4; break;
            case 4:
                s_f_len = b;
                s_f_idx = 0;
                if (s_f_len > MAX_PAYLOAD) { s_ps = 0; break; }
                s_ps = (s_f_len == 0) ? 6 : 5;
                break;
            case 5:
                s_f_payload[s_f_idx++] = b;
                if (s_f_idx >= s_f_len) s_ps = 6;
                break;
            case 6: s_f_crc_lo = b; s_ps = 7; break;
            case 7: {
                uint8_t body[3 + MAX_PAYLOAD];
                body[0] = s_f_type; body[1] = s_f_seq; body[2] = s_f_len;
                if (s_f_len) memcpy(&body[3], s_f_payload, s_f_len);
                uint16_t crc = crc16_modbus(body, (uint16_t)(3 + s_f_len));
                s_ps = 0;
                if ((uint8_t)(crc & 0xFF) != s_f_crc_lo ||
                    (uint8_t)(crc >> 8) != b) {
                    s_rx_crc_errors++;
                    break;
                }
                s_rx_packets++;
                if (s_f_type == TELEM_TYPE_CMD && s_f_len == 5) {
                    *cmd = s_f_payload[0];
                    memcpy(pwm_pct, &s_f_payload[1], 4);
                    *seq = s_f_seq;
                    return true;
                }
                break;
            }
            default: s_ps = 0; break;
        }
    }
    return false;
}

uint32_t Telemetry_RxPackets(void)   { return s_rx_packets; }
uint32_t Telemetry_RxCrcErrors(void) { return s_rx_crc_errors; }
