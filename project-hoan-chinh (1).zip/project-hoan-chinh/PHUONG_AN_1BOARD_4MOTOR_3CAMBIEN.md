# Phương án 1 board: 4 motor + 3 cảm biến, không chiếm tài nguyên của nhau

Phạm vi: **chỉ** 1 board STM32F407VET6 + 4 động cơ N20 (2× TB6612FNG)
+ 3 cảm biến VL53L0X. Không INMP441, không thêm ngoại vi khác — INMP441
là bước G5 riêng và đã được chừa đường (xem cuối tài liệu).
Sơ đồ tổng quan: `so_do_tai_nguyen.png`. Code tương ứng: gói
`project-hoan-chinh` này.

![Sơ đồ tài nguyên](so_do_tai_nguyen.png)

## Nguyên tắc phân bổ: mỗi tài nguyên một chủ, phần cứng tự chạy

Ba quy tắc giúp các hệ con không giẫm lên nhau:

1. **Mỗi timer/chân/bus chỉ có đúng một chủ.** Toàn bộ hệ thống dùng
   32 chân, không chân nào gánh hai chức năng (bảng 1 — đã rà soát cơ
   học từ chính mã nguồn của gói, không phải vẽ tay).
2. **Việc nặng giao cho phần cứng tự chạy, CPU chỉ điều phối.** PWM do
   timer tự phát, 2 encoder chính do timer tự đếm — khi CPU bận đọc
   cảm biến, motor vẫn quay đều và encoder vẫn đếm đủ, không mất xung.
3. **Việc phải dùng CPU thì chạy bằng ngắt hoặc chia lượt.** Encoder
   mềm chạy bằng ngắt EXTI (chen vào được mọi lúc), cảm biến đọc theo
   lượt quay vòng từng con một (không bao giờ khóa vòng lặp quá ~75 ms),
   telemetry gửi/nhận bằng ngắt USART — và **không dùng DMA nào cả**
   nên không tồn tại xung đột kênh DMA.

## Bảng 1 — Bản đồ chân (32 chân, mỗi chân 1 chức năng)

| Nhóm | Chân | Chức năng | Tài nguyên |
|---|---|---|---|
| PWM | PE9, PE11 | PWM M1, M2 | TIM1 CH1/CH2 (20 kHz) |
| PWM | PB14, PB15 | PWM M3, M4 | TIM12 CH1/CH2 (20 kHz) |
| Chiều | PB0/PB1, PE5/PE6 | AIN/BIN mạch 1 (M1, M2) | GPIO out |
| Chiều | PD8/PD9, PD10/PD11 | AIN/BIN mạch 2 (M3, M4) | GPIO out |
| STBY | PE0, PE1 | STBY 2 mạch TB6612 | GPIO out |
| Encoder cứng | PC6/PC7 | Encoder M1 | TIM3 Encoder Mode |
| Encoder cứng | PD12/PD13 | Encoder M2 | TIM4 Encoder Mode |
| Encoder mềm | PD14/PD15 | Encoder M3 | EXTI14/15 |
| Encoder mềm | PE12/PE13 | Encoder M4 | EXTI12/13 |
| Cảm biến | PB6/PB7 | SCL/SDA chung 3 cảm biến | I2C1, 100 kHz |
| Cảm biến | PC0/PC1/PC2 | XSHUT FRONT/LEFT/RIGHT | GPIO out, boot = LOW |
| Debug | PA9/PA10 | Log + CSV | USART1 115200 |
| Không dây | PA2/PA3 | HC-12 | USART2 9600, ngắt |
| An toàn | PE2 | Công tắc dừng vật lý | GPIO in, pull-up |

## Bảng 2 — Timer, ngắt, DMA

| Tài nguyên | Chủ | Ghi chú |
|---|---|---|
| TIM1 | PWM M1+M2 | PSC 0 / ARR 8399 @168 MHz |
| TIM12 | PWM M3+M4 | PSC 0 / ARR 4199 @84 MHz |
| TIM3 | Đếm encoder M1 | Tự đếm ×4, **0% CPU**, không ngắt |
| TIM4 | Đếm encoder M2 | Tự đếm ×4, **0% CPU**, không ngắt |
| TIM2, TIM5, TIM6, TIM7, TIM8 | **Trống** | Dành cho mở rộng sau |
| NVIC EXTI15_10 | Encoder mềm M3+M4 | Ưu tiên cao nhất trong các ngắt ứng dụng |
| NVIC USART2 | Telemetry HC-12 | Ngắt từng byte, xử lý khung ở vòng lặp |
| SysTick | HAL tick 1 ms | Mặc định |
| DMA1/DMA2 | **Không dùng** | 0 xung đột — để dành cho I2S/INMP441 ở G5 |

Vì sao M3/M4 phải dùng encoder mềm: sau khi TIM1/TIM12 làm PWM và
TIM3/TIM4 làm encoder cứng, các cặp chân encoder cứng còn lại của
TIM2/TIM5/TIM8 đều vướng chân đã có chủ (PA0 nút WKUP, PA15/PB3 nhóm
SPI-flash, PC6/PC7 trùng TIM3) — đây là kết quả đã kiểm chứng ở bản đồ
hợp nhất trong tài liệu phân tích. Encoder mềm bằng EXTI trên
PD14/PD15 + PE12/PE13 là phương án duy nhất không đụng tài nguyên nào.

## Vì sao 3 yêu cầu vẫn bảo đảm khi chạy đồng thời

**1. Bốn motor vẫn chạy đều.** Xung PWM do TIM1/TIM12 tự phát bằng
phần cứng — CPU có bận 75 ms để chờ một lần đo cảm biến thì duty vẫn
được phát liên tục, không nhấp nháy, không khựng. Việc cập nhật duty
(ramp) chạy theo tick 10 ms trong vòng điều phối, có bù nhịp sau mỗi
lần đọc cảm biến nên tốc độ ramp không bị chậm lại.

**2. Vẫn đọc được dữ liệu encoder của cả 4 motor.**
- M1/M2: TIM3/TIM4 **tự đếm bằng phần cứng**, độc lập hoàn toàn với
  CPU — CPU chỉ đọc bộ đếm mỗi 10 ms để tính RPM. Dù vòng lặp chính
  đang khóa ở I2C, xung encoder vẫn được đếm đủ từng xung một.
- M3/M4: mỗi cạnh xung kích ngắt EXTI; ngắt chen vào được ngay cả khi
  CPU đang chờ cảm biến (I2C theo polling vẫn nhường ngắt). Tải tối
  kem nhất khi cả hai cùng chạy 300 RPM (CPR 2800): ~14.000 cạnh/s mỗi
  motor → ~28.000 ngắt/s → khoảng **4% CPU**. Mức này không ảnh hưởng
  các việc khác.

**3. Ba cảm biến vẫn đọc được thông số.** Ba con dùng chung bus I2C1
nhưng mỗi con một địa chỉ riêng (0x30/0x31/0x32, gán lúc boot bằng dãy
XSHUT PC0→PC1→PC2) nên bus dùng chung mà không xung đột địa chỉ.
Firmware đọc **tuần tự quay vòng** FRONT→LEFT→RIGHT, mỗi lượt vòng
lặp chỉ một lần single-shot của một con → mỗi con có mẫu mới mỗi
~220 ms, median trượt 5 mẫu làm mới ~4–5 Hz cho cả ba con — đồng thời
giữ độ trễ phản ứng dừng ở mức một lượt vòng lặp (~85 ms tối đa).

Một cảm biến lỗi/offline cũng không kéo theo hai con còn lại: lượt
đọc bỏ qua con offline, FSM tự chuyển BLOCKED theo luật fail-safe, và
firmware tự thử khôi phục con đó mỗi 10 s khi xe đang dừng.

## Nguồn điện — phần "tài nguyên" dễ bị quên

- **VM 6V riêng cho motor** (buck từ 2S, ≥ 5 A), không lấy từ rail
  3.3V/5V của board — dòng khởi động motor không được phép làm sụt áp
  của MCU và cảm biến.
- **3.3V cho 3 cảm biến + 4 encoder** — tải nhỏ, dùng rail 3.3V của
  board được.
- **Đất chung nối sao** tại điểm cấp nguồn; tụ 100 µF tại VM–GND của
  mỗi TB6612 như phương án 4 motor; dây SCL/SDA ngắn, và I2C chạy
  **100 kHz** (3 module song song làm điện dung bus tăng ~3 lần — đây
  cũng là nghi phạm chính của lỗi INIT FAIL đang chẩn đoán).

## Giới hạn thật của phương án (nói thẳng)

- Lần đọc cảm biến là blocking theo polling: vòng lặp chính bị giữ
  tối đa ~75 ms mỗi lượt. Thiết kế chấp nhận việc này vì PWM và
  encoder cứng chạy bằng phần cứng, encoder mềm và UART chạy bằng
  ngắt — không hệ con nào mất dữ liệu trong khoảng đó. Đổi lại, độ
  trễ từ khi có median mới đến khi FSM đổi trạng thái là tối đa
  ~1 lượt vòng lặp + 1 tick FSM (100 ms).
- Median làm mới ~4–5 Hz/con là trần của kiểu đo single-shot quay
  vòng; muốn nhanh hơn phải chuyển VL53L0X sang continuous mode —
  ngoài phạm vi phương án này.
- Khi thêm INMP441 (G5), nó dùng I2S2 + DMA1 Stream 3 — cả hai đều
  đang trống trong phương án này, và chân MCK của I2S2 (PC6) được tắt
  để không đụng encoder M1 (đã phân tích riêng ở mục 6 tài liệu tích
  hợp), nên việc mở rộng không phá vỡ bản đồ trên.

## Cập nhật 2026-11-10: INMP441 chuyển sang I2S3

Phương án giữ DMA1 Stream 3 cho I2S2 (G5) ở trên nay thay bằng:
**INMP441 trên I2S3 (Master Receive)** — SCK=PC10, WS=PA4, SD=PC12
(đều AF6, đã đối chiếu DS8626), MCK tắt (PC7 là encoder M1), DMA1
Stream 0 Channel 0 (SPI3_RX) Circular. Cả 3 chân đều trống trong bản
đồ 32 chân nên kết luận "không xung đột tài nguyên" giữ nguyên;
PB10/PB12/PC3 và DMA1 Stream 3 được giải phóng. Chi tiết: xem
`INMP441_I2S3.md` + `so_do_inmp441_i2s3.png` trong cùng gói.
