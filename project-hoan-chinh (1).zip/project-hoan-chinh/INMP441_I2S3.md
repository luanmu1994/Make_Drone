# INMP441 trên I2S3 (chỉ thu) — sơ đồ pin & cấu hình

Quyết định 2026-11-10: chuyển INMP441 từ phương án I2S2 cũ
(PB10/PB12/PC3) sang **I2S3, Master Receive (chỉ thu)**. Sơ đồ hình:
`so_do_inmp441_i2s3.png`.

## Bảng đấu dây

| INMP441 | STM32F407 | Chức năng | Ghi chú |
|---|---|---|---|
| VDD | 3V3 | Nguồn 3.3V | Thêm 100 nF VDD–GND tại module nếu chưa có |
| GND | GND | Đất chung | |
| SCK | **PC10** | I2S3_CK (AF6) — BCLK | STM32 cấp xung |
| WS | **PA4** | I2S3_WS (AF6) — LRCK | |
| SD | **PC12** | I2S3_SD (AF6) — Data | Mic gửi về STM32 |
| L/R | GND | Chọn kênh LEFT | L/R = VDD thì là kênh RIGHT |
| — (không có) | PC7 | I2S3_MCK | **Không dùng, tắt trong CubeMX** |

Đã đối chiếu Bảng 9 (Alternate function) của DS8626 Rev 12: cả ba
chân đều là AF6 của SPI3/I2S3. Chân MCK của I2S3 chỉ có ở PC7 — mà PC7
đang là TIM3_CH2 của encoder M1, và INMP441 vốn không có chân MCK,
nên Master Clock Output bắt buộc DISABLE (giống hệt kết luận trước
đây với PC6/I2S2_MCK).

## Vì sao chọn đúng 3 chân này

- PC10 / PA4 / PC12 **đều đang trống** trong bản đồ 32 chân của
  project hợp nhất (motor + cảm biến + HC-12 + công tắc dừng) — rà
  theo `PHUONG_AN_1BOARD_4MOTOR_3CAMBIEN.md`, không chân nào gánh
  hai việc.
- Bộ chân I2S3 còn lại (CK=PB3, WS=PA15, SD=PB5) **không dùng**: cả
  ba nằm trong nhóm SPI-Flash/NRF trên bo DevEBox (PA15 còn là JTDI),
  dễ xung đột phần cứng có sẵn trên bo.
- Hệ quả phụ tích cực: phương án I2S2 cũ được giải phóng hoàn toàn —
  PB10, PB12, PC3 và DMA1 Stream 3 không còn bị giữ nữa.

## Cấu hình CubeMX / firmware (cho bước G5)

- SPI3 → Mode **I2S**, Full-Duplex tắt; I2S3: **Master Receive**,
  Standard = **Philips**, Data Format = **24 bits on 32 bits frame**,
  Audio Frequency = **16 kHz** (đủ cho mục đích đo mức âm 0–100 và
  báo động > 80; INMP441 xuất 24-bit, dấu bù 2, MSB trước).
- **Master Clock Output = Disable** (xem lý do PC7 ở trên). Sau khi
  Generate, rà `gpio.c`: PC10/PA4/PC12 phải là AF6; PC7 vẫn AF2 TIM3.
- DMA: **DMA1 Stream 0, Channel 0** (SPI3_RX theo RM0090; lựa chọn
  thay thế Stream 2 Ch 0 nếu Stream 0 bận — hiện DMA của project
  đang trống hoàn toàn), Mode = **Circular**, data width theo khung
  32-bit. Nhận DMA chạy nền, CPU chỉ tính mức âm (RMS/đỉnh) trên
  các nửa buffer mỗi 100 ms như phân tích mục 6 của tài liệu tích hợp.
- Dữ liệu kênh LEFT nằm ở nửa khung đầu của mỗi frame (vì L/R = GND);
  khi xử lý chỉ lấy các mẫu ở slot LEFT, bỏ slot RIGHT (toàn 0).
- Hiệu chuẩn như đã ghi ở phân tích tích hợp: tiếng ồn tự thân của
  4 motor làm tăng mức đo — thang 0–100 phải hiệu chuẩn khi motor
  đang chạy, nếu không báo động > 80 sẽ báo giả.

## Lưu ý đấu dây

- Ba dây tín hiệu giữ ngắn (< 20 cm), xoắn/đi kèm dây GND; tránh đi
  song song dài với dây PWM motor (nhiễu đóng cắt chui vào SCK).
- Không cắm thẻ TF vào khe microSD của bo khi đang chạy cấu hình
  này: khe TF dùng chung PC10/PC12 cho SDIO, cắm thẻ sẽ giành chân.

## Cập nhật 2026-11-11: firmware G5 đã viết và ghép vào project

Cấu hình ở trên nay đã có firmware tương ứng trong chính gói này:
`sound_app.c/.h` (thu I2S3 + DMA circular đúng cấu hình mục này, xử
lý khối 100 ms, tính mức 0–100) và `sos_detect.c/.h` (phát hiện mẫu
tiếng kêu cứu, nạp mẫu ngay trong callback DMA). Cách nối vào
`app_main`/telemetry và dấu hiệu kiểm chứng trên log boot xem mục
"Cập nhật 2026-11-11 (G5)" trong `HUONG_DAN_PROJECT_HOAN_CHINH.md`.
Vẫn còn hiệu chuẩn thang 0–100 trên xe thật (mục 3.3 của tài liệu kỹ
thuật 03) — hệ số trong `sound_app.h` đang là giá trị tạm.
